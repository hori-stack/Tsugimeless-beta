using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    internal sealed class TesterReportWindow : EditorWindow
    {
        // The receiving page was verified on 2026-09-23. No report or key is put into its URL.
        internal const string FormUrl = "https://docs.google.com/forms/d/e/1FAIpQLSfghCAYPcW6VkPl6j7PP8S6hoAMkgm98qoGeSSPFBWkqBorsA/viewform";
        private TesterReportBundle bundle;
        private readonly List<Texture2D> images = new List<Texture2D>();
        private string savedPath;
        internal static TesterReportWindow Open(TesterReportBundle report)
        {
            var window = CreateInstance<TesterReportWindow>(); window.bundle = report;
            window.titleContent = new GUIContent(L.T("テスト報告", "Test report"));
            window.minSize = new Vector2(440, 420); window.Show(); return window;
        }
        public void CreateGUI()
        {
            foreach (var image in images) if (image) DestroyImmediate(image); images.Clear();
            rootVisualElement.Clear();
            if (bundle == null)
            {
                rootVisualElement.Add(new Label(L.T("報告を作り直してください。元のアバターは変更していません。", "Create the report again. The original avatar was not changed."))); return;
            }
            TsugimelessStyles.Apply(rootVisualElement);
            var scroll = new ScrollView(); scroll.style.paddingLeft = scroll.style.paddingRight = 12;
            rootVisualElement.Add(scroll);
            scroll.Add(TsugimelessStyles.Heading(L.T("写真と内容を確かめて報告する", "Review photos and report details")));
            scroll.Add(TsugimelessStyles.Note(L.T("開いた時点の情報です。アバターを操作し直した場合は、この画面を閉じて報告を作り直してください。", "This is a snapshot from when you opened this window. If you change the avatar, close this window and create a new report.")));
            var avatar = new TextField(L.T("アバター名・版・改変内容", "Avatar, version and modifications")) { name = "report-avatar", maxLength = 200 };
            avatar.SetValueWithoutNotify(bundle.Document.avatar);
            var choices = new RadioButtonGroup(L.T("今回の結果", "Test result"), new List<string> {
                L.T("首が自然になじんだ", "The neck looks naturally blended"),
                L.T("線や見た目で困った", "A problem with lines or appearance"),
                L.T("適用・元に戻す操作で困った", "A problem applying or restoring"),
                L.T("まだ確認できていない", "Not checked yet") }) { name = "report-result", value = -1 };
            var codes = new[] { "LooksGood", "LinesOrAppearanceIssue", "ApplyOrRestoreIssue", "NotChecked" };
            choices.SetValueWithoutNotify(Array.IndexOf(codes, bundle.Document.result));
            var comment = new TextField(L.T("困ったこと・補足（任意）", "Problem or additional details (optional)")) { name = "report-comment", multiline = true, maxLength = 4000 };
            comment.SetValueWithoutNotify(bundle.Document.comment);
            comment.style.height = 90;
            var notice = TsugimelessStyles.Note(""); notice.name = "report-save-notice";
            var save = TsugimelessStyles.ColoredButton(L.T("確認した内容で報告ZIPを保存する", "Save the reviewed report ZIP"), Save, "report-save", true);
            save.SetEnabled(false);
            var message = new TextField(L.T("DMへ貼り付ける報告文", "Report message for your DM"))
                { name = "report-message", multiline = true, isReadOnly = true, value = bundle.Message() };
            message.style.height = 180;
            var copyMessage = TsugimelessStyles.ColoredButton(L.T("報告文をコピー", "Copy report message"), () => Copy(message.value), "report-copy-message", true);
            var savePhotos = TsugimelessStyles.ColoredButton(L.T("写真を保存", "Save photos"), SavePhotos, "report-save-photos", true);
            TextField json = null;
            var copyDetails = TsugimelessStyles.ColoredButton(L.T("詳しい診断をコピー", "Copy detailed diagnostics"), () => Copy(json?.value), "report-copy-diagnostics");
            var confirmed = new Toggle(L.T("写真とデータを確認しました", "I reviewed the photos and data")) { name = "report-reviewed" };
            void Update()
            {
                bool ready = confirmed.value && choices.value >= 0 && !string.IsNullOrWhiteSpace(avatar.value);
                save.SetEnabled(ready); copyMessage.SetEnabled(ready); copyDetails.SetEnabled(ready);
                savePhotos.SetEnabled(ready && bundle.Photos.Count > 0);
            }
            void Changed()
            {
                savedPath = null; notice.text = ""; confirmed.SetValueWithoutNotify(false);
                message.SetValueWithoutNotify(bundle.Message()); json?.SetValueWithoutNotify(bundle.Json()); Update();
            }
            Update();
            avatar.RegisterValueChangedCallback(e => { bundle.Document.avatar = e.newValue; Changed(); });
            choices.RegisterValueChangedCallback(e => { bundle.Document.result = e.newValue >= 0 ? codes[e.newValue] : "NotAnswered"; Changed(); });
            comment.RegisterValueChangedCallback(e => { bundle.Document.comment = e.newValue; Changed(); });
            confirmed.RegisterValueChangedCallback(_ => Update());
            scroll.Add(avatar); scroll.Add(choices); scroll.Add(comment);
            scroll.Add(TsugimelessStyles.Note(L.T("一定の照明で撮った首の比較画像です。シーンの光・髪・服・他ツールの仮表示は含みません。", "Neck images use fixed lighting. Scene lighting, hair, clothing and other tools' previews are excluded.")));
            string state = bundle.Document.photoState == "ComputedPreview" ? L.T("補正後の写真は計算結果です。適用・保存の完了を示すものではありません。", "After photos show the computed result, not proof of application or saving.")
                : L.T("現在の材質を撮影しています。比較できる元の材質がある場合は並べて表示します。", "Photos show the current material, alongside the original when available.");
            scroll.Add(TsugimelessStyles.Note(state));
            if (bundle.Photos.Count == 0) scroll.Add(new HelpBox(L.T("写真を撮れませんでした。検証データとコメントだけでも報告できます。", "Photos could not be captured. You can still report diagnostics and comments."), HelpBoxMessageType.Info));
            var grid = new VisualElement(); grid.style.flexDirection = FlexDirection.Row; grid.style.flexWrap = Wrap.Wrap;
            foreach (var photo in bundle.Photos)
            {
                var texture = new Texture2D(2, 2) { hideFlags = HideFlags.HideAndDontSave };
                images.Add(texture);
                if (!texture.LoadImage(photo.Png)) continue;
                var card = new VisualElement(); card.style.width = Length.Percent(50); card.style.paddingRight = 6;
                card.Add(new Label(TesterReportBundle.PhotoLabel(photo.Name)));
                var image = new Image { image = texture, scaleMode = ScaleMode.ScaleToFit }; image.style.height = 220;
                card.Add(image); grid.Add(card);
            }
            scroll.Add(grid);
            scroll.Add(message);
            scroll.Add(TsugimelessStyles.Note(L.T("報告文をDMへ貼り付け、保存した写真を添付してください。長い文章や写真は、使うDMに合わせて分けて送れます。", "Paste the report into your DM and attach the saved photos. Split long messages or photos as needed for your messaging service.")));
            var data = new Foldout { name = "report-details", text = L.T("詳しい報告が必要なとき", "When a detailed report is needed"), value = false };
            json = new TextField { value = bundle.Json(), multiline = true, isReadOnly = true }; json.style.height = 200; data.Add(json);
            data.Add(copyDetails); data.Add(save);
            data.RegisterValueChangedCallback(_ => json.SetValueWithoutNotify(bundle.Json()));
            scroll.Add(TsugimelessStyles.Note(L.T("キー・PC名・保存先・元の画像やメッシュは含みません。自動送信はしません。", "Keys, PC names, file paths, source textures and meshes are excluded. Nothing is sent automatically.")));
            scroll.Add(confirmed);
            var actions = new VisualElement(); actions.style.flexDirection = FlexDirection.Row; actions.style.flexWrap = Wrap.Wrap;
            foreach (var action in new[] { copyMessage, savePhotos }) { action.style.flexGrow = 1; action.style.flexBasis = 180; action.style.minWidth = 170; actions.Add(action); }
            scroll.Add(actions);
            scroll.Add(notice);
            var form = TsugimelessStyles.ColoredButton(L.T("報告フォームを開く", "Open the report form"), () => { if (!string.IsNullOrEmpty(FormUrl)) Application.OpenURL(FormUrl); }, "report-form");
            form.SetEnabled(!string.IsNullOrEmpty(FormUrl)); data.Add(form);
            data.Add(TsugimelessStyles.Note(L.T("フォームへの回答にはGoogleへのログインが必要です。報告ZIPを添付すると、アカウントの名前・メールアドレス・写真がGoogle側に記録されます。", "Answering the form requires Google sign-in. Attaching the report ZIP records your account name, email and profile photo with Google.")));
            scroll.Add(data);
            void Copy(string value)
            {
                try { EditorGUIUtility.systemCopyBuffer = value ?? ""; notice.text = L.T("コピーしました。DMへ貼り付けてください。まだ送信していません。", "Copied. Paste it into your DM. Nothing has been sent."); }
                catch { notice.text = L.T("コピーできませんでした。表示内容を選択してコピーしてください。", "Copy failed. Select the displayed text and copy it manually."); }
            }
            void SavePhotos()
            {
                string parent = EditorUtility.OpenFolderPanel(L.T("写真の保存先を選ぶ", "Choose where to save photos"), Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "");
                if (string.IsNullOrEmpty(parent)) return;
                try { savedPath = bundle.SavePhotos(parent); }
                catch
                {
                    notice.text = L.T("写真を保存できませんでした。Assetsの外の書き込めるフォルダを選んでください。一部だけ保存された場合も、既存のファイルは消しません。", "Photos could not be saved. Choose a writable folder outside Assets. Existing or partially saved files are not deleted."); return;
                }
                notice.text = L.T("写真を保存しました。開いたフォルダのPNGを選んで、DMへ添付してください。", "Photos saved. Select PNG images in the opened folder and attach them to your DM.");
                try { EditorUtility.RevealInFinder(Path.Combine(savedPath, bundle.Photos[0].Name)); }
                catch { notice.text += "\n" + savedPath; }
            }
            void Save()
            {
                string path = EditorUtility.SaveFilePanel(L.T("報告ZIPの保存先", "Save report ZIP"), Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                    "Tsugimeless-report-" + bundle.Document.reportId.Substring(0, 12), "zip");
                if (string.IsNullOrEmpty(path)) return;
                try
                {
                    bundle.Save(path); savedPath = path;
                    notice.text = L.T("報告ZIPを保存しました。次にフォームで、このファイルを添付してください。", "Report ZIP saved. Next, attach this file in the form.");
                    EditorUtility.RevealInFinder(savedPath);
                }
                catch (InvalidOperationException error) when (error.Message == "ReportTooLarge")
                { notice.text = L.T("写真の容量が大きいため保存できません。設定の「検証情報を表示する」から内容をコピーし、フォームの補足欄へ貼ってください。", "The photos exceed the size limit. Copy the test information from Settings and paste it into the form's comments."); }
                catch { notice.text = L.T("保存できませんでした。Assetsの外で、まだ存在しないZIP名を指定してください。", "Saving failed. Choose a new ZIP filename outside Assets."); }
            }
        }
        private void OnDisable() { foreach (var image in images) if (image) DestroyImmediate(image); images.Clear(); }
    }
}
