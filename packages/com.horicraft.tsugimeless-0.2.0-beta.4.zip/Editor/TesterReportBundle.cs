using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    [Serializable] internal sealed class TesterMaterialReport
    {
        public string role, family, lilToonVersion;
        public int vertices, subMeshes;
        public List<TesterPropertyReport> properties = new List<TesterPropertyReport>();
        internal static TesterMaterialReport Capture(string role, Renderer renderer, Material material)
        {
            var mesh = NeckTargets.MeshOf(renderer);
            var read = LilToonMaterialRead.Capture(material);
            var result = new TesterMaterialReport { role = role, family = read.Lil ? "lilToon" : "Other",
                lilToonVersion = read.version ?? "unknown", vertices = mesh ? mesh.vertexCount : 0, subMeshes = mesh ? mesh.subMeshCount : 0 };
            // Fixed allowlist: no arbitrary material properties, asset names, paths or texture bytes.
            foreach (string key in new[] { "_Color", "_MainTexHSVG", "_MainGradationStrength", "_MainTex", "_MainColorAdjustMask",
                "_UseMain2ndTex", "_Color2nd", "_Main2ndTex", "_Main2ndBlendMask", "_Main2ndTexBlendMode",
                "_UseMain3rdTex", "_Color3rd", "_Main3rdTex", "_Main3rdBlendMask", "_Main3rdTexBlendMode",
                "_UseShadow", "_ShadowStrength", "_ShadowColor", "_Shadow2ndColor", "_UseRim", "_UseReflection", "_OutlineWidth" })
            {
                if (!read.values.TryGetValue(key, out var value) || !value.Finite) continue;
                bool image = value.type == UnityEngine.Rendering.ShaderPropertyType.Texture;
                result.properties.Add(new TesterPropertyReport { property = key, type = value.type.ToString(),
                    value = image ? "" : string.Join(", ", new[] { value.value.x, value.value.y, value.value.z, value.value.w }.Select(v => v.ToString("G7", CultureInfo.InvariantCulture))),
                    hasImage = image && value.texture, width = image && value.texture ? value.texture.width : 0,
                    height = image && value.texture ? value.texture.height : 0 });
            }
            return result;
        }
    }
    [Serializable] internal sealed class TesterPropertyReport
    { public string property, type, value; public bool hasImage; public int width, height; }
    [Serializable] internal sealed class TesterReportDocument
    {
        public int formatVersion = 1;
        public string reportId = Guid.NewGuid().ToString("N"), avatar = "", result = "NotAnswered", comment = "";
        public TsugimelessWindow.TesterReport diagnostics;
        public List<TesterMaterialReport> materials = new List<TesterMaterialReport>();
        public string photoState = "Unavailable", photoReason = "NotCaptured";
        public string photoMethod = "Isolated face/body skin render; fixed light; no scene lighting, clothing or external preview overrides.";
        public string[] photos = Array.Empty<string>();
    }
    internal sealed class TesterReportPhoto
    {
        internal readonly string Name;
        internal readonly byte[] Png;
        internal TesterReportPhoto(string name, byte[] png) { Name = name; Png = png; }
    }
    internal sealed class TesterReportBundle
    {
        internal readonly TesterReportDocument Document = new TesterReportDocument();
        internal readonly List<TesterReportPhoto> Photos = new List<TesterReportPhoto>();
        internal const int MaxBytes = 10 * 1024 * 1024;
        // Only the reviewed document and in-memory camera PNGs enter the archive.
        internal string Json()
        {
            Document.photos = Photos.Select(p => p.Name).ToArray();
            return JsonUtility.ToJson(Document, true);
        }
        internal string Message()
        {
            var text = new StringBuilder(L.T("ツギメレスのテスト報告", "Tsugimeless test report"));
            text.AppendLine().Append(L.T("アバター: ", "Avatar: ")).AppendLine(Document.avatar);
            text.Append(L.T("結果: ", "Result: ")).AppendLine(ResultLabel(Document.result));
            if (!string.IsNullOrWhiteSpace(Document.comment))
                text.Append(L.T("コメント: ", "Comment: ")).AppendLine(Document.comment);
            text.Append(L.T("写真: ", "Photos: ")).Append(PhotoStateLabel()).Append(" (").Append(Photos.Count).AppendLine(")");
            var d = Document.diagnostics;
            if (d != null)
            {
                string lil = string.Join(" / ", Document.materials.Where(m => m.family == "lilToon")
                    .Select(m => m.lilToonVersion).Where(v => !string.IsNullOrEmpty(v)).Distinct());
                text.Append("Tsugimeless ").Append(d.toolVersion).Append(" / Unity ").Append(d.unityVersion)
                    .Append(" / lilToon ").AppendLine(string.IsNullOrEmpty(lil) ? "unknown" : lil);
                // Compact, fixed scalar diagnostics. Long material data stays in the optional detail copy.
                text.Append("[diagnostics] ").Append(d.platform).Append(" / ").Append(d.graphicsApi).Append(" / ").AppendLine(d.colorSpace);
                text.Append("step=").Append(d.step).Append("; detection=").Append(d.detection).Append("; color=").Append(d.colorResult)
                    .Append("; stale=").Append(d.calculationStale).Append("; applied=").AppendLine(d.applied.ToString());
                text.Append("lines=").Append(d.availableLines).Append("; upper=").Append(d.upperLine).Append("; lower=").Append(d.lowerLine)
                    .Append("; rangeReady=").Append(d.rangeReady).Append("; bandReady=").AppendLine(d.bandReady.ToString());
                if (d.bandPixels > 0) text.Append("pixels=").Append(d.bandPixels).Append("; unreachable=").Append(d.unreachablePixels)
                    .Append("; maxError=").AppendLine(d.maxError);
            }
            text.Append("reportId=").Append(Document.reportId);
            return text.ToString();
        }
        private string PhotoStateLabel()
        {
            if (Photos.Count == 0) return L.T("写真なし", "No photos");
            if (Document.photoState == "ComputedPreview")
                return L.T("補正前と計算結果。適用・保存済みとは限りません。", "Before and computed result; not proof of applying or saving.");
            if (Document.photoState == "CurrentVsOriginal")
                return L.T("元の材質と現在の材質", "Original and current material");
            return L.T("現在の材質（補正前後の比較ではありません）", "Current material (not a before/after comparison)");
        }
        internal string SavePhotos(string parent)
        {
            string full = Path.GetFullPath(parent); RequireOutsideAssets(full);
            if (!Directory.Exists(full)) throw new DirectoryNotFoundException();
            if (Photos.Count == 0) throw new InvalidOperationException("NoReportPhotos");
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            byte[] signature = { 137, 80, 78, 71, 13, 10, 26, 10 };
            long total = 0;
            foreach (var photo in Photos)
            {
                bool named = new[] { "before-", "after-", "current-" }.Any(prefix =>
                    new[] { "front", "left", "right", "back" }.Any(angle => photo.Name == prefix + angle + ".png"));
                if (!named || !seen.Add(photo.Name) || photo.Png == null || !photo.Png.Take(8).SequenceEqual(signature))
                    throw new InvalidOperationException("InvalidReportPhoto");
                total += photo.Png.Length;
            }
            if (total > MaxBytes) throw new InvalidOperationException("ReportTooLarge");
            // All names/bytes are checked before writing. A repeated export gets its own folder.
            string folder = Path.Combine(full, "Tsugimeless-photos-" + Guid.NewGuid().ToString("N"));
            if (Directory.Exists(folder) || File.Exists(folder)) throw new IOException("ReportAlreadyExists");
            Directory.CreateDirectory(folder);
            foreach (var photo in Photos)
                using (var stream = new FileStream(Path.Combine(folder, photo.Name), FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    stream.Write(photo.Png, 0, photo.Png.Length);
            return folder;
        }
        private static void RequireOutsideAssets(string full)
        {
            string assets = Path.GetFullPath(Application.dataPath), packages = Path.Combine(Path.GetDirectoryName(assets), "Packages");
            bool Within(string root) => string.Equals(full.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), root, StringComparison.OrdinalIgnoreCase)
                || full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
            if (Within(assets) || Within(packages)) throw new InvalidOperationException("ChooseOutsideAssets");
        }
        internal string Html()
        {
            string E(string value) => WebUtility.HtmlEncode(value ?? "");
            var html = new StringBuilder("<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>");
            html.Append("<meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; img-src data:; style-src 'unsafe-inline'\"><title>Tsugimeless report</title>");
            html.Append("<style>body{max-width:1100px;margin:32px auto;padding:20px;font:16px/1.7 system-ui;color:#203040}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#eef2f6;padding:20px}.photos{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px}figure{margin:0}img{width:100%;height:auto}h1{font-size:28px}</style></head><body>");
            html.Append("<h1>").Append(E(L.T("ツギメレスのテスト報告", "Tsugimeless test report"))).Append("</h1><p>").Append(E(Document.avatar)).Append("</p>");
            html.Append("<h2>").Append(E(L.T("今回の結果", "Test result"))).Append("</h2><p>").Append(E(ResultLabel(Document.result))).Append("</p>");
            html.Append("<p style='white-space:pre-wrap'>").Append(E(Document.comment)).Append("</p>");
            html.Append("<p>").Append(E(L.T("一定の照明で撮った首の比較画像です。シーンの光・髪・服・他ツールの仮表示は含みません。", "Neck images use fixed lighting. Scene lighting, hair, clothing and other tools' previews are excluded."))).Append("</p>");
            html.Append("<p>").Append(E(Document.photoState)).Append(" / ").Append(E(Document.photoReason)).Append("</p><div class='photos'>");
            foreach (var photo in Photos) html.Append("<figure><figcaption>").Append(E(PhotoLabel(photo.Name))).Append("</figcaption><img alt='").Append(E(photo.Name)).Append("' src='data:image/png;base64,").Append(Convert.ToBase64String(photo.Png)).Append("'></figure>");
            html.Append("</div><details><summary>").Append(E(L.T("含まれる検証データを見る", "View included diagnostics"))).Append("</summary><pre>").Append(E(Json())).Append("</pre></details></body></html>");
            return html.ToString();
        }
        private static string ResultLabel(string code)
        {
            switch (code)
            {
                case "LooksGood": return L.T("首が自然になじんだ", "The neck looks naturally blended");
                case "LinesOrAppearanceIssue": return L.T("線や見た目で困った", "A problem with lines or appearance");
                case "ApplyOrRestoreIssue": return L.T("適用・元に戻す操作で困った", "A problem applying or restoring");
                default: return L.T("まだ確認できていない", "Not checked yet");
            }
        }
        internal static string PhotoLabel(string name)
        {
            string state = name.StartsWith("before-", StringComparison.Ordinal) ? L.T("補正前", "Before")
                : name.StartsWith("after-", StringComparison.Ordinal) ? L.T("補正後", "After") : L.T("現在の材質", "Current material");
            string angle = name.Contains("front") ? L.T("正面", "Front") : name.Contains("left") ? L.T("左ななめ", "Left oblique")
                : name.Contains("right") ? L.T("右ななめ", "Right oblique") : L.T("後ろ", "Back");
            return state + " / " + angle;
        }
        internal byte[] Zip()
        {
            if (Document.avatar.Length > 200 || Document.comment.Length > 4000) throw new InvalidOperationException("ReportTextTooLong");
            using (var memory = new MemoryStream())
            {
                using (var zip = new ZipArchive(memory, ZipArchiveMode.Create, true))
                {
                    void Add(string name, byte[] bytes) { var entry = zip.CreateEntry(name, System.IO.Compression.CompressionLevel.Optimal); using (var output = entry.Open()) output.Write(bytes, 0, bytes.Length); }
                    Add("report.json", Encoding.UTF8.GetBytes(Json())); Add("report.html", Encoding.UTF8.GetBytes(Html()));
                    foreach (var photo in Photos)
                    {
                        if (photo.Name != Path.GetFileName(photo.Name) || !photo.Name.EndsWith(".png", StringComparison.Ordinal)) throw new InvalidOperationException("InvalidPhotoName");
                        Add("photos/" + photo.Name, photo.Png);
                    }
                }
                if (memory.Length > MaxBytes) throw new InvalidOperationException("ReportTooLarge");
                return memory.ToArray();
            }
        }
        internal void Save(string path)
        {
            string full = Path.GetFullPath(path); RequireOutsideAssets(full);
            if (!full.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("ChooseOutsideAssets");
            if (File.Exists(full)) throw new IOException("ReportAlreadyExists");
            byte[] bytes = Zip();
            string partial = full + ".partial-" + Guid.NewGuid().ToString("N");
            using (var stream = new FileStream(partial, FileMode.CreateNew, FileAccess.Write, FileShare.None)) stream.Write(bytes, 0, bytes.Length);
            File.Move(partial, full); // Refuses overwrite; an interrupted write stays explicitly .partial.
        }
    }
}
