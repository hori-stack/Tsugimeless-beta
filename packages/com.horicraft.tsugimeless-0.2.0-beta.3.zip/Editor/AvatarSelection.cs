using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    internal enum SelectionNotice { None, SelectAvatar, SceneOnly, PrefabStage, PreviewObject, ChooseRoot, MultipleAvatars, NotAvatar, Lost, PlayMode }

    internal readonly struct AvatarSelectionResult
    {
        internal readonly GameObject Root;
        internal readonly SelectionNotice Notice;
        internal bool Accepted => Root != null;
        internal AvatarSelectionResult(GameObject root, SelectionNotice notice) { Root = root; Notice = notice; }
    }

    // Resolve only the supplied object and its hierarchy. Never choose the first avatar in a scene.
    internal static class AvatarSelection
    {
        internal static SelectionNotice SceneProblem(GameObject obj)
        {
            if (obj == null || EditorUtility.IsPersistent(obj) || !obj.scene.IsValid() || !obj.scene.isLoaded)
                return SelectionNotice.SceneOnly;
            if (PrefabStageUtility.GetPrefabStage(obj) != null) return SelectionNotice.PrefabStage;
            if (EditorSceneManager.IsPreviewScene(obj.scene) || obj.scene.name == "___NDMF Preview___")
                return SelectionNotice.PreviewObject;
            for (var t = obj.transform; t != null; t = t.parent)
                if ((t.gameObject.hideFlags & HideFlags.DontSave) != 0) return SelectionNotice.PreviewObject;
            return SelectionNotice.None;
        }

        internal static AvatarSelectionResult Resolve(GameObject supplied, bool useSdk = true)
        {
            var problem = SceneProblem(supplied);
            if (problem != SelectionNotice.None) return new AvatarSelectionResult(null, problem);
#if TSUGIMELESS_HAS_VRCSDK
            if (useSdk)
                for (var t = supplied.transform; t != null; t = t.parent)
                    if (t.GetComponent<VRC.SDKBase.VRC_AvatarDescriptor>() != null)
                        return Accept(t.gameObject);
#endif
            // A humanoid Animator is the SDK-independent root, including inactive avatars.
            for (var t = supplied.transform; t != null; t = t.parent)
            {
                var animator = t.GetComponent<Animator>();
                if (animator != null && animator.isHuman) return Accept(t.gameObject);
            }
            // Do not silently select one descendant of a group containing avatars.
            foreach (var t in supplied.GetComponentsInChildren<Transform>(true))
            {
                if (t == supplied.transform) continue;
                var animator = t.GetComponent<Animator>();
                bool root = animator != null && animator.isHuman;
#if TSUGIMELESS_HAS_VRCSDK
                root |= useSdk && t.GetComponent<VRC.SDKBase.VRC_AvatarDescriptor>() != null;
#endif
                if (root) return new AvatarSelectionResult(null, SelectionNotice.MultipleAvatars);
            }
            // Unmarked/unpacked rigs require an explicit scene root; a face or clothing child is not a base.
            if (!HasMesh(supplied)) return new AvatarSelectionResult(null, SelectionNotice.NotAvatar);
            if (supplied.transform.parent != null) return new AvatarSelectionResult(null, SelectionNotice.ChooseRoot);
            return Accept(supplied);
        }

        private static AvatarSelectionResult Accept(GameObject root)
        {
            var problem = SceneProblem(root);
            if (problem != SelectionNotice.None) return new AvatarSelectionResult(null, problem);
            return HasMesh(root) ? new AvatarSelectionResult(root, SelectionNotice.None)
                : new AvatarSelectionResult(null, SelectionNotice.NotAvatar);
        }

        private static bool HasMesh(GameObject root)
        {
            foreach (var renderer in root.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                if (renderer.sharedMesh != null && SceneProblem(renderer.gameObject) == SelectionNotice.None) return true;
            return false;
        }
    }
}
