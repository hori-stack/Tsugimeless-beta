using System;
using UnityEngine;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    public sealed partial class TsugimelessWindow
    {
        private void BuildHistoryPage()
        {
            EnsureNeckTargets();
            body.Add(TsugimelessStyles.Heading(L.T("あとから戻す", "Restore a previous result")));
            if (!context.Root)
            {
                body.Add(TsugimelessStyles.Status(L.T("履歴を見るアバターを選んでください。", "Choose an avatar to view its history."), "history-no-avatar"));
                BuildHistoryChooseTarget(); return;
            }
            body.Add(TsugimelessStyles.Status(L.F("アバター：{0}", "Avatar: {0}", context.Root.name), "history-avatar"));
            if (!SeamTargetsReady())
            {
                body.Add(TsugimelessStyles.Status(L.T("顔と体の指定を確認すると、体の肌の履歴を表示できます。", "Confirm the face and body to view the body's skin history."), "history-target-required"));
                BuildHistoryChooseTarget(); return;
            }
            body.Add(TsugimelessStyles.Status(L.F("体：{0}／材質欄：{1}", "Body: {0} / material slot: {1}", neckTargets.Body.name, SeamBodySlot + 1), "history-target"));
            if (!string.IsNullOrEmpty(seamApplyReason)) body.Add(new HelpBox(seamApplyReason, HelpBoxMessageType.Warning));
            BuildHistoryCard();
        }

        private void BuildHistoryChooseTarget()
        {
            body.Add(TsugimelessStyles.ColoredButton(L.T("アバターと顔・体を確認する", "Review the avatar, face and body"),
                () => Navigate(WorkflowPage.Start), "history-choose-target"));
        }

        private void BuildHistoryCard()
        {
            if (neckTargets?.Body == null || SeamBodySlot < 0) return;
            try
            {
                var history = NeckHistoryStore.Read(context.Root, neckTargets.Body, SeamBodySlot);
                if (history.Initial == null)
                {
                    body.Add(TsugimelessStyles.Status(L.T("この体の肌には履歴がありません。適用すると、元の状態と仕上がりをここから選べます。",
                        "This body's skin has no history yet. After applying, you can choose the initial state and saved results here."), "history-empty"));
                    return;
                }
                var card = TsugimelessStyles.Card(); card.name = "seam-history";
                card.Add(TsugimelessStyles.Guide(L.T("戻すのは、この体の肌の材質欄だけです。画像を外部で編集した場合、その編集は履歴に含みません。", "Only this body's skin material slot is restored. External image edits are not part of this history.")));
                var current = SeamMaterial(false);
                bool initial = current == history.Initial.initial.asset.Load<Material>()
                    || current == history.Initial.original?.Load<Material>() && NeckHistoryAssets.MaterialState(current) == history.Initial.originalState;
                string initialLabel = L.T("元の状態へ戻す", "Restore initial state");
                if (initial) initialLabel += "  " + L.T("現在の状態", "Current");
                var original = TsugimelessStyles.ColoredButton(initialLabel, () => RestoreHistory(null), "seam-restore");
                original.SetEnabled(!initial && SeamTargetsReady()); card.Add(original);
                for (int i = history.Entries.Count - 1; i >= 0; i--)
                {
                    var entry = history.Entries[i]; string time = DateTime.TryParse(entry.utc, out var date) ? date.ToLocalTime().ToString("MM/dd HH:mm") : entry.utc;
                    string label = L.F("{0}回目　{1}", "Result {0}  {1}", i + 1, time);
                    bool applied = current == entry.material.asset.Load<Material>();
                    if (applied) label += "  " + L.T("現在の状態", "Current");
                    var button = TsugimelessStyles.ColoredButton(label, () => RestoreHistory(entry.id), "history-" + entry.id);
                    button.SetEnabled(!applied && SeamTargetsReady()); card.Add(button);
                }
                foreach (string warning in history.Warnings) card.Add(new HelpBox(warning, HelpBoxMessageType.Warning));
                body.Add(card);
            }
            catch (Exception e)
            {
                var warning = new HelpBox(NeckHistoryAssets.Reason(e), HelpBoxMessageType.Warning) { name = "history-unavailable" };
                body.Add(warning);
            }
        }
    }
}
