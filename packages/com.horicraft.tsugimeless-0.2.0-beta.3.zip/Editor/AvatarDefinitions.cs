using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    [Serializable] internal sealed class AvatarDefinitionFile { public int formatVersion = 1; public AvatarDefinition[] avatars; }
    [Serializable] internal sealed class AvatarDefinition
    {
        public string id, displayName, evidence;
        public AvatarDefinitionPart face, body;
        public bool legacyNeckVerified;
        public float legacyThresholdMm = -1;
        public string currentNeckVerification = "unverified";
        public float currentThresholdMm = -1;
    }
    [Serializable] internal sealed class AvatarDefinitionPart
    {
        public string rendererPath, meshGuid, fingerprint;
        public long localFileId;
        public int vertexCount;
        public int[] skinSlots;
    }
    internal static class AvatarDefinitions
    {
        internal const string CatalogPath = "Packages/com.horicraft.tsugimeless/Editor/AvatarDefinitions.json";
        internal static AvatarDefinitionFile Load()
        {
            var asset = AssetDatabase.LoadAssetAtPath<TextAsset>(CatalogPath);
            if (asset == null) return null;
            try { var data = JsonUtility.FromJson<AvatarDefinitionFile>(asset.text); return Valid(data) ? data : null; }
            catch (ArgumentException) { return null; }
        }
        internal static bool Valid(AvatarDefinitionFile data)
        {
            if (data == null || data.formatVersion != 1 || data.avatars == null) return false;
            var ids = new HashSet<string>(StringComparer.Ordinal);
            return data.avatars.All(d => d != null && !string.IsNullOrWhiteSpace(d.id) && ids.Add(d.id)
                && !string.IsNullOrWhiteSpace(d.displayName) && ValidPart(d.face) && ValidPart(d.body));
        }
        private static bool ValidPart(AvatarDefinitionPart p) => p != null && p.rendererPath != null
            && !string.IsNullOrEmpty(p.meshGuid) && p.localFileId != 0 && p.vertexCount > 0 && p.skinSlots != null
            && p.skinSlots.Length > 0 && p.skinSlots.All(s => s >= 0) && p.skinSlots.Distinct().Count() == p.skinSlots.Length;

        internal static Renderer ResolvePath(GameObject root, string path)
        {
            if (root == null || path == null) return null;
            var matches = root.GetComponentsInChildren<Renderer>(true)
                .Where(r => NeckTargets.RelativePath(root.transform, r.transform) == path).ToArray();
            return matches.Length == 1 ? matches[0] : null;
        }
        internal static bool Matches(Renderer renderer, AvatarDefinitionPart part)
        {
            var mesh = NeckTargets.MeshOf(renderer);
            if (mesh == null || part == null || mesh.vertexCount != part.vertexCount || string.IsNullOrEmpty(part.fingerprint)) return false;
            if (!AssetDatabase.TryGetGUIDAndLocalFileIdentifier(mesh, out string guid, out long localId)
                || guid != part.meshGuid || localId != part.localFileId) return false;
            try { return Fingerprint(mesh, part.skinSlots) == part.fingerprint; }
            catch (Exception e) when (e is ArgumentException || e is UnityException || e is IndexOutOfRangeException) { return false; }
        }
        // Shape values belong to the live snapshot; this fingerprint describes UV/topology correspondence.
        internal static string Fingerprint(Mesh mesh, int[] slots)
        {
            if (mesh == null || slots == null || slots.Length == 0) return "";
            var text = new StringBuilder("uv-topology-v1;").Append(mesh.vertexCount).Append(';').Append(mesh.subMeshCount);
            var uv = mesh.uv;
            if (uv.Length != mesh.vertexCount) return "";
            foreach (var value in uv)
            {
                if (!NeckSnapshot.Finite(value.x) || !NeckSnapshot.Finite(value.y)) return "";
                text.Append(';').Append(value.x.ToString("R", CultureInfo.InvariantCulture)).Append(',').Append(value.y.ToString("R", CultureInfo.InvariantCulture));
            }
            foreach (int slot in slots.OrderBy(s => s))
            {
                if (slot < 0 || slot >= mesh.subMeshCount || mesh.GetTopology(slot) != MeshTopology.Triangles) return "";
                text.Append("/slot").Append(slot);
                foreach (int vertex in mesh.GetIndices(slot)) text.Append(',').Append(vertex);
            }
            return Hash128.Compute(text.ToString()).ToString();
        }
    }
}
