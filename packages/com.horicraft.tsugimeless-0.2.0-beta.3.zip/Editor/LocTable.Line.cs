using System.Collections.Generic;

namespace HoriCraft.Tsugimeless.Editor
{
    // Translations for placing the two neck lines (Editor/Neck/NeckLinePlacer.cs).
    // Japanese keys, Simplified Chinese and Korean. English is explicit at each L.T call.
    internal static partial class LocTable
    {
        static partial void AddLineEntries(Dictionary<string, string[]> t)
        {
            t["シーンで、顔側の上の線を置く場所をクリックしてください。やめるときはEscキーを押します。"] = new[] { "请在场景中点击上方线条（面部一侧）的位置。按Esc键可取消。", "씬에서 위쪽 선(얼굴 쪽)을 놓을 위치를 클릭하세요. 그만두려면 Esc 키를 누릅니다." };
            t["シーンで、体側の下の線を置く場所をクリックしてください。やめるときはEscキーを押します。"] = new[] { "请在场景中点击下方线条（身体一侧）的位置。按Esc键可取消。", "씬에서 아래쪽 선(몸 쪽)을 놓을 위치를 클릭하세요. 그만두려면 Esc 키를 누릅니다." };
            t["丸をドラッグすると線の位置を調整できます。置き直すときはボタンを押してください。"] = new[] { "拖动圆点即可调整线条位置。若要重新放置，请点击按钮。", "원을 드래그하면 선의 위치를 조정할 수 있습니다. 다시 놓으려면 버튼을 누르세요." };
            t["上の線（顔側・100%）"] = new[] { "上方线条（面部一侧・100%）", "위쪽 선(얼굴 쪽・100%)" };
            t["下の線（体側・0%）"] = new[] { "下方线条（身体一侧・0%）", "아래쪽 선(몸 쪽・0%)" };
        }
    }
}
