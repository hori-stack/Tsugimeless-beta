using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace HoriCraft.Tsugimeless.Editor
{
    [Serializable] internal sealed class NeckPropertyDefinition { public string name, type, group; }
    [Serializable] internal sealed class NeckPropertyFile
    {
        public int formatVersion;
        public string lilToonVersion;
        public NeckPropertyDefinition[] properties;
        internal static NeckPropertyFile Parse(string json)
        {
            var f = JsonUtility.FromJson<NeckPropertyFile>(json);
            if (f == null || f.formatVersion != 1 || f.properties == null || f.properties.Length == 0
                || f.properties.Any(p => p == null || string.IsNullOrEmpty(p.name) || string.IsNullOrEmpty(p.group) || !Enum.TryParse<ShaderPropertyType>(p.type, out var type) || !Enum.IsDefined(typeof(ShaderPropertyType), type) || type == ShaderPropertyType.Texture
                    || p.name == "_Color" || p.name.StartsWith("_Main", StringComparison.Ordinal) || p.name.Contains("Mask") || p.name.Contains("Bump") || p.name.Contains("Emission"))
                || f.properties.Select(p => p.name).Distinct().Count() != f.properties.Length) throw new ArgumentException("Material property definition format / duplicate / type");
            return f;
        }
        internal static NeckPropertyFile Load()
        {
            var asset = AssetDatabase.LoadAssetAtPath<TextAsset>("Packages/com.horicraft.tsugimeless/Editor/MaterialPropertyDefinitions.json");
            if (!asset) throw new InvalidOperationException("MaterialPropertyDefinitions.json unavailable");
            return Parse(asset.text);
        }
    }
    internal sealed class NeckPropertyDifference
    {
        internal string name, group, face, body, reason;
        internal bool different, inactive;
        internal string Proposal(bool faceReference) => (faceReference ? body : face) + " → " + (faceReference ? face : body);
    }
    internal sealed class NeckMaterialPair
    {
        internal int faceSlot, bodySlot;
        internal NeckMaterialRead face, body;
        internal readonly List<NeckPropertyDifference> properties = new List<NeckPropertyDifference>();
        internal bool Shared => face.source == body.source;
    }
    internal static class NeckMaterialComparison
    {
        internal static string Toggle(string property, string group = "")
        {
            if (property.StartsWith("_Use", StringComparison.Ordinal)) return null;
            if (property.Contains("Emission2nd")) return "_UseEmission2nd";
            if (property.Contains("Emission")) return "_UseEmission";
            if (property.Contains("Main2nd") || property == "_Color2nd") return "_UseMain2ndTex";
            if (property.Contains("Main3rd") || property == "_Color3rd") return "_UseMain3rdTex";
            if (property.Contains("MatCap2nd")) return "_UseMatCap2nd";
            if (property.Contains("MatCap")) return "_UseMatCap";
            if (property.Contains("Backlight")) return "_UseBacklight";
            if (property.Contains("Rim")) return "_UseRim";
            if (property.Contains("Bump2nd")) return "_UseBump2ndMap";
            if (property.Contains("Bump")) return "_UseBumpMap";
            if (group == "Shadow" || property.Contains("Shadow")) return "_UseShadow";
            if (group == "Reflection") return "_UseReflection";
            return null;
        }
        internal static bool Equivalent(NeckMaterialValue a, NeckMaterialValue b, bool exact = false)
        {
            if (a.type != b.type || !a.Finite || !b.Finite) return false;
            exact |= a.discrete || b.discrete;
            if (a.type == ShaderPropertyType.Texture) return a.texture == b.texture && a.st == b.st;
            for (int i = 0; i < 4; i++)
                if (exact || a.type == ShaderPropertyType.Int ? a.value[i] != b.value[i] : Mathf.Abs(a.value[i] - b.value[i]) > 1e-6f * Mathf.Max(1, Mathf.Abs(a.value[i]), Mathf.Abs(b.value[i]))) return false;
            return true;
        }
        internal static NeckMaterialPair Compare(NeckMaterialRead face, int fs, NeckMaterialRead body, int bs, NeckPropertyFile definitions)
        {
            var pair = new NeckMaterialPair { face = face, body = body, faceSlot = fs, bodySlot = bs };
            foreach (var d in definitions.properties)
            {
                var row = new NeckPropertyDifference { name = d.name, group = d.group };
                var type = (ShaderPropertyType)Enum.Parse(typeof(ShaderPropertyType), d.type);
                face.values.TryGetValue(d.name, out var a); body.values.TryGetValue(d.name, out var b);
                row.face = a?.Text ?? "—"; row.body = b?.Text ?? "—";
                if (!face.Lil || !body.Lil || !face.Has(d.name, type) || !body.Has(d.name, type)) row.reason = "shader / type / value";
                else
                {
                    row.different = !Equivalent(a, b, d.name.StartsWith("_Use", StringComparison.Ordinal));
                    string toggle = Toggle(d.name, d.group);
                    if (toggle != null)
                    {
                        if (!face.Number(toggle) || !body.Number(toggle)) row.reason = toggle + ": type/value";
                        else row.inactive = face.N(toggle) == 0 && body.N(toggle) == 0;
                    }
                    if (d.group == "Outline") row.inactive = !face.shaderName.Contains("Outline") && !body.shaderName.Contains("Outline");
                }
                pair.properties.Add(row);
            }
            return pair;
        }
    }
}
