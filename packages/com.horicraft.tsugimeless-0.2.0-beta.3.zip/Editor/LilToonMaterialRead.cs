using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace HoriCraft.Tsugimeless.Editor
{
    internal sealed class NeckMaterialValue
    {
        internal ShaderPropertyType type;
        internal Vector4 value;
        internal Texture texture;
        internal Vector4 st;
        internal bool discrete;
        internal bool Finite => LilToonMaterialRead.Finite(value) && LilToonMaterialRead.Finite(st);
        internal string Text => type == ShaderPropertyType.Texture ? (texture ? texture.name : "None") + " ST " + st.ToString("G6") : value.ToString("G6");
    }
    // Immutable effective values, including inherited Material Variant values. Never writes to source.
    internal sealed class NeckMaterialRead
    {
        internal Material source;
        internal string shaderName, version, signature;
        internal readonly Dictionary<string, NeckMaterialValue> values = new Dictionary<string, NeckMaterialValue>();
        internal bool Has(string name, ShaderPropertyType type) => values.TryGetValue(name, out var v) && v.type == type && v.Finite;
        internal bool Number(string name) => values.TryGetValue(name, out var v) && v.Finite && (v.type == ShaderPropertyType.Float || v.type == ShaderPropertyType.Range || v.type == ShaderPropertyType.Int);
        internal float N(string name, float fallback = 0) => Number(name) ? values[name].value.x : fallback;
        internal Vector4 V(string name, Vector4 fallback = default) => values.TryGetValue(name, out var v) && v.Finite ? v.value : fallback;
        internal Texture T(string name) => values.TryGetValue(name, out var v) && v.type == ShaderPropertyType.Texture ? v.texture : null;
        internal bool Lil => shaderName != null && shaderName.IndexOf("lilToon", StringComparison.OrdinalIgnoreCase) >= 0;
    }
    internal static class LilToonMaterialRead
    {
        internal const string VerifiedVersion = "2.3.4";
        [Serializable] private sealed class PackageData { public string name, version; }
        internal static bool Finite(float v) => !float.IsNaN(v) && !float.IsInfinity(v);
        internal static bool Finite(Vector4 v) => Finite(v.x) && Finite(v.y) && Finite(v.z) && Finite(v.w);
        internal static string Hash(string s)
        { using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(s))).Replace("-", ""); }
        internal static string AssetStamp(UnityEngine.Object value)
        {
            if (!value) return "null";
            string path = AssetDatabase.GetAssetPath(value);
            return value.GetInstanceID() + ":" + EditorUtility.GetDirtyCount(value) + ":" + (string.IsNullOrEmpty(path) ? "memory" : AssetDatabase.GetAssetDependencyHash(path) + ":" + NeckDiagnosisAssetChanges.Revision(path));
        }
        internal static NeckMaterialRead Capture(Material source)
        {
            var result = new NeckMaterialRead { source = source, shaderName = source && source.shader ? source.shader.name : null };
            var stamp = new StringBuilder(AssetStamp(source));
            if (!source || !source.shader) { result.signature = Hash(stamp.ToString()); return result; }
            result.version = Version(source);
            stamp.Append('|').Append(AssetStamp(source.shader)).Append('|').Append(result.version).Append('|').Append(string.Join(",", source.shaderKeywords.OrderBy(x => x))).Append('|').Append(source.renderQueue);
            for (int i = 0; i < source.shader.GetPropertyCount(); i++)
            {
                string name = source.shader.GetPropertyName(i);
                // lilToon repeats inspector-only _DummyProperty declarations. Resolve the same
                // canonical name/index that Unity's material getters use, never duplicate-read it.
                if (source.shader.FindPropertyIndex(name) != i) continue;
                var v = new NeckMaterialValue { type = source.shader.GetPropertyType(i), discrete = source.shader.GetPropertyAttributes(i).Any(a => a.IndexOf("Toggle", StringComparison.OrdinalIgnoreCase) >= 0 || a.IndexOf("Enum", StringComparison.OrdinalIgnoreCase) >= 0) };
                // The shader's declared type is checked before every corresponding getter.
                switch (v.type)
                {
                    case ShaderPropertyType.Float: case ShaderPropertyType.Range: v.value.x = source.GetFloat(name); break;
                    case ShaderPropertyType.Int: v.value.x = source.GetInteger(name); break;
                    case ShaderPropertyType.Color: v.value = source.GetColor(name); break;
                    case ShaderPropertyType.Vector: v.value = source.GetVector(name); break;
                    case ShaderPropertyType.Texture:
                        v.texture = source.GetTexture(name); var scale = source.GetTextureScale(name); var offset = source.GetTextureOffset(name);
                        v.st = new Vector4(scale.x, scale.y, offset.x, offset.y); break;
                }
                result.values.Add(name, v); stamp.Append('|').Append(name).Append(':').Append((int)v.type);
                for (int k = 0; k < 4; k++) stamp.Append(':').Append(v.value[k].ToString("R", CultureInfo.InvariantCulture)).Append(':').Append(v.st[k].ToString("R", CultureInfo.InvariantCulture));
                if (v.texture) stamp.Append(':').Append(AssetStamp(v.texture)).Append(':').Append(v.texture.updateCount).Append(':').Append(v.texture.filterMode).Append(':').Append(v.texture.wrapModeU).Append(':').Append(v.texture.wrapModeV);
            }
            result.signature = Hash(stamp.ToString()); return result;
        }
        internal static string Version(Material source)
        {
            if (!source || !source.shader) return null;
            string path = AssetDatabase.GetAssetPath(source.shader);
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssetPath(path);
            if (package != null && package.name == "jp.lilxyzw.liltoon") return package.version;
            return ReadAssetsVersion(path, p => File.Exists(p) ? File.ReadAllText(p) : null);
        }
        internal static string ReadAssetsVersion(string path, Func<string, string> read)
        {
            if (string.IsNullOrEmpty(path) || !path.StartsWith("Assets/", StringComparison.Ordinal)) return null;
            string folder = Path.GetDirectoryName(path)?.Replace('\\', '/');
            while (folder != null && (folder == "Assets" || folder.StartsWith("Assets/", StringComparison.Ordinal)))
            {
                try { var json = read(folder + "/package.json"); var data = string.IsNullOrEmpty(json) ? null : JsonUtility.FromJson<PackageData>(json);
                    if (data?.name == "jp.lilxyzw.liltoon" && !string.IsNullOrWhiteSpace(data.version)) return data.version; }
                catch (Exception e) when (e is IOException || e is ArgumentException || e is UnauthorizedAccessException) { }
                folder = Path.GetDirectoryName(folder)?.Replace('\\', '/');
            }
            return null;
        }
        internal static string ColorReason(NeckMaterialRead m)
        {
            if (m == null || !m.Lil) return "shader: lilToon";
            foreach (string name in new[] { "Lite", "Gem", "Fur", "FakeShadow", "Overlay", "Tessellation" })
                if (m.shaderName.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0) return "shader: " + m.shaderName;
            foreach (string name in new[] { "_Color", "_MainTexHSVG", "_MainTex_ScrollRotate" })
                if (!m.Has(name, name == "_Color" ? ShaderPropertyType.Color : ShaderPropertyType.Vector)) return name + ": type/value";
            foreach (string name in new[] { "_MainGradationStrength", "_UseMain2ndTex", "_UseMain3rdTex", "_UseParallax", "_UseAudioLink", "_ShiftBackfaceUV" })
                if (!m.Number(name)) return name + ": type/value";
            if (m.V("_MainTex_ScrollRotate") != Vector4.zero || m.V("_MainTexHSVG").w <= 0) return "_MainTex_ScrollRotate / HSVG.gamma";
            if (m.N("_MainGradationStrength") < 0 || m.N("_MainGradationStrength") > 1) return "_MainGradationStrength";
            foreach (string name in new[] { "_UseParallax", "_UseMainDissolve", "_ShiftBackfaceUV" })
                if (m.values.ContainsKey(name) && (!m.Number(name) || m.N(name) != 0)) return name;
            foreach (string name in new[] { "_DissolveParams", "_AudioLinkVertexStrength" })
                if (m.values.ContainsKey(name) && (!m.Has(name, ShaderPropertyType.Vector) || (name == "_DissolveParams" ? m.V(name).x != 0 : m.N("_UseAudioLink") != 0 && m.V(name) != Vector4.zero))) return name;
            var textures = new List<string> { "_MainTex", "_MainColorAdjustMask" };
            if (m.N("_MainGradationStrength") != 0) textures.Add("_MainGradationTex");
            foreach (string layer in new[] { "2nd", "3rd" })
            {
                float use = m.N("_UseMain" + layer + "Tex");
                if (use == 0) continue;
                if (use != 1) return "_UseMain" + layer + "Tex";
                string p = "_Main" + layer;
                if (!m.Has("_Color" + layer, ShaderPropertyType.Color)) return "_Color" + layer + ": type/value";
                foreach (string suffix in new[] { "Tex_UVMode", "TexAngle", "TexIsDecal", "TexIsLeftOnly", "TexIsRightOnly", "TexShouldCopy", "TexShouldFlipMirror", "TexShouldFlipCopy", "TexIsMSDF", "TexAlphaMode", "Tex_Cull" })
                    if (!m.Number(p + suffix) || m.N(p + suffix) != 0) return p + suffix;
                foreach (string suffix in new[] { "Tex_ScrollRotate", "DissolveParams", "DistanceFade", "TexDecalAnimation", "TexDecalSubParam" })
                    if (!m.Has(p + suffix, ShaderPropertyType.Vector)) return p + suffix + ": type/value";
                if (m.V(p + "Tex_ScrollRotate") != Vector4.zero || m.V(p + "DissolveParams").x != 0 || m.V(p + "DistanceFade").z != 0) return p + ": dynamic";
                var a = m.V(p + "TexDecalAnimation"); var sub = m.V(p + "TexDecalSubParam");
                if (!(a.x == 1 && a.y == 1 && ((a.w > 0 && a.z == 1) || (a.w == 0 && a.z == 0)) && sub.x == 1 && sub.y == 1 && sub.z == 0)) return p + ": atlas";
                if (!m.Number("_AudioLink2Main" + layer) || m.N("_UseAudioLink") != 0 && m.N("_AudioLink2Main" + layer) != 0) return "AudioLink: " + layer;
                if (!m.Number(p + "TexBlendMode") || !m.Number(p + "EnableLighting")) return p + ": blend type/value";
                float mode = m.N(p + "TexBlendMode"), lighting = m.N(p + "EnableLighting");
                if (mode < 0 || mode > 3 || mode != (int)mode) return p + "TexBlendMode: range";
                if (lighting < 0 || lighting > 1) return p + "EnableLighting: range";
                textures.Add(p + "Tex"); textures.Add(p + "BlendMask");
            }
            foreach (string name in textures)
            {
                if (!m.Has(name, ShaderPropertyType.Texture)) return name + ": type/value";
                var t = m.T(name);
                // RenderTextures and custom Texture subclasses may update without a tracked updateCount.
                if (t && (!(t is Texture2D) || t.dimension != TextureDimension.Tex2D)) return name + ": Texture2D required";
            }
            var st = m.values["_MainTex"].st;
            if (Mathf.Abs(st.x) < 1e-8f || Mathf.Abs(st.y) < 1e-8f) return "_MainTex_ST: zero";
            return null;
        }
    }
    // An unchanged-content reimport must also invalidate a sampled image. Dependency
    // hashes alone do not detect that event; this epoch is session-local and never saved.
    internal sealed class NeckDiagnosisAssetChanges : AssetPostprocessor
    {
        private static readonly Dictionary<string, int> revisions = new Dictionary<string, int>();
        internal static int Revision(string path) => revisions.TryGetValue(path, out var value) ? value : 0;
        internal static void Changed(string[] paths)
        { foreach (string path in paths) revisions[path] = Revision(path) + 1; }
        private static void OnPostprocessAllAssets(string[] imported, string[] deleted, string[] moved, string[] movedFrom)
        { Changed(imported); Changed(deleted); Changed(moved); Changed(movedFrom); }
    }
}
