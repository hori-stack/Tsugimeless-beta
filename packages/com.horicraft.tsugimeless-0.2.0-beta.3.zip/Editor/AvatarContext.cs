using System;
using System.Runtime.CompilerServices;
using UnityEngine;

[assembly: InternalsVisibleTo("HoriCraft.Tsugimeless.Editor.Tests")]
namespace HoriCraft.Tsugimeless.Editor
{
    // Window-session state only: no recipe, asset, Base key, or cross-instance sharing.
    [Serializable]
    internal sealed class AvatarContext
    {
        [SerializeField] private GameObject root;
        [SerializeField] private bool hadSelection;
        [SerializeField] private SelectionNotice notice = SelectionNotice.SelectAvatar;
        internal GameObject Root => root;
        internal SelectionNotice Notice => notice;

        internal bool Select(GameObject supplied, bool blocked, bool useSdk = true)
        {
            if (blocked) { notice = SelectionNotice.PlayMode; return false; }
            if (ReferenceEquals(supplied, null)) { Clear(SelectionNotice.SelectAvatar); return true; }
            var result = AvatarSelection.Resolve(supplied, useSdk);
            notice = result.Notice;
            if (!result.Accepted) return false;
            root = result.Root; hadSelection = true;
            return true;
        }

        internal bool Reconcile(bool useSdk = true)
        {
            if (!hadSelection) return false;
            if (root != null)
            {
                var result = AvatarSelection.Resolve(root, useSdk);
                if (result.Accepted && result.Root == root) return false;
            }
            Clear(SelectionNotice.Lost);
            return true;
        }

        internal void Clear(SelectionNotice why)
        {
            root = null; hadSelection = false; notice = why;
        }
    }
}
