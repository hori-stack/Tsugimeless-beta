using System;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    // Ported from the integrated MaterialPon build (feature/seam-v1 Editor/SeamColorSolver.cs).
    internal sealed class SeamColorSolution : IDisposable
    {
        internal SeamColorImage candidate;
        internal float maximumError, meanError;
        internal int unreachablePixels;
        internal bool verified;
        internal string reason;
        public void Dispose() { candidate?.Dispose(); candidate = null; }
    }

    internal static class SeamColorSolver
    {
        internal const float Tolerance = .001f;

        // The candidate remains in source MainTex RGB space. Never feed the
        // evaluated final image into MainTex (that applies tone/layers twice).
        internal static SeamColorSolution Solve(SeamColorEvaluator evaluator, Texture goal)
        {
            if (evaluator == null || !goal) throw new ArgumentNullException();
            var result = new SeamColorSolution();
            try
            {
                result.candidate = evaluator.Candidate(goal);
                using (var check = evaluator.Evaluate(result.candidate.Texture))
                using (var target = new SeamColorImage(goal.width, goal.height, goal))
                {
                    var active = RenderTexture.active;
                    bool srgb = GL.sRGBWrite;
                    try { GL.sRGBWrite = false; Graphics.Blit(goal, target.Texture); }
                    finally { RenderTexture.active = active; GL.sRGBWrite = srgb; }
                    Measure(check.Read(), target.Read(), out result.maximumError, out result.meanError, out result.unreachablePixels);
                }
                result.verified = SeamColorEvaluator.Finite(result.maximumError) && result.maximumError <= Tolerance;
                if (!result.verified) result.reason = L.T("指定した色への到達を確認できません。補正は適用できません。", "The requested color could not be verified. This correction cannot be applied.");
                return result;
            }
            catch { result.Dispose(); throw; }
        }

        internal static void Measure(Color[] actual, Color[] expected, out float maximum, out float mean)
            => Measure(actual, expected, null, out maximum, out mean, out _, out _);

        // unreachable counts pixels whose largest channel difference is above Tolerance.
        internal static void Measure(Color[] actual, Color[] expected, out float maximum, out float mean, out int unreachable)
            => Measure(actual, expected, null, out maximum, out mean, out unreachable, out _);

        // include == null measures every pixel; otherwise only the marked ones (band inside / outside).
        internal static void Measure(Color[] actual, Color[] expected, bool[] include, out float maximum, out float mean, out int unreachable, out int counted)
        {
            if (actual.Length == 0 || actual.Length != expected.Length) throw new ArgumentException("Image sizes must match.");
            if (include != null && include.Length != actual.Length) throw new ArgumentException("Image sizes must match.");
            maximum = 0; mean = 0; unreachable = 0; counted = 0;
            double sum = 0;
            for (int pixel = 0; pixel < actual.Length; pixel++)
            {
                if (include != null && !include[pixel]) continue;
                counted++;
                float worst = 0;
                for (int channel = 0; channel < 3; channel++)
                {
                    float difference = Mathf.Abs(actual[pixel][channel] - expected[pixel][channel]);
                    if (!SeamColorEvaluator.Finite(difference)) { maximum = mean = float.PositiveInfinity; unreachable = counted; return; }
                    worst = Mathf.Max(worst, difference);
                    sum += difference;
                }
                maximum = Mathf.Max(maximum, worst);
                if (worst > Tolerance) unreachable++;
            }
            mean = counted == 0 ? 0 : (float)(sum / (counted * 3L));
        }
    }
}
