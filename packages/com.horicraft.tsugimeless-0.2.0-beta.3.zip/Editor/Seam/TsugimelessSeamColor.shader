Shader "Hidden/HoriCraft/TsugimelessSeamColor"
{
    Properties
    {
        _MainTex ("Source", 2D) = "white" {}
        // lilToon's [lilHDR] drawer uses a regular Color property (gamma-authored RGB).
        _Color ("Multiplier", Color) = (1,1,1,1)
        _MainTexHSVG ("Tone", Vector) = (0,1,1,1)
        _MainColorAdjustMask ("Tone mask", 2D) = "white" {}
        _MainGradationTex ("Gradation", 2D) = "white" {}
        _MainGradationStrength ("Gradation strength", Float) = 0
        _Color2nd ("Layer 2 multiplier", Color) = (1,1,1,1)
        _Main2ndTex ("Layer 2", 2D) = "white" {}
        _Main2ndBlendMask ("Layer 2 mask", 2D) = "white" {}
        _Main2ndTexBlendMode ("Layer 2 blend", Float) = 0
        _Main2ndEnableLighting ("Layer 2 lighting", Float) = 1
        _UseMain2ndTex ("Use layer 2", Float) = 0
        _Color3rd ("Layer 3 multiplier", Color) = (1,1,1,1)
        _Main3rdTex ("Layer 3", 2D) = "white" {}
        _Main3rdBlendMask ("Layer 3 mask", 2D) = "white" {}
        _Main3rdTexBlendMode ("Layer 3 blend", Float) = 0
        _Main3rdEnableLighting ("Layer 3 lighting", Float) = 1
        _UseMain3rdTex ("Use layer 3", Float) = 0
        _GoalTex ("Goal", 2D) = "black" {}
        _OriginalMainTex ("Underlying image", 2D) = "white" {}
        _CandidateLayer ("Layer to solve", Float) = 0
    }
    CGINCLUDE
    #include "UnityCG.cginc"
    #include "../NeckColorMath.hlsl"
    Texture2D _MainTex, _MainColorAdjustMask, _MainGradationTex, _OriginalMainTex;
    Texture2D _Main2ndTex, _Main2ndBlendMask, _Main3rdTex, _Main3rdBlendMask, _GoalTex;
    SamplerState sampler_MainTex;
    SamplerState sampler_OriginalMainTex;
    SamplerState seam_linear_clamp_sampler;
    float4 _Color, _Color2nd, _Color3rd, _MainTexHSVG, _SourceST, _Main2ndTex_ST, _Main3rdTex_ST;
    float _MainGradationStrength, _UseMain2ndTex, _UseMain3rdTex;
    float _Main2ndTexBlendMode, _Main3rdTexBlendMode, _Main2ndEnableLighting, _Main3rdEnableLighting;
    float _CandidateLayer;
    struct SeamContext { float mask; float4 layer2, layer3, underlying; };
    SeamContext Context(float2 uv)
    {
        SeamContext c;
        c.underlying = _OriginalMainTex.SampleLevel(sampler_OriginalMainTex, uv, 0);
        c.mask = _MainColorAdjustMask.SampleLevel(sampler_OriginalMainTex, uv, 0).r;
        float2 uv0 = (uv - _SourceST.zw) / _SourceST.xy;
        c.layer2 = _Color2nd * _Main2ndTex.SampleLevel(sampler_OriginalMainTex, uv0 * _Main2ndTex_ST.xy + _Main2ndTex_ST.zw, 0);
        c.layer3 = _Color3rd * _Main3rdTex.SampleLevel(sampler_OriginalMainTex, uv0 * _Main3rdTex_ST.xy + _Main3rdTex_ST.zw, 0);
        c.layer2.a *= _Main2ndBlendMask.SampleLevel(sampler_OriginalMainTex, uv, 0).r * _UseMain2ndTex;
        c.layer3.a *= _Main3rdBlendMask.SampleLevel(sampler_OriginalMainTex, uv, 0).r * _UseMain3rdTex;
        return c;
    }
    float3 Gradation(float3 color)
    {
        if (_MainGradationStrength == 0) return color;
        #ifndef UNITY_COLORSPACE_GAMMA
            color = SeamLinearToSRGB(color);
        #endif
        float3 mapped = float3(
            _MainGradationTex.SampleLevel(seam_linear_clamp_sampler, float2(color.r, .5), 0).r,
            _MainGradationTex.SampleLevel(seam_linear_clamp_sampler, float2(color.g, .5), 0).g,
            _MainGradationTex.SampleLevel(seam_linear_clamp_sampler, float2(color.b, .5), 0).b);
        #ifndef UNITY_COLORSPACE_GAMMA
            color = SeamSRGBToLinear(color);
            mapped = SeamSRGBToLinear(mapped);
        #endif
        return lerp(color, mapped, _MainGradationStrength);
    }
    float3 Evaluate(float3 input, SeamContext c)
    {
        if (_CandidateLayer == 2)
        {
            // Alpha, masks and blend settings stay fixed; only this texture's RGB changes.
            c.layer2.rgb = input * _Color2nd.rgb;
            input = c.underlying.rgb;
        }
        float3 color = lerp(input, Gradation(SeamTone(input, _MainTexHSVG)), c.mask) * _Color.rgb;
        color = SeamBlend(color, c.layer2.rgb, c.layer2.a * _Main2ndEnableLighting, (int)_Main2ndTexBlendMode);
        color = SeamBlend(color, c.layer3.rgb, c.layer3.a * _Main3rdEnableLighting, (int)_Main3rdTexBlendMode);
        color = SeamBlend(color, c.layer2.rgb, c.layer2.a * (1-_Main2ndEnableLighting), (int)_Main2ndTexBlendMode);
        return SeamBlend(color, c.layer3.rgb, c.layer3.a * (1-_Main3rdEnableLighting), (int)_Main3rdTexBlendMode);
    }
    float4 Forward(v2f_img i) : SV_Target
    {
        float4 source = _MainTex.SampleLevel(sampler_MainTex, i.uv, 0);
        SeamContext c = Context(i.uv);
        return float4(Evaluate(source.rgb, c), (_CandidateLayer == 2 ? c.underlying.a : source.a) * _Color.a);
    }
    float Error3(float3 a, float3 b) { float3 d = abs(a-b); return max(d.r, max(d.g,d.b)); }
    float3 Derivative(float3 x, float3 axis, SeamContext c)
    {
        float3 a = saturate(x + axis * .001), b = saturate(x - axis * .001);
        return (Evaluate(a,c) - Evaluate(b,c)) / max(dot(a-b,axis), 1e-6);
    }
    float4 Solve(v2f_img i) : SV_Target
    {
        float4 source = _MainTex.SampleLevel(sampler_MainTex, i.uv, 0);
        float3 goal = _GoalTex.SampleLevel(seam_linear_clamp_sampler, i.uv, 0).rgb;
        SeamContext c = Context(i.uv);
        float3 best = saturate(source.rgb);
        float error = Error3(Evaluate(best,c),goal);
        [loop] for (int attempt=0; attempt<2 && error>0.00005; attempt++)
        {
            float3 x = attempt==0 ? best : float3(.25,.25,.25);
            [loop] for (int iteration=0; iteration<20; iteration++)
            {
                float3 residual = Evaluate(x,c)-goal;
                float current = max(abs(residual.x),max(abs(residual.y),abs(residual.z)));
                if (current < error) { error=current; best=x; }
                if (current < 0.00005) break;
                float3 a=Derivative(x,float3(1,0,0),c), b=Derivative(x,float3(0,1,0),c), d=Derivative(x,float3(0,0,1),c);
                float determinant = dot(a,cross(b,d));
                float3 step;
                if (abs(determinant)>1e-8)
                    step=float3(dot(residual,cross(b,d)),dot(a,cross(residual,d)),dot(a,cross(b,residual)))/determinant;
                else step=float3(dot(a,residual),dot(b,residual),dot(d,residual))/(dot(a,a)+dot(b,b)+dot(d,d)+.0001);
                step=clamp(step,-.25,.25);
                bool improved=false;
                [unroll] for (int searchIndex=0; searchIndex<5; searchIndex++)
                {
                    float3 next=saturate(x-step*exp2(-searchIndex));
                    if (Error3(Evaluate(next,c),goal)<current) { x=next; improved=true; break; }
                }
                if (!improved) break;
            }
            float last=Error3(Evaluate(x,c),goal);
            if(last<error) { error=last; best=x; }
        }
        return float4(best,source.a);
    }
    ENDCG
    SubShader
    {
        Cull Off ZWrite Off ZTest Always
        Pass
        {
            CGPROGRAM
            #pragma target 4.5
            #pragma vertex vert_img
            #pragma fragment Forward
            ENDCG
        }
        Pass
        {
            CGPROGRAM
            #pragma target 4.5
            #pragma vertex vert_img
            #pragma fragment Solve
            ENDCG
        }
    }
    Fallback Off
}
