using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace HoriCraft.Tsugimeless.Editor
{
    // Ported from the integrated MaterialPon build (feature/seam-v1 Editor/SeamColorEvaluator.cs).
    // Image UV, mip 0, static UV0 layers. This is the specified unlit base-color
    // model, not a replacement for the full lilToon forward renderer.
    internal sealed class SeamColorEvaluator : IDisposable
    {
        internal const string ShaderName = "Hidden/HoriCraft/TsugimelessSeamColor";
        internal const string MainTexture = "_MainTex", SecondTexture = "_Main2ndTex";
        private Material evaluation;
        internal Texture Source { get; private set; }
        private SeamColorEvaluator() { }

        internal static bool TryCreate(Material source, out SeamColorEvaluator result, out string reason, string textureProperty = MainTexture)
        {
            result = null;
            reason = Validate(source);
            if (reason != null) return false;
            if (!KnownTexture(textureProperty)) { reason = Unsupported(textureProperty); return false; }
            if (textureProperty == SecondTexture && (reason = SecondLayerReason(source)) != null) return false;
            var shader = Shader.Find(ShaderName);
            if (!shader || !shader.isSupported || ShaderUtil.ShaderHasError(shader) || !SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.ARGBFloat)
                || !SystemInfo.SupportsTextureFormat(TextureFormat.RGBAFloat) || SystemInfo.graphicsDeviceType == GraphicsDeviceType.Null)
            {
                reason = L.T("この環境では色評価に必要なGPU機能を使えません。", "The GPU features required for color evaluation are unavailable.");
                return false;
            }
            var material = new Material(shader) { hideFlags = HideFlags.HideAndDontSave };
            try
            {
                foreach (string name in new[] { "_Color", "_Color2nd", "_Color3rd" }) material.SetColor(name, source.GetColor(name));
                material.SetVector("_MainTexHSVG", source.GetVector("_MainTexHSVG"));
                foreach (string name in new[] { "_MainGradationStrength", "_UseMain2ndTex", "_UseMain3rdTex", "_Main2ndTexBlendMode", "_Main3rdTexBlendMode", "_Main2ndEnableLighting", "_Main3rdEnableLighting" })
                    material.SetFloat(name, source.GetFloat(name));
                foreach (string name in new[] { "_MainTex", "_MainColorAdjustMask", "_MainGradationTex", "_Main2ndTex", "_Main3rdTex", "_Main2ndBlendMask", "_Main3rdBlendMask" })
                {
                    material.SetTexture(name, source.GetTexture(name) ? source.GetTexture(name) : Texture2D.whiteTexture);
                    material.SetTextureScale(name, source.GetTextureScale(name));
                    material.SetTextureOffset(name, source.GetTextureOffset(name));
                }
                var scale = source.GetTextureScale("_MainTex");
                var offset = source.GetTextureOffset("_MainTex");
                material.SetVector("_SourceST", new Vector4(scale.x, scale.y, offset.x, offset.y));
                // Graphics.Blit binds its input to _MainTex. Keep the underlying image separately
                // when the solver is changing the second layer's RGB instead.
                material.SetTexture("_OriginalMainTex", material.GetTexture(MainTexture));
                material.SetFloat("_CandidateLayer", textureProperty == SecondTexture ? 2 : 0);
                result = new SeamColorEvaluator { evaluation = material, Source = material.GetTexture(textureProperty) };
                return true;
            }
            catch { UnityEngine.Object.DestroyImmediate(material); throw; }
        }

        // The integrated build carried its own Validate. This package already states the same
        // rules once in LilToonMaterialRead.ColorReason, so the wrapper only adds the sentence
        // the user reads. Rule differences are listed in Documentation~/plans/2026-09-19_neck-only-n01.md.
        internal static string Validate(Material source)
        {
            if (!source || !source.shader) return Unsupported("material");
            string reason = LilToonMaterialRead.ColorReason(LilToonMaterialRead.Capture(source));
            return reason == null ? null : Unsupported(reason);
        }

        private static string Unsupported(string detail) => L.T("この材質の色経路は未対応です。", "This material color path is unsupported.") + " " + detail;
        internal static bool KnownTexture(string property) => property == MainTexture || property == SecondTexture;
        internal static bool IdentityUv(Material material, string property)
            => material.GetTextureScale(property) == Vector2.one && material.GetTextureOffset(property) == Vector2.zero;

        internal static string SecondLayerReason(Material material)
        {
            string reason = Validate(material);
            if (reason != null) return reason;
            if (material.GetFloat("_UseMain2ndTex") != 1 || !material.GetTexture(SecondTexture)
                || material.GetFloat("_Main2ndTexBlendMode") != 0 || material.GetFloat("_UseMain3rdTex") != 0
                || !IdentityUv(material, MainTexture) || !IdentityUv(material, SecondTexture))
                return L.T("重ねた肌画像のこの使い方には、まだ対応していません。2ndの通常合成・画像の拡縮や移動なし・3rdなしの場合に補正できます。",
                    "This layered skin setup is not supported yet. Correction supports a normal-blend second layer, without texture scaling or offsets, and without a third layer.");
            return null;
        }
        internal static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);

        internal SeamColorImage Evaluate(Texture input = null) => Render(input ? input : Source, null, 0);
        internal SeamColorImage Candidate(Texture goal) => Render(Source, goal, 1);

        private SeamColorImage Render(Texture input, Texture goal, int pass)
        {
            if (!evaluation) throw new ObjectDisposedException(nameof(SeamColorEvaluator));
            if (!input || (goal && (goal.width != input.width || goal.height != input.height))) throw new ArgumentException("Image sizes must match.");
            var result = new SeamColorImage(input.width, input.height, input);
            var active = RenderTexture.active;
            bool srgb = GL.sRGBWrite;
            try
            {
                GL.sRGBWrite = false;
                if (goal) evaluation.SetTexture("_GoalTex", goal);
                Graphics.Blit(input, result.Texture, evaluation, pass);
                return result;
            }
            catch { result.Dispose(); throw; }
            finally { RenderTexture.active = active; GL.sRGBWrite = srgb; }
        }

        public void Dispose()
        {
            if (evaluation) UnityEngine.Object.DestroyImmediate(evaluation);
            evaluation = null;
        }
    }

    internal sealed class SeamColorImage : IDisposable
    {
        internal RenderTexture Texture { get; private set; }
        internal SeamColorImage(int width, int height, Texture sampler)
        {
            Texture = new RenderTexture(width, height, 0, RenderTextureFormat.ARGBFloat, RenderTextureReadWrite.Linear)
            {
                hideFlags = HideFlags.HideAndDontSave, useMipMap = false, filterMode = sampler.filterMode,
                wrapModeU = sampler.wrapModeU, wrapModeV = sampler.wrapModeV, anisoLevel = 0
            };
            if (!Texture.Create()) { Dispose(); throw new InvalidOperationException("Float render target creation failed."); }
        }
        internal Color[] Read()
        {
            if (!Texture) throw new ObjectDisposedException(nameof(SeamColorImage));
            var active = RenderTexture.active;
            Texture2D readback = null;
            try
            {
                RenderTexture.active = Texture;
                readback = new Texture2D(Texture.width, Texture.height, TextureFormat.RGBAFloat, false, true) { hideFlags = HideFlags.HideAndDontSave };
                readback.ReadPixels(new Rect(0, 0, Texture.width, Texture.height), 0, 0, false);
                readback.Apply(false);
                return readback.GetPixels();
            }
            finally
            {
                RenderTexture.active = active;
                if (readback) UnityEngine.Object.DestroyImmediate(readback);
            }
        }
        // Hands the render target to a new owner without releasing it here.
        internal RenderTexture Detach() { var value = Texture; Texture = null; return value; }
        public void Dispose()
        {
            if (Texture) { Texture.Release(); UnityEngine.Object.DestroyImmediate(Texture); }
            Texture = null;
        }
    }
}
