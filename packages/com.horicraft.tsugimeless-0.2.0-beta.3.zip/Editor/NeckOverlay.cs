using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace HoriCraft.Tsugimeless.Editor
{
    internal sealed class NeckOverlay
    {
        private NeckResult result;
        private Vector3 center;
        private Vector3[] face = Array.Empty<Vector3>(), body = Array.Empty<Vector3>();
        private readonly Vector3[] segment = new Vector3[2];
        internal bool Visible { get; private set; }
        internal void Show(NeckResult value)
        {
            if (Visible && ReferenceEquals(result, value)) return;
            Hide(); result = value; Visible = value != null;
            if (Visible)
            {
                var pairs = value.Candidate ? value.Pairs : value.rejected;
                int count = value.Candidate ? pairs.Count : Mathf.Min(1000, pairs.Count);
                face = new Vector3[count]; body = new Vector3[count]; center = Vector3.zero;
                for (int i = 0; i < count; i++) { face[i] = pairs[i].face.position; body[i] = pairs[i].body.position; center += (face[i] + body[i]) * (.5f / count); }
            }
            if (Visible) SceneView.duringSceneGui += Draw;
            SceneView.RepaintAll();
        }
        internal void Hide()
        {
            SceneView.duringSceneGui -= Draw; result = null; Visible = false; face = body = Array.Empty<Vector3>(); SceneView.RepaintAll();
        }
        private void Draw(SceneView view)
        {
            if (!Visible || result == null || face.Length == 0 || view.camera == null || Event.current.type != EventType.Repaint) return;
            var oldDepth = Handles.zTest;
            try
            {
                // The diagnostic is intentionally drawn over hair/skin. The far half uses a fainter stroke.
                Handles.zTest = CompareFunction.Always;
                using (new Handles.DrawingScope(Matrix4x4.identity))
                {
                if (result.Candidate)
                {
                    // Far half first, so its crossing never obscures the near half.
                    for (int pass = 0; pass < 2; pass++)
                    {
                        for (int i = 0; i < face.Length; i++)
                        {
                            var a = face[i]; var b = face[(i + 1) % face.Length];
                            if (Far(view, a, b) != (pass == 0)) continue;
                            Stroke(a, b, pass == 0 ? 3 : 9, new Color(0, 1, 1, pass == 0 ? .3f : 1));
                        }
                        for (int i = 0; i < body.Length; i++)
                        {
                            var a = body[i]; var b = body[(i + 1) % body.Length];
                            if (Far(view, a, b) != (pass == 0)) continue;
                            Dashed(view, a, b, pass == 0 ? 2 : 5, new Color(1, .92f, .05f, pass == 0 ? .3f : 1));
                        }
                    }
                }
                else
                {
                    for (int i = 0; i < face.Length; i++)
                    {
                        float size = HandleUtility.GetHandleSize(face[i]) * .035f;
                        Handles.color = Color.black; Handles.DotHandleCap(0, face[i], Quaternion.identity, size * 1.5f, EventType.Repaint);
                        Handles.color = new Color(1, .5f, 0, 1); Handles.DotHandleCap(0, face[i], Quaternion.identity, size, EventType.Repaint);
                    }
                }
                }
            }
            finally { Handles.zTest = oldDepth; }
        }
        private bool Far(SceneView view, Vector3 a, Vector3 b)
        {
            var towardCamera = view.camera.orthographic ? -view.camera.transform.forward : view.camera.transform.position - center;
            return Vector3.Dot((a + b) * .5f - center, towardCamera) < 0;
        }
        private void Stroke(Vector3 a, Vector3 b, float width, Color color)
        {
            segment[0] = a; segment[1] = b;
            Handles.color = new Color(0, 0, 0, color.a * .9f); Handles.DrawAAPolyLine(width + 4, segment);
            Handles.color = color; Handles.DrawAAPolyLine(width, segment);
        }
        private void Dashed(SceneView view, Vector3 a, Vector3 b, float width, Color color)
        {
            if (view.camera.WorldToViewportPoint(a).z <= 0 || view.camera.WorldToViewportPoint(b).z <= 0) return;
            float length = Vector2.Distance(HandleUtility.WorldToGUIPoint(a), HandleUtility.WorldToGUIPoint(b));
            if (!NeckSnapshot.Finite(length) || length < .1f) return;
            int count = Mathf.Min(128, Mathf.CeilToInt(length / 14));
            for (int j = 0; j < count; j++)
            {
                float start = j * 14f / length, end = Mathf.Min((j * 14f + 7) / length, 1);
                if (start >= 1) break;
                Stroke(Vector3.Lerp(a, b, start), Vector3.Lerp(a, b, end), width, color);
            }
        }
    }
}
