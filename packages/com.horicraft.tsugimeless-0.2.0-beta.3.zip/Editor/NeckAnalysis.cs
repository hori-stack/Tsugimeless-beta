using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    internal enum NeckIssue { None, Targets, OverlappingSlots, Bones, Scale, Geometry, Animation, NoContacts, NoLoop, MultipleLoops, Stale, Cancelled, Exception, BonePose, MissingBone, OutsideBones, BoneWeights, OutsideNeckBand }
    internal enum NeckState { Idle, Running, Candidate, Ambiguous, NotFound, Invalid, Stale, Cancelled }
    internal sealed class NeckPoint
    {
        internal int[] vertices;
        internal int triangle = -1, slot = -1;
        internal NeckUvAlias[] aliases = Array.Empty<NeckUvAlias>();
        internal Vector3 weights;
        internal Vector3 position;
        internal Vector2 uv;
        internal bool hasUv;
    }
    internal sealed class NeckUvAlias { internal int vertex, corner; internal Vector2 uv; }
    internal sealed class NeckPair
    {
        internal NeckPoint face, body;
        internal int[] sourceAliases;
        internal float distanceMm, normalAngle;
        internal bool reverse;
    }
    internal sealed class NeckTrace
    {
        internal bool reverse, boundary;
        internal int within5mm, inBand, boundaryNodes, loops;
        internal float thresholdMm;
        public override string ToString() => L.F("{0}／{1}：5 mm内 {2}・位置帯内 {3}・開辺の点 {4}・輪 {5}・{6:F1} mm", "{0} / {1}: near 5 mm {2}, in band {3}, open-edge nodes {4}, loops {5}, {6:F1} mm",
            reverse ? L.T("体→顔", "body → face") : L.T("顔→体", "face → body"), boundary ? L.T("開いた縁", "open edges") : L.T("近接する実辺", "contact graph"), within5mm, inBand, boundaryNodes, loops, thresholdMm);
    }
    internal sealed class NeckResult
    {
        internal NeckState state = NeckState.NotFound;
        internal NeckIssue issue = NeckIssue.NoLoop;
        internal string stamp;
        internal float thresholdMm, meanNormalAngle, maxNormalAngle;
        internal int initialCandidates;
        internal int candidates => traces.Where(t => t.boundary).Sum(t => t.within5mm);
        internal bool usedPreset;
        internal NeckExcludedFace[] excludedFace = Array.Empty<NeckExcludedFace>(), excludedBody = Array.Empty<NeckExcludedFace>();
        internal readonly List<List<NeckPair>> loops = new List<List<NeckPair>>();
        internal readonly List<NeckPair> rejected = new List<NeckPair>();
        internal readonly List<NeckTrace> traces = new List<NeckTrace>();
        internal bool Candidate => state == NeckState.Candidate;
        internal List<NeckPair> Pairs => loops.Count == 1 ? loops[0] : rejected;
        internal bool HasUv => Candidate && Pairs.All(p => p.face.hasUv && p.body.hasUv);
    }
    internal static class NeckAnalysis
    {
        internal static string[] SharedMaterials(NeckTargets targets)
        {
            if (targets == null || !targets.Valid(out _)) return Array.Empty<string>();
            var skin = targets.FaceSlots.Select(s => targets.Face.sharedMaterials[s]).Concat(targets.BodySlots.Select(s => targets.Body.sharedMaterials[s])).Distinct();
            var lines = new List<string>();
            foreach (var material in skin)
            {
                var uses = new List<string>();
                foreach (var renderer in targets.Root.GetComponentsInChildren<Renderer>(true))
                    for (int i = 0; i < renderer.sharedMaterials.Length; i++)
                        if (renderer.sharedMaterials[i] == material) uses.Add(NeckTargets.RelativePath(targets.Root.transform, renderer.transform) + " [" + i + "]");
                if (uses.Count > 1) lines.Add(material.name + ": " + string.Join(", ", uses));
            }
            return lines.ToArray();
        }
        internal static string Reason(NeckIssue issue)
        {
            switch (issue)
            {
                case NeckIssue.None: return L.T("首の候補が1つ見つかりました。線の場所を確認してください。", "One neck candidate was found. Check the lines in Scene view.");
                case NeckIssue.Targets: return L.T("顔・体と肌の材質欄を確認してください。", "Check the face, body and skin material slots.");
                case NeckIssue.OverlappingSlots: return L.T("顔と体に同じ描画部品の同じ材質欄は指定できません。", "Face and body cannot use the same slot of the same renderer.");
                case NeckIssue.Bones: return L.T("胸・首・頭を動かす骨を特定できません。アバター全体と、顔・体の指定を確認してください。", "The bones that move the chest, neck and head could not be identified. Check the whole avatar and the face/body selection.");
                case NeckIssue.BonePose: return L.T("胸・首・頭の位置を正しく読み取れません。姿勢や拡大率を確認してください。", "Chest, neck or head positions cannot be read correctly. Check the pose and scale.");
                case NeckIssue.MissingBone: return L.T("顔や体を動かすための骨が見つかりません。顔・体の指定と、元のアバターの状態を確認してください。", "A bone needed to deform the face or body is missing. Check the face/body selection and the original avatar state.");
                case NeckIssue.OutsideBones: return L.T("顔や体が、選んだアバターの外にある骨を参照しています。アバターと顔・体の指定を確認してください。", "The face or body references bones outside the selected avatar. Check the avatar and face/body selection.");
                case NeckIssue.BoneWeights: return L.T("顔や体と骨のつながりを正しく読み取れません。顔・体の指定を確認してください。", "The connections between the face/body and bones cannot be read correctly. Check the face/body selection.");
                case NeckIssue.Scale: return L.T("0や負の拡大率、計算できない変換があります。", "A zero, negative or singular scale is unsupported.");
                case NeckIssue.Geometry: return L.T("面・法線など、形の情報が不足しているか不正です。", "Geometry or normals are missing or invalid.");
                case NeckIssue.Animation: return L.T("PlayとAnimationのプレビューを停止してください。", "Stop Play Mode and Animation preview.");
                case NeckIssue.NoContacts: return L.T("顔と体の間に、首の境目として比べられる場所が見つかりません。顔・体の指定と、離れすぎていないかを確認してください。", "No comparable neck boundary was found between the face and body. Check the face/body selection and whether they are too far apart.");
                case NeckIssue.OutsideNeckBand: return L.T("骨から調べた首元と、顔・体が近い場所の位置が合いません。顔・体の指定と、改変した形を確認してください。", "The neck area inferred from the bones does not match the nearby face/body positions. Check the face/body selection and modified shape.");
                case NeckIssue.NoLoop: return L.T("顔と体が近い場所はありますが、首の境目を一周つなげられませんでした。顔・体の指定と、首の形を確認してください。", "Some face and body positions are close, but a complete neck boundary could not be connected. Check the face/body selection and neck shape.");
                case NeckIssue.MultipleLoops: return L.T("首の候補が複数あります。自動では選びません。", "Multiple neck candidates remain. None is chosen automatically.");
                case NeckIssue.Stale: return L.T("形や対象が変わりました。もう一度調べてください。", "The shape or target changed. Run detection again.");
                case NeckIssue.Cancelled: return L.T("検出を中断しました。途中の結果は使いません。", "Detection was cancelled. Partial results are not used.");
                default: return L.T("首の検出を完了できませんでした。詳細を確認してください。", "Neck detection could not finish. Check the details.");
            }
        }
    }
}
