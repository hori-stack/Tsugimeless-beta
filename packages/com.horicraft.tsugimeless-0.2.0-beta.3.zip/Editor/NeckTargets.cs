using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    internal enum NeckBinding { Generic, Matched, Mismatch, Manual, InvalidCatalog, Ambiguous }
    internal sealed class NeckTargets
    {
        internal readonly GameObject Root;
        internal Renderer Face, Body;
        internal int[] FaceSlots = Array.Empty<int>(), BodySlots = Array.Empty<int>();
        internal NeckBinding Binding;
        internal AvatarDefinition Definition;
        internal string DefinitionId;
        internal bool Confirmed;
        internal NeckTargets(GameObject root, AvatarDefinitionFile catalog, string id)
        {
            Root = root; DefinitionId = id ?? "";
            if (!AvatarDefinitions.Valid(catalog)) { Binding = NeckBinding.InvalidCatalog; return; }
            if (!string.IsNullOrEmpty(id))
            {
                Definition = catalog.avatars.SingleOrDefault(d => d.id == id);
                if (Definition == null) { Binding = NeckBinding.InvalidCatalog; return; }
                Face = AvatarDefinitions.ResolvePath(root, Definition.face.rendererPath);
                Body = AvatarDefinitions.ResolvePath(root, Definition.body.rendererPath);
                FaceSlots = (int[])Definition.face.skinSlots.Clone(); BodySlots = (int[])Definition.body.skinSlots.Clone();
                bool exact = AvatarDefinitions.Matches(Face, Definition.face) && AvatarDefinitions.Matches(Body, Definition.body);
                Binding = exact && Valid(out _) ? NeckBinding.Matched : NeckBinding.Mismatch;
                Confirmed = Binding == NeckBinding.Matched;
            }
            else if (!MatchAutomatic(catalog)) Suggest();
        }
        // Match identity and topology, not hierarchy names. A second valid pair (even
        // under the same definition) is ambiguous; never silently use the first one.
        private bool MatchAutomatic(AvatarDefinitionFile catalog)
        {
            if (Root == null) return false;
            var renderers = Root.GetComponentsInChildren<Renderer>(true);
            AvatarDefinition found = null; Renderer face = null, body = null;
            foreach (var definition in catalog.avatars)
            {
                var faces = renderers.Where(r => ValidPart(Root, r, definition.face.skinSlots)
                    && AvatarDefinitions.Matches(r, definition.face)).ToArray();
                var bodies = renderers.Where(r => ValidPart(Root, r, definition.body.skinSlots)
                    && AvatarDefinitions.Matches(r, definition.body)).ToArray();
                foreach (var f in faces)
                    foreach (var b in bodies)
                    {
                        if (f == b && definition.face.skinSlots.Intersect(definition.body.skinSlots).Any()) continue;
                        if (found != null) { Binding = NeckBinding.Ambiguous; return true; }
                        found = definition; face = f; body = b;
                    }
            }
            if (found == null) return false;
            Definition = found; DefinitionId = found.id; Face = face; Body = body;
            FaceSlots = (int[])found.face.skinSlots.Clone(); BodySlots = (int[])found.body.skinSlots.Clone();
            Binding = NeckBinding.Matched; Confirmed = true; return true;
        }
        internal NeckTargets(GameObject root, Renderer face, int[] faceSlots, Renderer body, int[] bodySlots)
        { Root = root; Face = face; Body = body; FaceSlots = faceSlots; BodySlots = bodySlots; Binding = NeckBinding.Manual; Confirmed = true; }
        internal bool SetManual(bool isFace, Renderer renderer, int[] slots)
        {
            if (slots == null) return false;
            if (renderer != null && (Root == null || !renderer.transform.IsChildOf(Root.transform)
                || AvatarSelection.SceneProblem(renderer.gameObject) != SelectionNotice.None || MeshOf(renderer) == null
                || (slots.Length > 0 && !ValidPart(Root, renderer, slots)))) return false;
            if (renderer != null && renderer == (isFace ? Body : Face) && slots.Intersect(isFace ? BodySlots : FaceSlots).Any()) return false;
            if (isFace) { Face = renderer; FaceSlots = renderer == null ? Array.Empty<int>() : (int[])slots.Clone(); }
            else { Body = renderer; BodySlots = renderer == null ? Array.Empty<int>() : (int[])slots.Clone(); }
            Binding = NeckBinding.Manual; Confirmed = false; return true;
        }
        internal bool Confirm() { Confirmed = Valid(out _); if (Confirmed && Binding != NeckBinding.Matched) Binding = NeckBinding.Manual; return Confirmed; }
        internal bool Valid(out NeckIssue issue)
        {
            issue = NeckIssue.Targets;
            if (Root == null || AvatarSelection.SceneProblem(Root) != SelectionNotice.None
                || !ValidPart(Root, Face, FaceSlots) || !ValidPart(Root, Body, BodySlots)) return false;
            if (Face == Body && FaceSlots.Intersect(BodySlots).Any()) { issue = NeckIssue.OverlappingSlots; return false; }
            issue = NeckIssue.None; return true;
        }
        internal static bool ValidPart(GameObject root, Renderer renderer, int[] slots)
        {
            if (root == null || renderer == null || !renderer.transform.IsChildOf(root.transform)
                || AvatarSelection.SceneProblem(renderer.gameObject) != SelectionNotice.None || slots == null || slots.Length == 0) return false;
            var mesh = MeshOf(renderer); if (mesh == null) return false;
            var materials = renderer.sharedMaterials;
            return slots.Distinct().Count() == slots.Length && slots.All(s => s >= 0 && s < mesh.subMeshCount
                && s < materials.Length && materials[s] != null && mesh.GetTopology(s) == MeshTopology.Triangles && mesh.GetIndexCount(s) > 0);
        }
        internal static Mesh MeshOf(Renderer renderer)
        {
            if (renderer == null) return null;
            if (renderer is SkinnedMeshRenderer skin) return skin.sharedMesh;
            if (!(renderer is MeshRenderer)) return null;
            // Unity's missing-component object is not necessarily a CLR null. Use Unity's null check before reading it.
            var filter = renderer.GetComponent<MeshFilter>();
            return filter != null ? filter.sharedMesh : null;
        }
        internal static string RelativePath(Transform root, Transform target)
        {
            if (root == null || target == null || !target.IsChildOf(root)) return null;
            var parts = new List<string>(); for (var t = target; t != root; t = t.parent) parts.Add(t.name);
            parts.Reverse(); return string.Join("/", parts);
        }
        internal static int[] SuggestedSlots(GameObject root, Renderer renderer)
        {
            if (renderer == null) return Array.Empty<int>();
            return Enumerable.Range(0, renderer.sharedMaterials.Length).Where(i =>
            {
                var m = renderer.sharedMaterials[i]; if (m == null || !ValidPart(root, renderer, new[] { i })) return false;
                var n = m.name.ToLowerInvariant();
                return new[] { "skin", "body", "face", "肌", "素体" }.Any(n.Contains)
                    && !new[] { "eye", "brow", "hair", "teeth", "歯", "目", "眉", "髪" }.Any(n.Contains);
            }).ToArray();
        }
        private void Suggest()
        {
            Binding = NeckBinding.Generic;
            if (Root == null) return;
            var renderers = Root.GetComponentsInChildren<Renderer>(true).Where(r => SuggestedSlots(Root, r).Length > 0).ToArray();
            NeckSnapshot.TryBones(this, out var chest, out _, out var head);
            var faces = new List<Renderer>(); var bodies = new List<Renderer>();
            foreach (var renderer in renderers)
            {
                bool face = false, body = false;
                if (renderer is SkinnedMeshRenderer skin && head != null && chest != null)
                {
                    int hi = Array.IndexOf(skin.bones, head), ci = Array.IndexOf(skin.bones, chest);
                    var weights = skin.sharedMesh.boneWeights;
                    if (weights.Length > 0)
                    {
                        double hw = weights.Average(w => Weight(w, hi)), cw = weights.Average(w => Weight(w, ci));
                        face = hw > .5; body = cw > .1 && hw < .25;
                    }
                }
                if (!face && !body)
                {
                    string n = renderer.name.ToLowerInvariant();
                    face = n.Contains("face") || n.Contains("顔");
                    body = !face && (n.Contains("body") || n.Contains("素体"));
                }
                if (face) faces.Add(renderer); if (body) bodies.Add(renderer);
            }
            if (faces.Count == 1) { Face = faces[0]; FaceSlots = SuggestedSlots(Root, Face); }
            if (bodies.Count == 1) { Body = bodies[0]; BodySlots = SuggestedSlots(Root, Body); }
            if (faces.Count > 1 || bodies.Count > 1) Binding = NeckBinding.Ambiguous;
            Confirmed = false; // Evidence suggests targets; the owner confirms the selected slots before measurement.
        }
        private static float Weight(BoneWeight w, int index) => index < 0 ? 0 :
            (w.boneIndex0 == index ? w.weight0 : 0) + (w.boneIndex1 == index ? w.weight1 : 0)
            + (w.boneIndex2 == index ? w.weight2 : 0) + (w.boneIndex3 == index ? w.weight3 : 0);
    }
}
