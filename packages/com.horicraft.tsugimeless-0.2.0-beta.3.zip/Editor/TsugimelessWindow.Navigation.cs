using System.Collections.Generic;
using UnityEditor.UIElements;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    public sealed partial class TsugimelessWindow
    {
        internal void Navigate(WorkflowPage destination)
        {
            if (IsUtilityPage(destination) && !IsUtilityPage(page))
                lastWorkPage = page == WorkflowPage.Seam ? WorkflowPage.Seam : WorkflowPage.Start;
            if (page == WorkflowPage.Seam && destination != WorkflowPage.Seam) OnSeamPageLeft();
            page = destination;
            if (page != WorkflowPage.Neck || !diagnosis.EnsureCurrent()) measurement.Hide();
            UpdateNeckVisibility(); RenderBody();
        }

        private void RenderBody()
        {
            if (body == null) return;
            body.Clear(); body.SetEnabled(!playBlocked);
            workflowFooter?.Clear();
            bool utility = IsUtilityPage(page);
            if (avatarCard != null) avatarCard.style.display = page == WorkflowPage.Seam || utility ? DisplayStyle.None : DisplayStyle.Flex;
            if (workflowFooter != null) workflowFooter.style.display = utility ? DisplayStyle.None : DisplayStyle.Flex;
            if (workflowProgress != null) workflowProgress.style.display = utility ? DisplayStyle.None : DisplayStyle.Flex;
            BuildMainTabs();
            UpdateWorkflowProgress();
            if (page == WorkflowPage.Settings) { BuildSettingsPage(); return; }
            if (page == WorkflowPage.History) { BuildHistoryPage(); return; }
            if (page == WorkflowPage.Start)
            {
                BuildSeamSelection();
                return;
            }
            if (page == WorkflowPage.Seam) { BuildSeamPage(); return; }
            body.Add(TsugimelessStyles.ColoredButton(L.T("入口へ戻る", "Back to start"), () => Navigate(WorkflowPage.Start), "back-start"));
            var tabs = new VisualElement(); tabs.AddToClassList("tsg-tabs");
            tabs.Add(TsugimelessStyles.ColoredButton(L.T("質感", "Surface"), () => Navigate(WorkflowPage.Surface), "tab-surface", page == WorkflowPage.Surface));
            tabs.Add(TsugimelessStyles.ColoredButton(L.T("顔と首", "Face and neck"), () => Navigate(WorkflowPage.Neck), "tab-neck", page == WorkflowPage.Neck));
            var parts = TsugimelessStyles.ColoredButton(L.T("部位", "Parts"), null, "tab-parts"); parts.SetEnabled(false); tabs.Add(parts);
            var apply = TsugimelessStyles.ColoredButton(L.T("比較・適用", "Compare / apply"), null, "tab-apply"); apply.SetEnabled(false); tabs.Add(apply);
            body.Add(tabs);
            if (page == WorkflowPage.Surface) BuildSurface(); else BuildNeck();
        }

        private void BuildMainTabs()
        {
            if (mainTabs == null) return;
            mainTabs.Clear();
            int selected = page == WorkflowPage.History ? 1 : page == WorkflowPage.Settings ? 2 : 0;
            mainTabs.Add(TsugimelessStyles.ChoiceBar(
                new[] { L.T("首をなじませる", "Blend the neck"), L.T("あとから戻す", "Restore a previous result"), L.T("設定", "Settings") },
                new[] { "main-work-tab", "main-history-tab", "main-settings-tab" }, selected,
                index => { if (index == 0) ReturnToWork(); else Navigate(index == 1 ? WorkflowPage.History : WorkflowPage.Settings); }));
        }
        private static bool IsUtilityPage(WorkflowPage value) => value == WorkflowPage.Settings || value == WorkflowPage.History;
        internal void ReturnToWork() { if (IsUtilityPage(page)) Navigate(lastWorkPage); }

        private void BuildSurface()
        {
            body.Add(TsugimelessStyles.Heading(L.T("全体の質感を整える", "Match overall surface")));
            body.Add(TsugimelessStyles.Note(L.T("プリセット・顔・体・髪のどれかを基準にする画面です。", "This workflow will offer presets or matching to the face, body, or hair.")));
            body.Add(new HelpBox(L.T("質感の提案は次の実装で接続します。今は画面移動だけを確認できます。", "Surface proposals will be connected in a later step. Navigation is available now."), HelpBoxMessageType.Info));
            var button = TsugimelessStyles.ColoredButton(L.T("質感の提案を見る", "View surface proposal"), null, "surface-propose"); button.SetEnabled(false); body.Add(button);
            body.Add(TsugimelessStyles.ColoredButton(L.T("次へ：顔と首をなじませる", "Next: blend face and neck"), () => Navigate(WorkflowPage.Neck), "surface-next", true));
        }

        private void BuildNeck()
        {
            body.Add(TsugimelessStyles.Heading(L.T("顔と首をなじませる", "Blend face and neck")));
            body.Add(BuildNeckPanel());
            BuildDiagnosisPanel();
            var proposal = TsugimelessStyles.ColoredButton(L.T("なじませる提案を見る", "View blending proposal"), null, "neck-propose", true); proposal.SetEnabled(false); body.Add(proposal);
            var parts = TsugimelessStyles.ColoredButton(L.T("必要なら部位を保護・調整する", "Protect or adjust parts if needed"), null, "neck-parts"); parts.SetEnabled(false); body.Add(parts);
            var compare = TsugimelessStyles.ColoredButton(L.T("比較して適用する", "Compare and apply"), null, "neck-compare"); compare.SetEnabled(false); body.Add(compare);
            body.Add(TsugimelessStyles.Note(L.T("部位・比較・適用も準備中です。アバターの材質や設定は変更しません。", "Parts, comparison, and application are not connected yet. Avatar materials and settings stay unchanged.")));
        }
    }
}
