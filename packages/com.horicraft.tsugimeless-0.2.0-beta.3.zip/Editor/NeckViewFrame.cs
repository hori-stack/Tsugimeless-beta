using System.Collections.Generic;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    internal enum NeckViewAngle { Oblique, Front, Left, Right, Back }

    // Pure framing math. Detection positions and the avatar are never moved for display.
    internal readonly struct NeckViewFrame
    {
        internal readonly Vector3 Center;
        internal readonly Quaternion Rotation;
        internal readonly float Size;
        private NeckViewFrame(Vector3 center, Quaternion rotation, float size)
        { Center = center; Rotation = rotation; Size = size; }

        internal static bool TryCreate(IReadOnlyList<NeckPair> pairs, Vector3 forward, Vector3 up, NeckViewAngle angle, out NeckViewFrame frame)
        {
            frame = default;
            if (pairs == null || pairs.Count == 0 || !NeckSnapshot.Finite(forward) || !NeckSnapshot.Finite(up) || up.sqrMagnitude < 1e-8f) return false;
            up.Normalize(); forward = Vector3.ProjectOnPlane(forward, up);
            if (forward.sqrMagnitude < 1e-8f) return false;
            forward.Normalize(); var center = Vector3.zero;
            foreach (var p in pairs)
            {
                if (p?.face == null || p.body == null || !NeckSnapshot.Finite(p.face.position) || !NeckSnapshot.Finite(p.body.position)) return false;
                center += (p.face.position + p.body.position) * (.5f / pairs.Count);
            }
            float radius = 0;
            foreach (var p in pairs) radius = Mathf.Max(radius, (p.face.position - center).magnitude, (p.body.position - center).magnitude);
            if (radius < 1e-5f || !NeckSnapshot.Finite(radius)) return false;
            float yaw = angle == NeckViewAngle.Left ? -30 : angle == NeckViewAngle.Right ? 30 : angle == NeckViewAngle.Back ? 180 : angle == NeckViewAngle.Oblique ? 25 : 0;
            var fromNeck = Quaternion.AngleAxis(yaw, up) * forward;
            // A small view from below exposes the jaw/neck join without looking up from inside the chest.
            // Left/right views approach from the front at the same close distance as the main view,
            // avoiding the low, distant side position behind outstretched arms and side hair.
            fromNeck = (fromNeck - up * .35f).normalized;
            float padding = 1.65f;
            frame = new NeckViewFrame(center - up * radius * .12f, Quaternion.LookRotation(-fromNeck, up), radius * padding);
            return true;
        }
    }
}
