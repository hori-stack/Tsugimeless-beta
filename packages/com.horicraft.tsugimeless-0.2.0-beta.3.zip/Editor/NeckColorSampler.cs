using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace HoriCraft.Tsugimeless.Editor
{
    internal static class NeckColorSampler
    {
        internal const int BatchLimit = 1024, ReferenceLimit = 16384;
        internal static int LiveResources { get; private set; }
        internal static string EnvironmentReason(ColorSpace space, bool builtIn, bool gpu, bool floats, bool shader)
        {
            if (space != ColorSpace.Linear) return "ColorSpace: Linear required";
            if (!builtIn) return "Built-in Render Pipeline required";
            if (!gpu || !floats || !shader) return "GPU / float formats / sampling shader unavailable";
            return null;
        }
        internal static string EnvironmentReason()
        {
            var shader = Shader.Find("Hidden/HoriCraft/TsugimelessNeckSampling");
            return EnvironmentReason(QualitySettings.activeColorSpace, GraphicsSettings.currentRenderPipeline == null, SystemInfo.graphicsDeviceType != GraphicsDeviceType.Null,
                SystemInfo.SupportsTextureFormat(TextureFormat.RGBAFloat) && SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.ARGBFloat) && SystemInfo.maxTextureSize >= BatchLimit * 2,
                shader && shader.isSupported && !ShaderUtil.ShaderHasError(shader));
        }
        // Only allocates an N-coordinate texture and 2N output pixels, independent of source image size.
        internal static Color[] Sample(NeckMaterialRead source, Vector2[] coordinates)
        {
            if (coordinates == null || coordinates.Length == 0 || coordinates.Length > BatchLimit || coordinates.Any(v => !LilToonMaterialRead.Finite(v.x) || !LilToonMaterialRead.Finite(v.y))) throw new ArgumentException("UV batch");
            string reason = EnvironmentReason() ?? LilToonMaterialRead.ColorReason(source);
            if (reason != null) throw new NotSupportedException(reason);
            Material evaluation = null; Texture2D uv = null, read = null; RenderTexture rt = null;
            var previous = RenderTexture.active; bool srgb = GL.sRGBWrite;
            try
            {
                evaluation = new Material(Shader.Find("Hidden/HoriCraft/TsugimelessNeckSampling")) { hideFlags = HideFlags.HideAndDontSave }; LiveResources++;
                foreach (var kv in source.values)
                {
                    int index = evaluation.shader.FindPropertyIndex(kv.Key);
                    if (index < 0) continue;
                    var v = kv.Value; var type = evaluation.shader.GetPropertyType(index);
                    if (!v.Finite) continue;
                    if (type == ShaderPropertyType.Color && v.type == type) evaluation.SetColor(kv.Key, v.value);
                    else if (type == ShaderPropertyType.Vector && v.type == type) evaluation.SetVector(kv.Key, v.value);
                    else if (type == ShaderPropertyType.Float && source.Number(kv.Key)) evaluation.SetFloat(kv.Key, v.value.x);
                    else if (type == ShaderPropertyType.Texture && v.type == type)
                    { evaluation.SetTexture(kv.Key, v.texture ? v.texture : Texture2D.whiteTexture); evaluation.SetTextureScale(kv.Key, new Vector2(v.st.x, v.st.y)); evaluation.SetTextureOffset(kv.Key, new Vector2(v.st.z, v.st.w)); }
                }
                // Disabled layers must not sample stale unsupported textures, NaNs or render targets.
                foreach (var layer in new[] { "2nd", "3rd" }) if (source.N("_UseMain" + layer + "Tex") == 0)
                {
                    evaluation.SetColor("_Color" + layer, Color.white); evaluation.SetTexture("_Main" + layer + "Tex", Texture2D.whiteTexture);
                    evaluation.SetTexture("_Main" + layer + "BlendMask", Texture2D.whiteTexture); evaluation.SetFloat("_Main" + layer + "TexBlendMode", 0); evaluation.SetFloat("_Main" + layer + "EnableLighting", 1);
                    evaluation.SetTextureScale("_Main" + layer + "Tex", Vector2.one); evaluation.SetTextureOffset("_Main" + layer + "Tex", Vector2.zero);
                }
                evaluation.SetVector("_SourceST", source.values["_MainTex"].st);
                uv = new Texture2D(coordinates.Length, 1, TextureFormat.RGBAFloat, false, true) { hideFlags = HideFlags.HideAndDontSave, filterMode = FilterMode.Point }; LiveResources++;
                uv.SetPixels(coordinates.Select(v => new Color(v.x, v.y, 0, 0)).ToArray()); uv.Apply(false); evaluation.SetTexture("_SampleUvTex", uv);
                rt = new RenderTexture(coordinates.Length * 2, 1, 0, RenderTextureFormat.ARGBFloat, RenderTextureReadWrite.Linear) { hideFlags = HideFlags.HideAndDontSave, useMipMap = false, filterMode = FilterMode.Point }; LiveResources++;
                if (!rt.Create()) throw new InvalidOperationException("Float RenderTexture creation failed");
                GL.sRGBWrite = false;
                Graphics.Blit(source.T("_MainTex") ? source.T("_MainTex") : Texture2D.whiteTexture, rt, evaluation, 0);
                RenderTexture.active = rt;
                read = new Texture2D(rt.width, 1, TextureFormat.RGBAFloat, false, true) { hideFlags = HideFlags.HideAndDontSave }; LiveResources++;
                read.ReadPixels(new Rect(0, 0, rt.width, 1), 0, 0, false); read.Apply(false);
                var result = read.GetPixels();
                if (result.Any(c => !LilToonMaterialRead.Finite((Vector4)c))) throw new ArithmeticException("Non-finite GPU sample");
                return result;
            }
            finally
            {
                RenderTexture.active = previous; GL.sRGBWrite = srgb;
                if (read) { UnityEngine.Object.DestroyImmediate(read); LiveResources--; }
                if (rt) { rt.Release(); UnityEngine.Object.DestroyImmediate(rt); LiveResources--; }
                if (uv) { UnityEngine.Object.DestroyImmediate(uv); LiveResources--; }
                if (evaluation) { UnityEngine.Object.DestroyImmediate(evaluation); LiveResources--; }
            }
        }
        // Actual selected-submesh incidence, not a Cartesian product of unrelated seam corners.
        internal sealed class UvIndex
        {
            private sealed class Triangle { internal int slot, id; internal int[] vertices; }
            private readonly Dictionary<int, List<Triangle>> incident = new Dictionary<int, List<Triangle>>();
            private readonly Vector2[] uv;
            internal UvIndex(Mesh mesh, int[] slots)
            {
                uv = mesh.uv;
                if (uv.Length != mesh.vertexCount) { uv = null; return; }
                foreach (int slot in slots)
                {
                    var indices = mesh.GetTriangles(slot);
                    for (int i = 0; i < indices.Length; i += 3)
                    {
                        var t = new Triangle { slot = slot, id = i / 3, vertices = new[] { indices[i], indices[i + 1], indices[i + 2] } };
                        foreach (int vertex in t.vertices.Distinct())
                        { if (!incident.TryGetValue(vertex, out var list)) incident[vertex] = list = new List<Triangle>(); list.Add(t); }
                    }
                }
            }
            internal List<NeckColorReference> References(NeckPoint point)
            {
                var result = new List<NeckColorReference>();
                if (uv == null || !point.hasUv || point.vertices == null || point.vertices.Length == 0) return result;
                void Add(int slot, int triangle, Vector2 value)
                {
                    if (!result.Any(r => r.slot == slot && r.uv == value)) result.Add(new NeckColorReference { slot = slot, triangle = triangle, uv = value });
                }
                var aliases = point.aliases ?? Array.Empty<NeckUvAlias>();
                if (point.vertices.Length == 1)
                {
                    foreach (int v in aliases.Select(a => a.vertex).Concat(point.vertices).Distinct())
                        if (v >= 0 && v < uv.Length && incident.TryGetValue(v, out var triangles))
                            foreach (var t in triangles) Add(t.slot, t.id, uv[v]);
                    return result;
                }
                var groups = Enumerable.Range(0, 3).Select(c => new HashSet<int>(aliases.Where(a => a.corner == c).Select(a => a.vertex).Concat(new[] { point.vertices[c] }))).ToArray();
                var candidates = new HashSet<Triangle>();
                foreach (int v in groups[0]) if (incident.TryGetValue(v, out var list)) foreach (var t in list) candidates.Add(t);
                foreach (var t in candidates)
                {
                    var ordered = groups.Select(g => t.vertices.Where(g.Contains).ToArray()).ToArray();
                    if (ordered.Any(a => a.Length != 1) || ordered.Select(a => a[0]).Distinct().Count() != 3) continue;
                    Add(t.slot, t.id, uv[ordered[0][0]] * point.weights.x + uv[ordered[1][0]] * point.weights.y + uv[ordered[2][0]] * point.weights.z);
                }
                return result;
            }
        }
    }
}
