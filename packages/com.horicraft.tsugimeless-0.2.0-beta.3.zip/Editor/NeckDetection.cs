using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    // Pure geometry. Face/body roles stay stable even when the source of the search is the body.
    internal static class NeckDetection
    {
        // Optional read-only diagnostics for reproducing a rejected component. The normal UI does not allocate these arrays.
        internal sealed class LoopDiagnostic
        {
            internal string reason;
            internal bool reverse, boundary;
            internal float thresholdMm;
            internal int belowDegreeTwo, aboveDegreeTwo;
            internal Vector3[] source, target;
        }
        private const float WeldDistance = .00001f;
        private sealed class Node { internal Bounds bounds; internal Node left, right; internal int[] triangles; }
        private sealed class Contact
        {
            internal int vertex, triangle = -1;
            internal Vector3 point, barycentric;
            internal float squaredDistance = .005001f * .005001f;
        }
        private sealed class Direction
        {
            internal NeckSurface source, target;
            internal bool reverse;
            internal readonly List<Contact> contacts = new List<Contact>();
            internal int[] welded;
            internal HashSet<long> boundaryEdges;
            internal int[] targetWelded;
            internal HashSet<int> invalidTargetBoundary;
            internal HashSet<long> targetBoundaryEdges;
            internal HashSet<int> excludedSourceNodes, excludedTargetNodes;
            internal Dictionary<int, int[]> sourceAliases, targetAliases;
            internal bool sourceHasUv, targetHasUv;
        }
        internal static NeckResult Detect(NeckSnapshot pose, float presetThreshold = -1)
        {
            var result = new NeckResult();
            using (var work = Run(pose, result, presetThreshold).GetEnumerator()) while (work.MoveNext()) { }
            return result;
        }
        internal static IEnumerable<float> Run(NeckSnapshot pose, NeckResult result, float presetThreshold = -1, Action<LoopDiagnostic> diagnostic = null)
        {
            result.state = NeckState.Running;
            if (pose?.face?.triangles == null || pose.body?.triangles == null || pose.face.triangles.Length == 0 || pose.body.triangles.Length == 0)
            { result.state = NeckState.Invalid; result.issue = NeckIssue.Geometry; yield break; }
            result.stamp = pose.stamp;
            result.excludedFace = pose.face.excluded; result.excludedBody = pose.body.excluded;
            var axis = (pose.head - pose.chest).normalized; float length = Vector3.Distance(pose.head, pose.chest);
            var directions = new[] { new Direction { source = pose.face, target = pose.body }, new Direction { source = pose.body, target = pose.face, reverse = true } };
            for (int d = 0; d < directions.Length; d++)
            {
                var direction = directions[d]; direction.welded = new int[direction.source.positions.Length];
                foreach (float progress in WeldSteps(direction.source.positions, direction.welded)) yield return .04f * d + .025f * progress;
                direction.excludedSourceNodes = new HashSet<int>(direction.source.excluded.SelectMany(t => t.vertices).Select(i => direction.welded[i]));
                direction.sourceAliases = Enumerable.Range(0, direction.welded.Length).GroupBy(i => direction.welded[i]).ToDictionary(g => g.Key, g => g.ToArray());
                yield return .04f * d + .026f;
                direction.boundaryEdges = new HashSet<long>();
                foreach (float progress in BoundarySteps(direction.source, direction.welded, direction.boundaryEdges)) yield return .04f * d + .026f + .01f * progress;
                yield return .04f * (d + 1);
            }
            for (int d = 0; d < directions.Length; d++)
            {
                var source = directions[d]; var target = directions[1 - d];
                source.targetWelded = target.welded; source.targetAliases = target.sourceAliases;
                source.excludedTargetNodes = target.excludedSourceNodes; source.targetBoundaryEdges = target.boundaryEdges;
                source.invalidTargetBoundary = InvalidBoundaryNodes(pose, target.source, target.boundaryEdges, target.sourceAliases, axis, length);
                yield return .08f;
            }
            for (int d = 0; d < directions.Length; d++)
            {
                var direction = directions[d]; var vertices = direction.source.triangles.Distinct().OrderBy(i => i).ToArray();
                direction.sourceHasUv = UsableUv(direction.source); direction.targetHasUv = UsableUv(direction.target);
                var tree = new Node();
                foreach (float progress in BuildTreeSteps(direction.target, tree)) yield return .08f + .26f * d + .025f * progress;
                for (int i = 0; i < vertices.Length; i++)
                {
                    var contact = new Contact { vertex = vertices[i] };
                    Nearest(tree, direction.target, direction.source.positions[contact.vertex], contact);
                    if (contact.triangle >= 0) direction.contacts.Add(contact);
                    if (i % 128 == 0) yield return .08f + .26f * d + .025f + .235f * i / vertices.Length;
                }
                result.initialCandidates += direction.contacts.Count(c => c.squaredDistance <= 1e-6f && InBand(pose, direction.source.positions[c.vertex]));
                foreach (bool boundary in new[] { true, false })
                    result.traces.Add(new NeckTrace { reverse = direction.reverse, boundary = boundary,
                        within5mm = direction.contacts.Count, inBand = direction.contacts.Count(c => InBand(pose, direction.source.positions[c.vertex])),
                        boundaryNodes = direction.boundaryEdges.SelectMany(e => new[] { (int)(e >> 32), (int)e }).Distinct().Count() });
            }
            var thresholds = new List<float>();
            if (presetThreshold >= .1f && presetThreshold <= 5) thresholds.Add(presetThreshold);
            for (int i = 1; i <= 50; i++) if (!thresholds.Any(t => Mathf.Abs(t - i * .1f) < .00001f)) thresholds.Add(i * .1f);
            foreach (float threshold in thresholds)
            {
                var found = new List<List<NeckPair>>();
                foreach (var direction in directions)
                {
                    var selected = direction.contacts.Where(c => c.squaredDistance <= threshold * threshold * 1e-6f).ToArray();
                    foreach (bool boundary in new[] { true, false })
                    {
                        var loops = ExtractLoops(pose, direction, selected, boundary, axis, length, threshold, diagnostic);
                        var trace = result.traces.Single(t => t.reverse == direction.reverse && t.boundary == boundary);
                        trace.thresholdMm = threshold; trace.loops = loops.Count;
                        foreach (var loop in loops) if (!found.Any(other => SameLoop(other, loop))) found.Add(loop);
                        // A measured open edge is a stronger seam candidate than an interior contact graph.
                        if (boundary && loops.Count > 0) break;
                    }
                }
                result.thresholdMm = threshold;
                yield return .6f + .39f * threshold / 5;
                if (found.Count == 0) continue;
                result.loops.AddRange(found);
                result.usedPreset = presetThreshold >= .1f && Mathf.Abs(presetThreshold - threshold) < .00001f;
                if (found.Count > 1)
                {
                    result.state = NeckState.Ambiguous; result.issue = NeckIssue.MultipleLoops;
                    foreach (var loop in found) result.rejected.AddRange(loop);
                }
                else
                {
                    result.state = NeckState.Candidate; result.issue = NeckIssue.None;
                    result.meanNormalAngle = found[0].Average(p => p.normalAngle); result.maxNormalAngle = found[0].Max(p => p.normalAngle);
                }
                yield break;
            }
            result.state = NeckState.NotFound;
            result.issue = directions.All(d => d.contacts.Count == 0) ? NeckIssue.NoContacts
                : result.traces.All(t => t.inBand == 0) ? NeckIssue.OutsideNeckBand : NeckIssue.NoLoop;
            foreach (var d in directions) foreach (var c in d.contacts.Where(c => InBand(pose, d.source.positions[c.vertex])).Take(500)) result.rejected.Add(Pair(d, c));
        }
        private static bool InBand(NeckSnapshot pose, Vector3 point)
        {
            var axis = (pose.head - pose.chest).normalized; float length = Vector3.Distance(pose.head, pose.chest);
            float h = Vector3.Dot(point - pose.chest, axis);
            return h >= Vector3.Dot(pose.neck - pose.chest, axis) - .15f * length && h <= length * 1.1f;
        }
        private static long Edge(int a, int b) => ((long)Math.Min(a, b) << 32) | (uint)Math.Max(a, b);
        private static IEnumerable<float> WeldSteps(Vector3[] positions, int[] map)
        {
            var cells = new Dictionary<Vector3Int, List<int>>(); var representatives = new List<int>();
            for (int i = 0; i < positions.Length; i++)
            {
                var point = positions[i]; var cell = new Vector3Int(Mathf.FloorToInt(point.x / WeldDistance), Mathf.FloorToInt(point.y / WeldDistance), Mathf.FloorToInt(point.z / WeldDistance));
                int found = -1;
                for (int x = -1; x <= 1 && found < 0; x++) for (int y = -1; y <= 1 && found < 0; y++) for (int z = -1; z <= 1 && found < 0; z++)
                    if (cells.TryGetValue(cell + new Vector3Int(x, y, z), out var bucket))
                        foreach (int r in bucket) if ((positions[representatives[r]] - point).sqrMagnitude <= WeldDistance * WeldDistance) { found = r; break; }
                if (found < 0)
                {
                    found = representatives.Count; representatives.Add(i);
                    if (!cells.TryGetValue(cell, out var bucket)) cells[cell] = bucket = new List<int>(); bucket.Add(found);
                }
                map[i] = found;
                if (i % 256 == 0) yield return (float)i / positions.Length;
            }
            yield return 1;
        }
        private static IEnumerable<float> BoundarySteps(NeckSurface surface, int[] welded, HashSet<long> boundary)
        {
            var uses = new Dictionary<long, int>();
            for (int i = 0; i < surface.triangles.Length; i += 3)
            {
                for (int j = 0; j < 3; j++)
                {
                    int a = welded[surface.triangles[i + j]], b = welded[surface.triangles[i + (j + 1) % 3]];
                    if (a == b) continue;
                    long e = Edge(a, b); uses[e] = uses.TryGetValue(e, out int count) ? count + 1 : 1;
                }
                if (i % 3072 == 0) yield return (float)i / surface.triangles.Length;
            }
            int visited = 0;
            foreach (var pair in uses)
            {
                if (pair.Value == 1) boundary.Add(pair.Key);
                if (++visited % 1024 == 0) yield return 1;
            }
        }
        private static List<List<NeckPair>> ExtractLoops(NeckSnapshot pose, Direction direction, Contact[] selected, bool boundary, Vector3 axis, float length, float threshold, Action<LoopDiagnostic> diagnostic)
        {
            var source = direction.source;
            var groups = selected.Where(c =>
            {
                float radius = Vector3.ProjectOnPlane(source.positions[c.vertex] - pose.neck, axis).magnitude;
                return radius >= length * .03f && radius <= length * .65f && !direction.excludedSourceNodes.Contains(direction.welded[c.vertex]);
            }).GroupBy(c => direction.welded[c.vertex]).ToDictionary(g => g.Key, g => g.OrderBy(c => c.vertex).ToArray());
            if (diagnostic != null)
            {
                var filtered = selected.Where(c => !groups.ContainsKey(direction.welded[c.vertex])).Select(c => source.positions[c.vertex]).Distinct().ToArray();
                if (filtered.Length > 0) diagnostic(new LoopDiagnostic { reason = "source radius or excluded face", reverse = direction.reverse,
                    boundary = boundary, thresholdMm = threshold, source = filtered, belowDegreeTwo = -1, aboveDegreeTwo = -1 });
            }
            var adjacency = groups.Keys.ToDictionary(i => i, _ => new HashSet<int>());
            for (int i = 0; i < source.triangles.Length; i += 3)
                for (int j = 0; j < 3; j++)
                {
                    int a = direction.welded[source.triangles[i + j]], b = direction.welded[source.triangles[i + (j + 1) % 3]];
                    if (a == b || !groups.ContainsKey(a) || !groups.ContainsKey(b) || (boundary && !direction.boundaryEdges.Contains(Edge(a, b)))) continue;
                    adjacency[a].Add(b); adjacency[b].Add(a);
                }
            var visited = new HashSet<int>(); var loops = new List<List<NeckPair>>();
            void Trace(string reason, List<int> component, List<NeckPair> pairs = null)
            {
                if (diagnostic == null || component.Count < 3) return;
                diagnostic(new LoopDiagnostic { reason = reason, reverse = direction.reverse, boundary = boundary, thresholdMm = threshold,
                    belowDegreeTwo = component.Count(i => adjacency[i].Count < 2), aboveDegreeTwo = component.Count(i => adjacency[i].Count > 2),
                    source = pairs != null ? pairs.Select(p => direction.reverse ? p.body.position : p.face.position).ToArray() : component.Select(i => source.positions[groups[i][0].vertex]).ToArray(),
                    target = pairs?.Select(p => direction.reverse ? p.face.position : p.body.position).ToArray() });
            }
            foreach (int start in groups.Keys.OrderBy(i => i))
            {
                if (!visited.Add(start)) continue;
                var component = new List<int>(); var stack = new Stack<int>(); stack.Push(start);
                while (stack.Count > 0)
                {
                    int current = stack.Pop(); component.Add(current);
                    foreach (int next in adjacency[current]) if (visited.Add(next)) stack.Push(next);
                }
                if (component.Count < 8 || component.Any(i => adjacency[i].Count != 2)) { Trace("source topology", component); continue; }
                var ordered = new List<NeckPair>(); bool invalidTarget = false; int previous = -1, index = start;
                do
                {
                    var contact = groups[index][0];
                    // A reverse projection must not close a hole in the other surface.
                    var support = Enumerable.Range(0, 3).Where(j => contact.barycentric[j] > 0)
                        .Select(j => direction.targetWelded[direction.target.triangles[contact.triangle * 3 + j]]).Distinct().ToArray();
                    bool onBoundary = support.Length == 1 || (support.Length == 2 && direction.targetBoundaryEdges.Contains(Edge(support[0], support[1])));
                    if (onBoundary && support.Any(direction.invalidTargetBoundary.Contains)) invalidTarget = true;
                    if (support.Any(direction.excludedTargetNodes.Contains)) invalidTarget = true;
                    var pair = Pair(direction, groups[index][0]); pair.sourceAliases = groups[index].Select(c => c.vertex).ToArray(); ordered.Add(pair);
                    int next = adjacency[index].OrderBy(i => i).First(i => i != previous); previous = index; index = next;
                } while (index != start && ordered.Count <= component.Count);
                if (invalidTarget) { Trace("target boundary not certified or excluded face", component, ordered); continue; }
                if (ordered.Count != component.Count) { Trace("source traversal", component, ordered); continue; }
                if (ordered.Any(p => !InBand(pose, p.face.position) || !InBand(pose, p.body.position))) { Trace("bone height band", component, ordered); continue; }
                if (RingValid(ordered.Select(p => p.face.position).ToArray(), pose.neck, axis, length)
                    && RingValid(ordered.Select(p => p.body.position).ToArray(), pose.neck, axis, length)) { loops.Add(ordered); Trace("accepted", component, ordered); }
                else Trace("ring geometry", component, ordered);
            }
            return loops;
        }
        private static HashSet<int> InvalidBoundaryNodes(NeckSnapshot pose, NeckSurface surface, HashSet<long> boundaries, Dictionary<int, int[]> aliases, Vector3 axis, float length)
        {
            var adjacency = new Dictionary<int, HashSet<int>>();
            foreach (long edge in boundaries)
            {
                int a = (int)(edge >> 32), b = (int)edge;
                if (!adjacency.ContainsKey(a)) adjacency[a] = new HashSet<int>();
                if (!adjacency.ContainsKey(b)) adjacency[b] = new HashSet<int>();
                adjacency[a].Add(b); adjacency[b].Add(a);
            }
            var visited = new HashSet<int>(); var invalid = new HashSet<int>();
            foreach (int start in adjacency.Keys)
            {
                if (!visited.Add(start)) continue;
                var component = new List<int>(); var pending = new Stack<int>(); pending.Push(start);
                while (pending.Count > 0)
                {
                    int current = pending.Pop(); component.Add(current);
                    foreach (int next in adjacency[current]) if (visited.Add(next)) pending.Push(next);
                }
                bool valid = component.Count >= 8 && component.All(i => adjacency[i].Count == 2);
                if (valid)
                {
                    var ordered = new List<Vector3>(); int previous = -1, current = start;
                    do
                    {
                        ordered.Add(surface.positions[aliases[current][0]]); int next = adjacency[current].First(i => i != previous); previous = current; current = next;
                    } while (current != start && ordered.Count <= component.Count);
                    valid = ordered.Count == component.Count && ordered.All(p => InBand(pose, p)) && RingValid(ordered.ToArray(), pose.neck, axis, length);
                }
                if (!valid) invalid.UnionWith(component);
            }
            return invalid;
        }
        private static bool RingValid(Vector3[] points, Vector3 origin, Vector3 axis, float length)
        {
            var projected = points.Select(p => Vector3.ProjectOnPlane(p - origin, axis)).ToArray();
            if (projected.Any(p => p.magnitude < length * .03f || p.magnitude > length * .65f)) return false;
            if (points.Max(p => Vector3.Dot(p - origin, axis)) - points.Min(p => Vector3.Dot(p - origin, axis)) > length * .4f) return false;
            float sum = 0; int direction = 0;
            for (int i = 0; i < points.Length; i++)
            {
                int next = (i + 1) % points.Length; float angle = Vector3.SignedAngle(projected[i], projected[next], axis);
                if (Mathf.Abs(angle) > 60 || Mathf.Abs(angle) < .001f || Vector3.Distance(points[i], points[next]) < WeldDistance) return false;
                int sign = angle > 0 ? 1 : -1; if (direction != 0 && sign != direction) return false;
                direction = sign; sum += angle;
            }
            return Mathf.Abs(Mathf.Abs(sum) - 360) < 1;
        }
        private static bool SameLoop(List<NeckPair> a, List<NeckPair> b)
        {
            // Conservative identity: both face and body traces must lie on the same measured polylines.
            // Different source sampling densities can still represent one seam; nearby parallel seams cannot.
            bool Matches(List<NeckPair> left, List<NeckPair> right, bool face)
            {
                foreach (var p in left)
                {
                    Vector3 point = face ? p.face.position : p.body.position;
                    bool hit = false;
                    for (int i = 0; i < right.Count && !hit; i++)
                    {
                        var x = face ? right[i].face.position : right[i].body.position;
                        var y = face ? right[(i + 1) % right.Count].face.position : right[(i + 1) % right.Count].body.position;
                        var delta = y - x; float t = delta.sqrMagnitude > 0 ? Mathf.Clamp01(Vector3.Dot(point - x, delta) / delta.sqrMagnitude) : 0;
                        hit = (point - (x + t * delta)).sqrMagnitude <= WeldDistance * WeldDistance;
                    }
                    if (!hit) return false;
                }
                return true;
            }
            return Matches(a, b, true) && Matches(b, a, true) && Matches(a, b, false) && Matches(b, a, false);
        }
        private static NeckPair Pair(Direction d, Contact c)
        {
            int k = c.triangle * 3; var indices = new[] { d.target.triangles[k], d.target.triangles[k + 1], d.target.triangles[k + 2] };
            bool sourceUv = d.sourceHasUv, targetUv = d.targetHasUv;
            var source = new NeckPoint { vertices = new[] { c.vertex }, weights = Vector3.right, position = d.source.positions[c.vertex], hasUv = sourceUv, uv = sourceUv ? d.source.uv[c.vertex] : Vector2.zero };
            var target = new NeckPoint { vertices = indices, weights = c.barycentric, position = c.point, hasUv = targetUv,
                triangle = d.target.triangleIds != null ? d.target.triangleIds[c.triangle] : c.triangle, slot = d.target.triangleSlots != null ? d.target.triangleSlots[c.triangle] : -1,
                uv = targetUv ? d.target.uv[indices[0]] * c.barycentric.x + d.target.uv[indices[1]] * c.barycentric.y + d.target.uv[indices[2]] * c.barycentric.z : Vector2.zero };
            if (sourceUv) source.aliases = d.sourceAliases[d.welded[c.vertex]].Select(i => new NeckUvAlias { vertex = i, corner = 0, uv = d.source.uv[i] }).ToArray();
            if (targetUv) target.aliases = Enumerable.Range(0, 3).SelectMany(j => d.targetAliases[d.targetWelded[indices[j]]].Select(i => new NeckUvAlias { vertex = i, corner = j, uv = d.target.uv[i] })).ToArray();
            var normal = d.target.normals[indices[0]] * c.barycentric.x + d.target.normals[indices[1]] * c.barycentric.y + d.target.normals[indices[2]] * c.barycentric.z;
            return new NeckPair { face = d.reverse ? target : source, body = d.reverse ? source : target,
                distanceMm = Mathf.Sqrt(c.squaredDistance) * 1000, normalAngle = Vector3.Angle(d.source.normals[c.vertex], normal), sourceAliases = new[] { c.vertex }, reverse = d.reverse };
        }
        private static bool UsableUv(NeckSurface surface) => surface.uv != null && surface.uv.Length == surface.positions.Length
            && surface.uv.All(v => NeckSnapshot.Finite(v.x) && NeckSnapshot.Finite(v.y));

        private sealed class BuildRange { internal Node node; internal int start, count; }
        private static IEnumerable<float> BuildTreeSteps(NeckSurface surface, Node root)
        {
            int count = surface.triangles.Length / 3;
            var indices = Enumerable.Range(0, count).ToArray();
            var minimum = new Vector3[count]; var maximum = new Vector3[count]; var centers = new Vector3[count];
            for (int i = 0; i < count; i++)
            {
                var a = surface.positions[surface.triangles[i * 3]]; var b = surface.positions[surface.triangles[i * 3 + 1]]; var c = surface.positions[surface.triangles[i * 3 + 2]];
                minimum[i] = Vector3.Min(a, Vector3.Min(b, c)); maximum[i] = Vector3.Max(a, Vector3.Max(b, c)); centers[i] = (a + b + c) / 3;
                if (i % 1024 == 0) yield return .3f * i / count;
            }
            var comparers = Enumerable.Range(0, 3).Select(axis => Comparer<int>.Create((a, b) => centers[a][axis].CompareTo(centers[b][axis]))).ToArray();
            var pending = new Stack<BuildRange>(); pending.Push(new BuildRange { node = root, start = 0, count = count }); int processed = 0;
            while (pending.Count > 0)
            {
                var work = pending.Pop(); var low = minimum[indices[work.start]]; var high = maximum[indices[work.start]];
                for (int i = work.start + 1; i < work.start + work.count; i++) { low = Vector3.Min(low, minimum[indices[i]]); high = Vector3.Max(high, maximum[indices[i]]); }
                work.node.bounds = new Bounds((low + high) * .5f, high - low);
                if (work.count <= 8) { work.node.triangles = new int[work.count]; Array.Copy(indices, work.start, work.node.triangles, 0, work.count); processed += work.count; }
                else
                {
                    var size = high - low; int axis = size.x > size.y ? 0 : 1; if (size.z > size[axis]) axis = 2;
                    Array.Sort(indices, work.start, work.count, comparers[axis]); int middle = work.count / 2;
                    work.node.left = new Node(); work.node.right = new Node();
                    pending.Push(new BuildRange { node = work.node.right, start = work.start + middle, count = work.count - middle });
                    pending.Push(new BuildRange { node = work.node.left, start = work.start, count = middle });
                }
                // Yield after a large split and regularly while making small nodes; cancellation never waits for the entire tree.
                if (work.count > 1024 || processed % 128 < 8) yield return .3f + .7f * processed / count;
            }
        }
        private static void Nearest(Node node, NeckSurface surface, Vector3 point, Contact best)
        {
            if (node == null || node.bounds.SqrDistance(point) > best.squaredDistance) return;
            if (node.triangles == null) { Nearest(node.left, surface, point, best); Nearest(node.right, surface, point, best); return; }
            foreach (int triangle in node.triangles)
            {
                int i = triangle * 3;
                Vector3 a = surface.positions[surface.triangles[i]], b = surface.positions[surface.triangles[i + 1]], c = surface.positions[surface.triangles[i + 2]];
                if (Vector3.Cross(b - a, c - a).sqrMagnitude < 1e-18f) continue;
                Vector3 weights = ClosestWeights(point, a, b, c);
                Vector3 closest = a * weights.x + b * weights.y + c * weights.z;
                float distance = (point - closest).sqrMagnitude;
                if (distance > best.squaredDistance) continue;
                best.squaredDistance = distance; best.point = closest; best.barycentric = weights; best.triangle = triangle;
            }
        }

        // Closest point on a triangle, explicitly considering its vertex and edge regions.
        internal static Vector3 ClosestWeights(Vector3 p, Vector3 a, Vector3 b, Vector3 c)
        {
            Vector3 ab = b - a, ac = c - a, ap = p - a;
            float d1 = Vector3.Dot(ab, ap), d2 = Vector3.Dot(ac, ap);
            if (d1 <= 0 && d2 <= 0) return new Vector3(1, 0, 0);
            var bp = p - b; float d3 = Vector3.Dot(ab, bp), d4 = Vector3.Dot(ac, bp);
            if (d3 >= 0 && d4 <= d3) return new Vector3(0, 1, 0);
            float vc = d1 * d4 - d3 * d2;
            if (vc <= 0 && d1 >= 0 && d3 <= 0) { float v = d1 / (d1 - d3); return new Vector3(1 - v, v, 0); }
            var cp = p - c; float d5 = Vector3.Dot(ab, cp), d6 = Vector3.Dot(ac, cp);
            if (d6 >= 0 && d5 <= d6) return new Vector3(0, 0, 1);
            float vb = d5 * d2 - d1 * d6;
            if (vb <= 0 && d2 >= 0 && d6 <= 0) { float w = d2 / (d2 - d6); return new Vector3(1 - w, 0, w); }
            float va = d3 * d6 - d5 * d4;
            if (va <= 0 && d4 - d3 >= 0 && d5 - d6 >= 0) { float w = (d4 - d3) / ((d4 - d3) + (d5 - d6)); return new Vector3(0, 1 - w, w); }
            float inverse = 1 / (va + vb + vc); return new Vector3(1 - (vb + vc) * inverse, vb * inverse, vc * inverse);
        }
    }
}
