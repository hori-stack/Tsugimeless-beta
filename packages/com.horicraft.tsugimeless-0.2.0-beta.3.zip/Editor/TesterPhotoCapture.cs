using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace HoriCraft.Tsugimeless.Editor
{
    // Independent camera: never changes the user's SceneView, renderers or global RenderSettings.
    internal sealed class TesterPhotoCapture : IDisposable
    {
        private Scene scene;
        private GameObject root;
        private Camera camera;
        private RenderTexture target;
        private MeshRenderer body;
        private readonly List<Object> owned = new List<Object>();
        internal static int LiveCaptures { get; private set; }
        private bool counted;

        internal TesterPhotoCapture(Renderer face, int faceSlot, Renderer sourceBody, int bodySlot)
        {
            try
            {
                scene = EditorSceneManager.NewPreviewScene();
                root = new GameObject("Tsugimeless report camera") { hideFlags = HideFlags.HideAndDontSave };
                SceneManager.MoveGameObjectToScene(root, scene);
                body = Surface(sourceBody, bodySlot);
                if (face != sourceBody || faceSlot != bodySlot) Surface(face, faceSlot);
                camera = Child("camera").AddComponent<Camera>(); camera.enabled = false; camera.scene = scene;
                camera.clearFlags = CameraClearFlags.SolidColor; camera.backgroundColor = new Color(.035f, .043f, .055f, 1);
                camera.orthographic = true; camera.allowHDR = true; camera.allowMSAA = false; camera.renderingPath = RenderingPath.Forward;
                camera.nearClipPlane = .001f; camera.farClipPlane = 100; camera.cullingMask = 1 << 31;
                var light = Child("light").AddComponent<Light>(); light.type = LightType.Directional; light.color = Color.white;
                light.intensity = 1; light.cullingMask = 1 << 31; light.shadows = LightShadows.None;
                // Shared world-space lighting for every before/after view.
                light.transform.rotation = Quaternion.Euler(35, 25, 0);
                target = new RenderTexture(512, 512, 24, RenderTextureFormat.ARGBFloat, RenderTextureReadWrite.Linear)
                    { hideFlags = HideFlags.HideAndDontSave, antiAliasing = 1 };
                if (!target.Create()) throw new InvalidOperationException("RenderTargetUnavailable");
                camera.targetTexture = target; LiveCaptures++; counted = true;
            }
            catch { Dispose(); throw; }
        }
        private GameObject Child(string name)
        {
            var child = new GameObject(name) { hideFlags = HideFlags.HideAndDontSave, layer = 31 };
            SceneManager.MoveGameObjectToScene(child, scene); child.transform.SetParent(root.transform, false); return child;
        }
        internal static Mesh WorldMesh(Renderer renderer, int slot)
        {
            if (!renderer || !NeckTargets.MeshOf(renderer)) throw new InvalidOperationException("MissingMesh");
            Mesh mesh = null;
            try
            {
                Matrix4x4 matrix;
                if (renderer is SkinnedMeshRenderer skin)
                {
                    mesh = new Mesh(); skin.BakeMesh(mesh, false);
                    // BakeMesh(false) already incorporates renderer scale; applying it again distorts avatars.
                    matrix = Matrix4x4.TRS(renderer.transform.position, renderer.transform.rotation, Vector3.one);
                }
                else { mesh = Object.Instantiate(NeckTargets.MeshOf(renderer)); matrix = renderer.localToWorldMatrix; }
                mesh.hideFlags = HideFlags.HideAndDontSave;
                if (slot < 0 || slot >= mesh.subMeshCount || mesh.GetTopology(slot) != MeshTopology.Triangles) throw new InvalidOperationException("InvalidSkinSlot");
                int[] triangles = mesh.GetTriangles(slot); mesh.subMeshCount = 1; mesh.SetTriangles(triangles, 0);
                mesh.vertices = mesh.vertices.Select(matrix.MultiplyPoint3x4).ToArray();
                var normalMatrix = matrix.inverse.transpose;
                mesh.normals = mesh.normals.Select(n => { var v = normalMatrix.MultiplyVector(n); return v.magnitude > 1e-12f ? v / v.magnitude : Vector3.zero; }).ToArray();
                mesh.tangents = mesh.tangents.Select(t => { var v = matrix.MultiplyVector(new Vector3(t.x, t.y, t.z)); v = v.magnitude > 1e-12f ? v / v.magnitude : Vector3.zero; return new Vector4(v.x, v.y, v.z, t.w * Mathf.Sign(matrix.determinant)); }).ToArray();
                mesh.RecalculateBounds(); return mesh;
            }
            catch { if (mesh) Object.DestroyImmediate(mesh); throw; }
        }
        private MeshRenderer Surface(Renderer source, int slot)
        {
            if (!source || slot < 0 || slot >= source.sharedMaterials.Length || !source.sharedMaterials[slot]) throw new InvalidOperationException("MissingMaterial");
            var mesh = WorldMesh(source, slot); owned.Add(mesh);
            var child = Child("skin"); child.AddComponent<MeshFilter>().sharedMesh = mesh;
            var renderer = child.AddComponent<MeshRenderer>(); renderer.sharedMaterial = Copy(source.sharedMaterials[slot]);
            renderer.shadowCastingMode = ShadowCastingMode.Off; renderer.receiveShadows = false;
            renderer.lightProbeUsage = LightProbeUsage.Off; renderer.reflectionProbeUsage = ReflectionProbeUsage.Off;
            return renderer;
        }
        private Material Copy(Material source)
        {
            var material = new Material(source) { parent = null, hideFlags = HideFlags.HideAndDontSave };
            material.CopyPropertiesFromMaterial(source); owned.Add(material); return material;
        }
        internal byte[] Render(Material source, Texture replacement, string property, Vector3 center, Vector3 forward, Vector3 up, float size, float yaw)
        {
            var material = Copy(source);
            if (replacement && !string.IsNullOrEmpty(property)) material.SetTexture(property, replacement);
            body.sharedMaterial = material;
            var direction = (Quaternion.AngleAxis(yaw, up) * forward - up * .18f).normalized;
            camera.transform.SetPositionAndRotation(center + direction * size * 3.5f, Quaternion.LookRotation(-direction, up));
            camera.orthographicSize = size; camera.farClipPlane = Mathf.Max(size * 9, 1);
            var active = RenderTexture.active; bool srgb = GL.sRGBWrite; Texture2D floats = null, png = null;
            try
            {
                GL.sRGBWrite = false; camera.Render(); RenderTexture.active = target;
                floats = new Texture2D(512, 512, TextureFormat.RGBAFloat, false, true) { hideFlags = HideFlags.HideAndDontSave };
                floats.ReadPixels(new Rect(0, 0, 512, 512), 0, 0); floats.Apply(false);
                var pixels = floats.GetPixels();
                for (int i = 0; i < pixels.Length; i++)
                {
                    var color = QualitySettings.activeColorSpace == ColorSpace.Linear ? pixels[i].gamma : pixels[i];
                    color.a = 1; pixels[i] = color;
                }
                png = new Texture2D(512, 512, TextureFormat.RGBA32, false, true) { hideFlags = HideFlags.HideAndDontSave };
                png.SetPixels(pixels); png.Apply(false); return png.EncodeToPNG();
            }
            finally { RenderTexture.active = active; GL.sRGBWrite = srgb; if (floats) Object.DestroyImmediate(floats); if (png) Object.DestroyImmediate(png); }
        }
        internal static bool Frame(NeckTargets targets, NeckBandResult band, out Vector3 center, out Vector3 forward, out Vector3 up, out float size)
        {
            center = default; forward = Vector3.forward; up = Vector3.up; size = 0;
            if (targets?.Root == null) return false;
            up = targets.Root.transform.up; forward = Vector3.ProjectOnPlane(targets.Root.transform.forward, up).normalized;
            if (band?.Valid == true && band.UpperRing?.Length > 2 && band.LowerRing?.Length > 2)
            {
                var ring = band.UpperRing.Concat(band.LowerRing).ToArray();
                foreach (var point in ring) { if (!NeckSnapshot.Finite(point)) return false; center += point / ring.Length; }
                var capturedCenter = center;
                size = ring.Max(p => (p - capturedCenter).magnitude) * 1.5f;
            }
            else if (NeckSnapshot.TryBones(targets, out _, out var neck, out var head))
            {
                center = Vector3.Lerp(neck.position, head.position, .6f);
                size = (neck.position - head.position).magnitude * 1.5f;
            }
            return NeckSnapshot.Finite(center) && NeckSnapshot.Finite(size) && size > .003f && size < 5 && forward.sqrMagnitude > .5f;
        }
        public void Dispose()
        {
            if (camera) camera.targetTexture = null;
            if (target) { target.Release(); Object.DestroyImmediate(target); }
            if (root) Object.DestroyImmediate(root);
            foreach (var value in owned) if (value) Object.DestroyImmediate(value);
            owned.Clear();
            if (scene.IsValid()) { EditorSceneManager.ClosePreviewScene(scene); scene = default; }
            if (counted) { counted = false; LiveCaptures--; }
        }
    }
}
