using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    internal static class TsugimelessStyles
    {
        private static StyleSheet sheet;
        internal static void Apply(VisualElement root)
        {
            if (sheet == null) sheet = AssetDatabase.LoadAssetAtPath<StyleSheet>("Packages/com.horicraft.tsugimeless/Editor/Tsugimeless.uss");
            if (sheet != null && !root.styleSheets.Contains(sheet)) root.styleSheets.Add(sheet);
            root.AddToClassList("tsg-root");
            root.EnableInClassList("tsg-light", !EditorGUIUtility.isProSkin);
        }
        internal static VisualElement Card() { var element = new VisualElement(); element.AddToClassList("tsg-card"); return element; }
        // Card/Guide/Status/EqualRow follow HoriCraft.Katachia.Styles (9baab281).
        // Keep styling local and cached; no dependency on the other product's assembly.
        internal static Label Guide(string text) { var element = new Label(text); element.AddToClassList("tsg-note"); return element; }
        internal static Label Note(string text) => Guide(text);
        internal static Label Status(string text, string name)
        {
            var element = Guide(text); element.name = name; element.AddToClassList("tsg-status"); return element;
        }
        internal static VisualElement EqualRow(params VisualElement[] items)
        {
            var row = new VisualElement(); row.AddToClassList("tsg-equal-row");
            foreach (var item in items) row.Add(item);
            return row;
        }
        internal static VisualElement ChoiceBar(string[] labels, string[] names, int selected, Action<int> changed)
        {
            var buttons = new VisualElement[labels.Length];
            for (int i = 0; i < labels.Length; i++)
            {
                int index = i;
                var button = ColoredButton(labels[i], () => { if (index != selected) changed(index); }, names[i]);
                button.tooltip = labels[i]; button.AddToClassList("tsg-tab");
                button.EnableInClassList("tsg-tab-selected", index == selected); buttons[i] = button;
            }
            return EqualRow(buttons);
        }
        internal static Label Heading(string text) { var element = new Label(text); element.AddToClassList("tsg-heading"); return element; }
        internal static Button SmallButton(string text, Action clicked, string name)
        {
            var button = ColoredButton(text, clicked, name); button.AddToClassList("tsg-small"); return button;
        }
        internal static Button ConfirmButton(string text, Action clicked, string name)
        {
            var button = ColoredButton(text, clicked, name, true); button.AddToClassList("tsg-confirm"); return button;
        }
        internal static Button ColoredButton(string text, Action clicked, string name, bool primary = false)
        {
            var button = new Button(clicked) { text = text, name = name };
            button.AddToClassList("tsg-button");
            button.EnableInClassList("tsg-primary", primary);
            return button;
        }
    }
}
