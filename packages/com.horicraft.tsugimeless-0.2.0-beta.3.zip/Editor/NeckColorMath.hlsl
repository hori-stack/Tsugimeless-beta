// Equations adapted from lilToon 2.3.4 (lilToneCorrection, lilBlendColor,
// lilGradationMap, lilLinearToSRGB, lilSRGBToLinear). The color-space
// approximations are credited by lilToon to Ian Taylor (chilliant).
// MIT License
// Copyright (c) 2020-present lilxyzw
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

float3 SeamTone(float3 c, float4 hsvg)
{
    c = pow(abs(c), hsvg.w);
    float4 p = (c.b > c.g) ? float4(c.bg, -1, 2.0/3.0) : float4(c.gb, 0, -1.0/3.0);
    float4 q = (p.x > c.r) ? float4(p.xyw, c.r) : float4(c.r, p.yzx);
    float d = q.x - min(q.w, q.y);
    float3 hsv = float3(abs(q.z + (q.w-q.y)/(6*d+1e-10)), d/(q.x+1e-10), q.x);
    hsv = float3(hsv.x+hsvg.x, saturate(hsv.y*hsvg.y), saturate(hsv.z*hsvg.z));
    return hsv.z-hsv.z*hsv.y + hsv.z*hsv.y*saturate(abs(frac(hsv.x+float3(1,2.0/3.0,1.0/3.0))*6-3)-1);
}
float3 SeamLinearToSRGB(float3 c) { return saturate(1.055 * pow(abs(c), 0.416666667) - 0.055); }
float3 SeamSRGBToLinear(float3 c) { return c * (c * (c * 0.305306011 + 0.682171111) + 0.012522878); }
float3 SeamBlend(float3 dst, float3 src, float alpha, int mode)
{
    float3 result = src;
    if (mode == 1) result = dst + src;
    if (mode == 2) result = max(dst + src - dst*src, dst);
    if (mode == 3) result = dst * src;
    return lerp(dst, result, alpha);
}
