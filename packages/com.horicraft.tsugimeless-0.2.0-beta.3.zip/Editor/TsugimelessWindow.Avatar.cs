using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    public sealed partial class TsugimelessWindow
    {
        private ObjectField avatarField;
        private HelpBox avatarNotice;
        private Label selectionLocation;
        internal ObjectField AvatarField => avatarField;

        private VisualElement BuildAvatar()
        {
            var card = TsugimelessStyles.Card();
            card.Add(new Label(L.T("編集するアバター", "Avatar to edit")));
            avatarField = new ObjectField { name = "avatar-object", objectType = typeof(GameObject), allowSceneObjects = true };
            avatarField.SetValueWithoutNotify(context.Root);
            avatarField.RegisterValueChangedCallback(evt =>
            {
                context.Select(evt.newValue as GameObject, playBlocked || EditorApplication.isPlayingOrWillChangePlaymode);
                // Keep this native field attached; rebuilding it during its own change event loses picker/D&D state.
                UpdateAvatar();
                RenderBody();
            });
            card.Add(avatarField);
            card.Add(TsugimelessStyles.Note(L.T("Hierarchyからこの欄へドラッグ。右の丸いボタンでも選べます。", "Drag from Hierarchy into this field, or use the round picker button.")));
            selectionLocation = TsugimelessStyles.Note(""); selectionLocation.name = "avatar-location"; card.Add(selectionLocation);
            avatarNotice = new HelpBox("", HelpBoxMessageType.Info) { name = "avatar-notice" };
            avatarNotice.AddToClassList("tsg-help"); card.Add(avatarNotice);
            UpdateAvatar();
            return card;
        }

        private void UpdateAvatar()
        {
            OnNeckTargetChanged();
            if (avatarField == null) return;
            avatarField.SetValueWithoutNotify(context.Root);
            avatarField.SetEnabled(!playBlocked);
            if (selectionLocation != null)
            {
                var root = context.Root;
                var path = root != null ? root.name : "";
                if (root != null)
                {
                    for (var t = root.transform.parent; t != null; t = t.parent) path = t.name + "/" + path;
                    path = root.scene.name + " / " + path + "  (#" + root.GetInstanceID() + ")";
                }
                selectionLocation.text = path;
                selectionLocation.style.display = root != null ? DisplayStyle.Flex : DisplayStyle.None;
            }
            if (avatarNotice != null)
            {
                avatarNotice.text = NoticeText(context.Notice);
                avatarNotice.messageType = context.Notice == SelectionNotice.None || context.Notice == SelectionNotice.SelectAvatar
                    ? HelpBoxMessageType.Info : HelpBoxMessageType.Warning;
                avatarNotice.style.display = context.Notice == SelectionNotice.None ? DisplayStyle.None : DisplayStyle.Flex;
            }
        }

        private static string NoticeText(SelectionNotice notice)
        {
            switch (notice)
            {
                case SelectionNotice.None: return "";
                case SelectionNotice.SceneOnly: return L.T("シーン上のアバターを指定してください。Project内のPrefabには適用しません。", "Select an avatar in the scene. Project prefab assets cannot be edited here.");
                case SelectionNotice.PrefabStage: return L.T("Prefabの編集画面を閉じ、シーン上の1体を指定してください。", "Close Prefab Mode and select one avatar in the scene.");
                case SelectionNotice.PreviewObject: return L.T("表示用の複製は選べません。Hierarchyの元のアバターを指定してください。", "Preview copies cannot be selected. Choose the original avatar in Hierarchy.");
                case SelectionNotice.ChooseRoot: return L.T("アバター全体の親を特定できません。Hierarchyのいちばん上のアバターを指定してください。", "The avatar root could not be identified. Select the top-level avatar in Hierarchy.");
                case SelectionNotice.MultipleAvatars: return L.T("まとめた親は選べません。中にあるアバターを1体指定してください。", "This is an avatar container. Select one avatar inside it.");
                case SelectionNotice.NotAvatar: return L.T("肌を表示するメッシュが見つかりません。アバター全体を指定してください。", "No skinned mesh was found. Select the complete avatar.");
                case SelectionNotice.Lost: return L.T("選択したアバターを確認できなくなりました。もう一度指定してください。", "The selected avatar is no longer available. Select it again.");
                case SelectionNotice.PlayMode: return L.T("Play中は操作できません。停止後にアバターを選び直してください。", "Editing is disabled in Play Mode. Stop and select the avatar again.");
                default: return L.T("上の欄に、編集するアバターを入れてください。", "Place the avatar to edit in the field above.");
            }
        }
    }
}
