using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    internal sealed class NeckDiagnosisSession : IDisposable
    {
        private IEnumerator<float> job;
        private NeckTargets targets;
        private double checkAt;
        private Stopwatch watch;
        private long memoryBefore;
        internal NeckDiagnosis Result { get; private set; }
        internal bool Running => job != null;
        internal float Progress { get; private set; }
        internal NeckDiagnosisState State { get; private set; }
        internal string Error { get; private set; }
        internal static string Signature(NeckTargets targets)
        {
            if (targets == null || !targets.Confirmed || !targets.Valid(out _)) return "invalid";
            var materials = targets.FaceSlots.Select(s => targets.Face.sharedMaterials[s]).Concat(targets.BodySlots.Select(s => targets.Body.sharedMaterials[s])).Distinct();
            return LilToonMaterialRead.Hash(NeckSnapshot.Signature(targets) + "|" + QualitySettings.activeColorSpace + "|" + LilToonMaterialRead.AssetStamp(UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline)
                + "|" + string.Join("|", materials.Select(m => LilToonMaterialRead.Capture(m).signature))
                + "|" + LilToonMaterialRead.AssetStamp(AssetDatabase.LoadAssetAtPath<TextAsset>("Packages/com.horicraft.tsugimeless/Editor/MaterialPropertyDefinitions.json")));
        }
        internal void Begin(NeckTargets input, NeckResult neck, string noGeometryReason)
        {
            Cancel(NeckDiagnosisState.Idle); targets = input;
            if (input == null || !input.Confirmed || !input.Valid(out _) || EditorApplication.isPlayingOrWillChangePlaymode || AnimationMode.InAnimationMode())
            { State = NeckDiagnosisState.Unsupported; Error = "targets / Play / Animation"; return; }
            State = NeckDiagnosisState.Running; watch = Stopwatch.StartNew(); memoryBefore = GC.GetTotalMemory(false);
            Result = new NeckDiagnosis { state = State, stamp = Signature(input), geometryReason = noGeometryReason };
            job = Run(neck).GetEnumerator();
        }
        internal void InvalidateCheck() => checkAt = 0;
        internal bool EnsureCurrent()
        {
            if (Result == null) return false;
            try
            {
                if (!EditorApplication.isPlayingOrWillChangePlaymode && !AnimationMode.InAnimationMode() && Signature(targets) == Result.stamp) return true;
                Cancel(NeckDiagnosisState.Stale); return false;
            }
            catch (Exception e) { Cancel(NeckDiagnosisState.Unsupported); Error = e.GetType().Name + ": " + e.Message; return false; }
        }
        internal bool Tick()
        {
            if (Result == null) return false;
            try
            {
                if (EditorApplication.timeSinceStartup >= checkAt)
                {
                    checkAt = EditorApplication.timeSinceStartup + 1;
                    if (!EnsureCurrent()) return true;
                }
                if (job == null) return false;
                var step = Stopwatch.StartNew(); bool more = job.MoveNext();
                Result.maxStepMs = Math.Max(Result.maxStepMs, step.ElapsedMilliseconds);
                if (more) { Progress = job.Current; return false; }
                job.Dispose(); job = null;
                if (Signature(targets) != Result.stamp) { Cancel(NeckDiagnosisState.Stale); return true; }
                Result.Aggregate(); State = Result.state; Progress = 1; Result.elapsedMs = watch.ElapsedMilliseconds;
                Result.managedHeapDelta = GC.GetTotalMemory(false) - memoryBefore; return true;
            }
            catch (Exception e) { Cancel(NeckDiagnosisState.Unsupported); Error = e.GetType().Name + ": " + e.Message; return true; }
        }
        private IEnumerable<float> Run(NeckResult neck)
        {
            var definitions = NeckPropertyFile.Load();
            foreach (var material in targets.FaceSlots.Select(s => targets.Face.sharedMaterials[s]).Concat(targets.BodySlots.Select(s => targets.Body.sharedMaterials[s])).Distinct())
            { Result.reads.Add(material, LilToonMaterialRead.Capture(material)); yield return .05f; }
            foreach (int face in targets.FaceSlots) foreach (int body in targets.BodySlots)
                Result.materials.Add(NeckMaterialComparison.Compare(Result.reads[targets.Face.sharedMaterials[face]], face, Result.reads[targets.Body.sharedMaterials[body]], body, definitions));
            Result.shared = NeckAnalysis.SharedMaterials(targets); yield return .1f;
            if (neck == null || !neck.Candidate || neck.stamp != NeckSnapshot.Signature(targets)) { Result.reason = Result.geometryReason ?? "neck: no unique current loop"; yield break; }
            Result.normalsMeasured = true; Result.normalMean = neck.meanNormalAngle; Result.normalMax = neck.maxNormalAngle;
            for (int i = 0; i < neck.Pairs.Count; i++) Result.points.Add(new NeckColorPoint { index = i, position = neck.Pairs[i] });
            var faceIndex = new NeckColorSampler.UvIndex(NeckTargets.MeshOf(targets.Face), targets.FaceSlots); yield return .15f;
            var bodyIndex = new NeckColorSampler.UvIndex(NeckTargets.MeshOf(targets.Body), targets.BodySlots); yield return .2f;
            int count = 0;
            foreach (var point in Result.points)
            {
                foreach (bool face in new[] { true, false })
                {
                    var refs = (face ? faceIndex : bodyIndex).References(face ? point.position.face : point.position.body);
                    foreach (var reference in refs)
                    { reference.face = face; reference.pair = point.index; reference.material = Result.reads[(face ? targets.Face : targets.Body).sharedMaterials[reference.slot]]; }
                    (face ? point.face : point.body).AddRange(refs); count += refs.Count;
                    if (count > NeckColorSampler.ReferenceLimit) { Result.reason = "UV reference limit: " + NeckColorSampler.ReferenceLimit; yield break; }
                }
                yield return .2f + .1f * (point.index + 1f) / Result.points.Count;
            }
            string environment = NeckColorSampler.EnvironmentReason();
            var groups = Result.points.SelectMany(p => p.face.Concat(p.body)).GroupBy(r => r.material).ToArray();
            int done = 0;
            foreach (var group in groups)
            {
                var refs = group.ToArray(); string reason = environment ?? LilToonMaterialRead.ColorReason(group.Key);
                if (reason != null) { foreach (var r in refs) r.reason = reason; done += refs.Length; yield return .3f + .7f * done / Math.Max(1, count); continue; }
                for (int start = 0; start < refs.Length; start += NeckColorSampler.BatchLimit)
                {
                    var batch = refs.Skip(start).Take(NeckColorSampler.BatchLimit).ToArray(); Color[] values = null;
                    try { values = NeckColorSampler.Sample(group.Key, batch.Select(r => r.uv).ToArray()); }
                    catch (Exception e) { foreach (var r in batch) r.reason = e.GetType().Name + ": " + e.Message; }
                    Result.batches++; Result.peakBatchBytes = Math.Max(Result.peakBatchBytes, batch.Length * 80);
                    if (values != null) for (int i = 0; i < batch.Length; i++) { batch[i].raw = values[i * 2]; batch[i].evaluated = values[i * 2 + 1]; batch[i].measured = true; }
                    done += batch.Length; yield return .3f + .7f * done / Math.Max(1, count);
                }
            }
        }
        internal void Cancel(NeckDiagnosisState state = NeckDiagnosisState.Cancelled)
        {
            job?.Dispose(); job = null; Result = null; targets = null; State = state; Error = null; Progress = 0; watch?.Stop();
        }
        public void Dispose() => Cancel(NeckDiagnosisState.Idle);
    }
}
