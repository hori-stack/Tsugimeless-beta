using System;
using System.Globalization;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    public sealed partial class TsugimelessWindow
    {
        private NeckIssue seamAutoIssue;
        [Serializable] internal sealed class TesterReport
        {
            public int formatVersion = 1;
            public string capturedUtc, toolVersion, unityVersion, platform, graphicsApi, colorSpace, licenseState;
            public bool avatarSelected, sceneSaved, sceneHasPendingChanges, faceSelected, bodySelected, targetConfirmed;
            public string binding, step, detection, colorResult;
            public int faceSlot, bodySlot, availableLines, upperLine, lowerLine, bandPixels, unreachablePixels;
            public bool rangeReady, bandReady, calculationStale, applied, linePlacementStopped, colorStopped, previewStopped, applyStopped;
            public string maxError, meanError;
        }

        internal string BuildTesterReport()
        {
            // Deliberately enumerate safe scalar fields. Do not serialize Context, materials,
            // exceptions, hierarchy names, paths, mesh/UV data or the license token.
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssetPath("Packages/com.horicraft.tsugimeless/package.json");
            string Number(float? value) => value.HasValue && SeamColorEvaluator.Finite(value.Value)
                ? value.Value.ToString("G7", CultureInfo.InvariantCulture) : "unavailable";
            var report = new TesterReport
            {
                capturedUtc = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture),
                toolVersion = package?.version ?? "unknown", unityVersion = Application.unityVersion,
                platform = Application.platform.ToString(), graphicsApi = SystemInfo.graphicsDeviceType.ToString(),
                colorSpace = QualitySettings.activeColorSpace.ToString(), licenseState = TsugimelessLicense.Status.ToString(),
                avatarSelected = context.Root, sceneSaved = context.Root && !string.IsNullOrEmpty(context.Root.scene.path),
                sceneHasPendingChanges = context.Root && context.Root.scene.isDirty,
                faceSelected = neckTargets?.Face, bodySelected = neckTargets?.Body,
                targetConfirmed = neckTargets?.Confirmed == true, binding = neckTargets?.Binding.ToString() ?? "NoTarget",
                step = seamStep.ToString(), detection = seamAutoIssue.ToString(),
                faceSlot = SeamFaceSlot + 1, bodySlot = SeamBodySlot + 1,
                availableLines = seamRows?.Lines?.Length ?? 0,
                rangeReady = seamUseRows && seamRows?.Ready == true,
                upperLine = seamUseRows ? seamUpperLine + 1 : 0, lowerLine = seamUseRows ? seamLowerLine + 1 : 0,
                bandReady = seamBand?.Valid == true, calculationStale = seamStale,
                linePlacementStopped = !string.IsNullOrEmpty(seamAutoReason), colorStopped = !string.IsNullOrEmpty(seamColorReason),
                previewStopped = !string.IsNullOrEmpty(seamPreviewReason), applyStopped = !string.IsNullOrEmpty(seamApplyReason) && !seamApplied,
                colorResult = seamStale ? "Stale" : !string.IsNullOrEmpty(seamColorReason) ? "Stopped" : seamBake == null ? "NotCalculated" : seamBake.Valid ? "Ready" : "Stopped",
                bandPixels = seamBake?.BandPixels ?? 0, unreachablePixels = seamBake?.UnreachablePixels ?? 0,
                maxError = Number(seamBake?.MaxError), meanError = Number(seamBake?.MeanError), applied = seamApplied
            };
            return JsonUtility.ToJson(report, true);
        }

        private void BuildTesterReportCard()
        {
            var foldout = new Foldout { name = "tester-report", text = L.T("テスト結果を伝える", "Share a test result"), value = false };
            foldout.Add(TsugimelessStyles.Note(L.T("バージョンと処理の状態をまとめます。キー・アバター名・PC名・保存先は含みません。自動送信はしません。",
                "Collect versions and processing status. Keys, avatar names, PC names and file paths are excluded. Nothing is sent automatically.")));
            var content = new TextField { name = "tester-report-content", multiline = true, isReadOnly = true };
            content.style.display = DisplayStyle.None; content.style.height = 180;
            var notice = TsugimelessStyles.Note(""); notice.name = "tester-report-notice";
            var copy = TsugimelessStyles.ColoredButton(L.T("この内容をコピーする", "Copy this information"), () =>
            {
                try { EditorGUIUtility.systemCopyBuffer = content.value; notice.text = L.T("コピーしました。依頼者への返信に貼り付けてください。", "Copied. Paste it into your reply to the tester coordinator."); }
                catch { notice.text = L.T("コピーできませんでした。表示内容を選択してコピーしてください。", "Copy failed. Select the displayed text and copy it manually."); }
            }, "tester-report-copy");
            copy.SetEnabled(false);
            foldout.Add(TsugimelessStyles.ColoredButton(L.T("検証情報を表示する", "Show test information"), () =>
            {
                content.SetValueWithoutNotify(BuildTesterReport()); content.style.display = DisplayStyle.Flex; copy.SetEnabled(true);
                notice.text = L.T("表示した時点の情報です。内容を確認してからコピーしてください。", "This captures the current state. Review it before copying.");
            }, "tester-report-show"));
            foldout.Add(content); foldout.Add(copy); foldout.Add(notice);
            var photo = TsugimelessStyles.ColoredButton(L.T("写真付きの報告を作る", "Create a report with photos"), () => TesterReportWindow.Open(CaptureTesterReport()), "tester-report-photos", true);
            photo.SetEnabled(!EditorApplication.isPlayingOrWillChangePlaymode);
            foldout.Add(photo); body.Add(foldout);
        }

        internal TesterReportBundle CaptureTesterReport()
        {
            var bundle = new TesterReportBundle();
            bundle.Document.diagnostics = JsonUtility.FromJson<TesterReport>(BuildTesterReport());
            if (EditorApplication.isPlayingOrWillChangePlaymode) { bundle.Document.photoReason = "PlayMode"; return bundle; }
            if (neckTargets?.Root != context.Root || !context.Root || !neckTargets.Valid(out _) || SeamFaceSlot < 0 || SeamBodySlot < 0)
            { bundle.Document.photoReason = "SelectFaceAndBody"; return bundle; }
            Texture2D replacement = null;
            try
            {
                var face = neckTargets.Face.sharedMaterials[SeamFaceSlot];
                var current = neckTargets.Body.sharedMaterials[SeamBodySlot];
                bundle.Document.materials.Add(TesterMaterialReport.Capture("Face", neckTargets.Face, face));
                bundle.Document.materials.Add(TesterMaterialReport.Capture("CurrentBody", neckTargets.Body, current));
                bool sameGeometry = NeckSnapshot.Signature(neckTargets) == seamSignature;
                // This is intentionally read-only; ColorInputCurrent() would discard the user's preview.
                bool candidate = TsugimelessLicense.Active && !seamStale && seamBake?.Valid == true && sameGeometry
                    && seamComputedFrom && ColorStamp(seamComputedFrom) == seamColorStamp;
                bool hasBaseline = NeckHistoryStore.TryBaseline(context.Root, neckTargets.Body, SeamBodySlot, out var baseline, out _);
                if (!hasBaseline) baseline = current;
                if (candidate) baseline = seamComputedFrom;
                if (baseline != current) bundle.Document.materials.Add(TesterMaterialReport.Capture("OriginalBody", neckTargets.Body, baseline));
                var band = sameGeometry ? seamBand : null;
                if (!TesterPhotoCapture.Frame(neckTargets, band, out var center, out var forward, out var up, out float size))
                { bundle.Document.photoReason = "NeckFrameUnavailable"; return bundle; }
                if (candidate) replacement = NeckHistoryImage.Preview(seamBake.Candidate, baseline.GetTexture(seamBake.TextureProperty) as Texture2D);
                bool compareOriginal = !candidate && hasBaseline && baseline != current;
                using (var capture = new TesterPhotoCapture(neckTargets.Face, SeamFaceSlot, neckTargets.Body, SeamBodySlot))
                {
                    var names = new[] { "front", "left", "right", "back" }; var angles = new[] { 0f, -30f, 30f, 180f };
                    for (int i = 0; i < names.Length; i++)
                    {
                        if (candidate || compareOriginal)
                            bundle.Photos.Add(new TesterReportPhoto("before-" + names[i] + ".png", capture.Render(baseline, null, null, center, forward, up, size, angles[i])));
                        bundle.Photos.Add(new TesterReportPhoto((candidate ? "after-" : "current-") + names[i] + ".png",
                            capture.Render(candidate ? baseline : current, replacement, candidate ? seamBake.TextureProperty : null, center, forward, up, size, angles[i])));
                    }
                }
                bundle.Document.photoState = candidate ? "ComputedPreview" : compareOriginal ? "CurrentVsOriginal" : "CurrentOnly";
                bundle.Document.photoReason = band?.Valid == true ? "SelectedBand" : "NeckBonesFallback";
            }
            catch (Exception error)
            {
                bundle.Photos.Clear(); bundle.Document.photoState = "Unavailable";
                bundle.Document.photoReason = "CaptureFailed/" + error.GetType().Name;
            }
            finally { if (replacement) DestroyImmediate(replacement); }
            return bundle;
        }
    }
}
