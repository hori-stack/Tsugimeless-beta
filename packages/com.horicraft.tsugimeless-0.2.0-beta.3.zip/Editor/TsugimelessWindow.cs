using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    // Append only: Unity stores these values in saved window layouts.
    internal enum WorkflowPage { Start, Surface, Neck, Seam, Settings, History }

    public sealed partial class TsugimelessWindow : EditorWindow
    {
        [SerializeField] private AvatarContext context = new AvatarContext();
        [SerializeField] private WorkflowPage page;
        [SerializeField] private WorkflowPage lastWorkPage;
        private VisualElement body;
        private VisualElement workflowFooter, avatarCard, mainTabs;
        private Label workflowProgress;
        private bool playBlocked;
        internal AvatarContext Context => context;
        internal WorkflowPage Page => page;

        [MenuItem("HoriCraft/ツギメレス", false, 201)]
        public static void Open() => GetWindow<TsugimelessWindow>().Show();

        private void OnEnable()
        {
            RestoreWorkflowPage();
            InitializeNeck(); InitializeDiagnosis();
            titleContent = new GUIContent("ツギメレス");
            minSize = new Vector2(360, 460);
            if (context == null) context = new AvatarContext();
            playBlocked = EditorApplication.isPlayingOrWillChangePlaymode;
            if (playBlocked) context.Clear(SelectionNotice.PlayMode);
            else context.Reconcile();
            EditorApplication.hierarchyChanged += OnHierarchyChanged;
            EditorApplication.playModeStateChanged += HandlePlayMode;
            InitializeSeam();   // after Reconcile: restoring the lines needs the resolved avatar
        }

        private void OnDisable()
        {
            DisposeSeam(); DisposeDiagnosis(); DisposeNeck();
            EditorApplication.hierarchyChanged -= OnHierarchyChanged;
            EditorApplication.playModeStateChanged -= HandlePlayMode;
        }

        public void CreateGUI()
        {
            RestoreWorkflowPage();
            if (context == null) context = new AvatarContext();
            context.Reconcile();
            rootVisualElement.Clear();
            TsugimelessStyles.Apply(rootVisualElement);
            body = null; workflowFooter = null;
            var header = new VisualElement { name = "workflow-header" }; header.AddToClassList("tsg-header"); rootVisualElement.Add(header);
            var brand = new VisualElement(); brand.AddToClassList("tsg-brand-row"); header.Add(brand);
            var title = new Label("ツギメレス"); title.AddToClassList("tsg-title"); brand.Add(title);
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssetPath("Packages/com.horicraft.tsugimeless/package.json");
            if (package != null) { var version = TsugimelessStyles.Note(package.version); version.AddToClassList("tsg-version"); brand.Add(version); }
            var spacer = new VisualElement(); spacer.style.flexGrow = 1; brand.Add(spacer);
            var language = new ToolbarMenu { text = new[] { "日本語", "English", "简体中文", "한국어" }[Mathf.Clamp(L.Language, 0, 3)] };
            var names = new[] { "日本語", "English", "简体中文", "한국어" };
            for (var i = 0; i < names.Length; i++)
            {
                var selected = i;
                language.menu.AppendAction(names[i], _ => { L.Language = selected; CreateGUI(); });
            }
            language.AddToClassList("tsg-language"); brand.Add(language);
            mainTabs = new VisualElement { name = "main-tabs" }; mainTabs.AddToClassList("tsg-main-tabs"); header.Add(mainTabs);
            workflowProgress = TsugimelessStyles.Note(""); workflowProgress.name = "workflow-progress"; header.Add(workflowProgress);
            var scroll = new ScrollView(ScrollViewMode.Vertical) { name = "workflow-scroll" }; scroll.AddToClassList("tsg-content"); rootVisualElement.Add(scroll);
            avatarCard = BuildAvatar(); scroll.Add(avatarCard);
            body = new VisualElement { name = "workflow-body" }; scroll.Add(body);
            workflowFooter = new VisualElement { name = "workflow-footer" }; workflowFooter.AddToClassList("tsg-footer"); rootVisualElement.Add(workflowFooter);
            RenderBody();
        }

        private void RestoreWorkflowPage()
        {
            if (lastWorkPage != WorkflowPage.Start && lastWorkPage != WorkflowPage.Seam) lastWorkPage = WorkflowPage.Start;
            // Older window layouts can retain the retired diagnostics pages.
            if (page != WorkflowPage.Surface && page != WorkflowPage.Neck) return;
            CancelNeck(NeckIssue.None); page = WorkflowPage.Start;
        }

        private void OnHierarchyChanged()
        {
            context.Reconcile();
            UpdateAvatar();
            RenderBody();
        }

        internal void HandlePlayMode(PlayModeStateChange state)
        {
            CancelNeck(NeckIssue.Stale); ResetSeam();
            playBlocked = state != PlayModeStateChange.EnteredEditMode;
            context.Clear(playBlocked ? SelectionNotice.PlayMode : SelectionNotice.SelectAvatar);
            UpdateAvatar(); RenderBody();
        }
    }
}
