using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    internal sealed class NeckViewController
    {
        private sealed class SavedView
        {
            internal Vector3 pivot, lastPivot;
            internal Quaternion rotation, lastRotation;
            internal float size, lastSize;
            internal bool orthographic, in2DMode, rotationLocked;
            internal SceneView.CameraSettings settings;
        }
        private readonly Dictionary<SceneView, SavedView> saved = new Dictionary<SceneView, SavedView>();
        private SceneView latest;
        internal bool CanRestore => latest != null && saved.ContainsKey(latest);

        internal bool Focus(NeckResult result, NeckTargets targets, NeckViewAngle angle = NeckViewAngle.Oblique)
        {
            if (result == null || targets?.Root == null) return false;
            // Root orientation is the avatar's forward convention; bone local axes differ between rigs.
            if (!NeckViewFrame.TryCreate(result.Candidate ? result.Pairs : result.rejected, targets.Root.transform.forward, targets.Root.transform.up, angle, out var frame)) return false;
            var view = SceneView.lastActiveSceneView;
            if (view == null) view = EditorWindow.GetWindow<SceneView>();
            return Apply(view, frame);
        }
        internal bool Apply(SceneView view, NeckViewFrame frame)
        {
            if (view == null) return false;
            if (!saved.TryGetValue(view, out var state))
            {
                state = new SavedView { pivot = view.pivot, rotation = view.rotation, size = view.size, orthographic = view.orthographic,
                    in2DMode = view.in2DMode, rotationLocked = view.isRotationLocked, settings = CopySettings(view.cameraSettings) };
                saved.Add(view, state);
            }
            latest = view;
            Set2DMode(view, false); view.isRotationLocked = false;
            // Manual near planes can clip a small neck completely; restore the original settings on return.
            var settings = CopySettings(view.cameraSettings); settings.dynamicClip = true; settings.fieldOfView = 50;
            view.cameraSettings = settings;
            view.LookAt(frame.Center, frame.Rotation, frame.Size, false, true);
            state.lastPivot = frame.Center; state.lastRotation = frame.Rotation; state.lastSize = frame.Size;
            view.Show(); view.Focus(); view.Repaint(); return true;
        }
        internal bool Restore()
        {
            if (!CanRestore) return false;
            Restore(latest, saved[latest]); saved.Remove(latest); latest = null;
            foreach (var view in saved.Keys) if (view != null) { latest = view; break; }
            return true;
        }
        private static void Restore(SceneView view, SavedView state)
        {
            Set2DMode(view, state.in2DMode); view.isRotationLocked = state.rotationLocked;
            view.cameraSettings = CopySettings(state.settings);
            view.LookAt(state.pivot, state.rotation, state.size, state.orthographic, true); view.Repaint();
        }
        private static SceneView.CameraSettings CopySettings(SceneView.CameraSettings value)
            => JsonUtility.FromJson<SceneView.CameraSettings>(JsonUtility.ToJson(value));
        private static void Set2DMode(SceneView view, bool value)
        {
            var tool = Tools.current; view.in2DMode = value;
            if (Tools.current != tool) Tools.current = tool;
        }
        internal void Dispose()
        {
            foreach (var pair in saved)
            {
                var view = pair.Key; var s = pair.Value;
                if (view != null && Vector3.Distance(view.pivot, s.lastPivot) < .00001f && Quaternion.Angle(view.rotation, s.lastRotation) < .01f
                    && Mathf.Abs(view.size - s.lastSize) < .00001f && !view.in2DMode && !view.orthographic)
                    Restore(view, s); // Preserve a view the user subsequently moved by hand.
            }
            saved.Clear(); latest = null;
        }
    }
}
