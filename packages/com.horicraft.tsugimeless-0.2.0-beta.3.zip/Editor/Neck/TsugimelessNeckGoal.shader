Shader "Hidden/HoriCraft/TsugimelessNeckGoal"
{
    Properties
    {
        _MainTex ("Current or candidate", 2D) = "black" {}
        _WeightTex ("Band weight", 2D) = "black" {}
        _GainTex ("Gain (scaled)", 2D) = "white" {}
        _SourceTex ("Original MainTex", 2D) = "black" {}
        _GainScale ("Gain scale", Float) = 1
    }
    CGINCLUDE
    #include "UnityCG.cginc"
    Texture2D _MainTex, _WeightTex, _GainTex, _SourceTex;
    SamplerState sampler_MainTex;
    SamplerState sampler_SourceTex;
    SamplerState neck_point_clamp_sampler;
    float _GainScale;

    // goal = current * lerp(1, gain, w). 帯の外（w=0）では goal が current と同じになるので、
    // ソルバーは元の MainTex をそのまま答えにできる。
    float4 Goal(v2f_img i) : SV_Target
    {
        float4 current = _MainTex.SampleLevel(sampler_MainTex, i.uv, 0);
        float weight = saturate(_WeightTex.SampleLevel(neck_point_clamp_sampler, i.uv, 0).r);
        float3 gain = _GainTex.SampleLevel(neck_point_clamp_sampler, i.uv, 0).rgb * _GainScale;
        return float4(current.rgb * lerp(float3(1,1,1), gain, weight), current.a);
    }

    // 帯の外は、求めた候補ではなく元の MainTex の画素をそのまま返す。
    // 丸め誤差で帯の外が 1/255 でも動くのを避けるため。
    float4 PreserveOutside(v2f_img i) : SV_Target
    {
        float4 candidate = _MainTex.SampleLevel(sampler_MainTex, i.uv, 0);
        float4 source = _SourceTex.SampleLevel(sampler_SourceTex, i.uv, 0);
        float weight = _WeightTex.SampleLevel(neck_point_clamp_sampler, i.uv, 0).r;
        return weight > 0 ? candidate : source;
    }
    ENDCG
    SubShader
    {
        Cull Off ZWrite Off ZTest Always
        Pass
        {
            CGPROGRAM
            #pragma target 4.5
            #pragma vertex vert_img
            #pragma fragment Goal
            ENDCG
        }
        Pass
        {
            CGPROGRAM
            #pragma target 4.5
            #pragma vertex vert_img
            #pragma fragment PreserveOutside
            ENDCG
        }
    }
    Fallback Off
}
