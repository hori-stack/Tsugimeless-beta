using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    /// <summary>首の帯を決めるときの調整値。既定値は fable-evaluation §2 項目4 のもの。</summary>
    internal sealed class NeckBandSettings
    {
        /// <summary>上端の半径の何倍までを帯に入れるか（腕・肩を落とすため）。</summary>
        internal float radiusFactor = 1.6f;

        /// <summary>隣の面へ広がるときに止める折れ角（度）。</summary>
        internal float growAngleDeg = 60f;

        /// <summary>上の点から何 mm 以内の開いた辺へ吸着するか。</summary>
        internal float snapDistanceMm = 5f;

        /// <summary>上下の線がこれより近ければ失敗にする（mm）。</summary>
        internal float minHeightGapMm = 3f;

        /// <summary>高さで面を拾うときの上下の余裕（mm）。</summary>
        internal float marginMm = 2f;

        /// <summary>首穴の縁（開いた辺）へ吸着するか。</summary>
        internal bool snapToBoundary = true;
    }

    /// <summary>首の帯の計算結果。すべてワールド座標。</summary>
    internal sealed class NeckBandResult
    {
        internal bool Valid;

        /// <summary>失敗の理由（L.T 済み）。成功でも上下を入れ替えたときは知らせを入れる。</summary>
        internal string Reason;

        /// <summary>高さと角度を測る原点と軸（軸は正規化済み）。</summary>
        internal Vector3 Origin, Axis;

        /// <summary>軸まわりの角度を測るための基準（Axis と直交する 2 本）。</summary>
        internal Vector3 BasisX, BasisZ;

        /// <summary>クリックした2点の高さ（m）。報告用で、帯の実際の上下は区画ごとに持つ。</summary>
        internal float HLow, HUp;

        /// <summary>上端を首穴の縁（開いた辺の輪）から取れたか。</summary>
        internal bool Snapped;

        internal int SectorCount;

        /// <summary>区画ごとの上端の高さ。吸着しなかったときはどこも HUp。</summary>
        internal float[] HUpBySector;

        /// <summary>区画ごとの下端の高さ（上端から Thickness だけ下）。吸着しなければどこも HLow。</summary>
        internal float[] HLowBySector;

        /// <summary>帯の厚み（m）。下の線を置いた場所での、縁から下の線までの距離。どの区画でも同じ。</summary>
        internal float Thickness;

        /// <summary>帯の三角形。body.triangles の三角形番号 k（頂点は triangles[3k..3k+2]）。</summary>
        internal int[] Triangles;

        /// <summary>体の頂点ごとの値。T は帯の外では 0、Theta は 0〜2π。</summary>
        internal float[] T;
        internal bool[] InBand;
        internal float[] Theta;

        /// <summary>表示用の輪（36 点）。</summary>
        internal Vector3[] UpperRing, LowerRing;
        internal bool FollowsMeshRows;

        /// <summary>報告用の数値。</summary>
        internal string Summary;

        /// <summary>帯に入れる半径の上限（m）。基準色を採る側でも使う。</summary>
        internal float RadiusLimit;

        internal float Height(Vector3 point) => Vector3.Dot(point - Origin, Axis);

        internal Vector3 Radial(Vector3 point)
        {
            var offset = point - Origin;
            return offset - Axis * Vector3.Dot(offset, Axis);
        }

        internal float Radius(Vector3 point) => Radial(point).magnitude;

        /// <summary>軸まわりの角度（0〜2π）。</summary>
        internal float Angle(Vector3 point)
        {
            var radial = Radial(point);
            float value = Mathf.Atan2(Vector3.Dot(radial, BasisZ), Vector3.Dot(radial, BasisX));
            if (value < 0) value += 2 * Mathf.PI;
            if (value >= 2 * Mathf.PI) value = 0;
            return value;
        }

        internal int Sector(float angle)
        {
            if (SectorCount <= 0) return 0;
            int index = Mathf.FloorToInt(angle / (2 * Mathf.PI / SectorCount));
            return Mathf.Clamp(index, 0, SectorCount - 1);
        }

        /// <summary>その角度での上端の高さ（区画の中心どうしを円周方向に線形補間）。</summary>
        internal float UpperAt(float angle) => FollowsMeshRows
            ? NeckMeshRows.At(UpperRing, Origin, Axis, BasisX * Mathf.Cos(angle) + BasisZ * Mathf.Sin(angle))
            : NeckBand.Circular(HUpBySector, angle, HUp);

        /// <summary>その角度での下端の高さ。上端と同じ形のまま Thickness だけ下をなぞる。</summary>
        internal float LowerAt(float angle) => FollowsMeshRows
            ? NeckMeshRows.At(LowerRing, Origin, Axis, BasisX * Mathf.Cos(angle) + BasisZ * Mathf.Sin(angle))
            : NeckBand.Circular(HLowBySector, angle, HLow);
    }

    /// <summary>
    /// 2 本の線（2 点）から首の帯を決める。
    ///
    /// 高さ h は軸に沿った距離、角度 theta は軸まわりの向き。帯に入れるのは
    ///  ①高さが下の線〜上の線（＋余裕）に入る面、②軸からの半径が上端の半径×係数まで、
    ///  ③上端に接する面からつながっている面 の 3 つを満たすものだけ。
    /// ②③で腕・肩・胸を落とす。
    ///
    /// 上端は、首穴の縁（1 つの三角形にしか使われていない辺）が上の点の近くにあれば
    /// その輪へ吸着する。首の後ろで境目の高さが違うアバターで、帯の上端が実物の境目に沿う。
    /// 輪が見つからなければ平面（どの角度でも同じ高さ）に戻す。
    ///
    /// 下端は<b>上端と同じ形のまま Thickness だけ下</b>を通る。下の線を平らな面のままにすると、
    /// 縁が後ろで 20 mm 下がっているアバターで帯が前は厚く後ろは薄くなり、
    /// 後ろの区画に色を採る場所が残らない（Milltina 実測）。厚みは「下の線を置いた場所で、
    /// その場所の縁から何 mm 下か」で決める。
    /// </summary>
    internal static class NeckBand
    {
        internal const int DefaultSectors = 12;
        internal const int RingPoints = 36;
        private const float WeldDistance = .00001f;

        /// <summary>上端に接するとみなす幅（m）。種の面を選ぶときと半径を測るときに使う。</summary>
        private const float TopBand = .003f;

        internal static NeckBandResult Compute(NeckSnapshot snapshot, Vector3 upperWorld, Vector3 lowerWorld, NeckBandSettings settings = null,
            Vector3[] upperRing = null, Vector3[] lowerRing = null)
        {
            settings = settings ?? new NeckBandSettings();
            var result = new NeckBandResult { SectorCount = DefaultSectors };
            var body = snapshot?.body;
            if (body == null || body.positions == null || body.positions.Length == 0 || body.triangles == null || body.triangles.Length < 3
                || !NeckSnapshot.Finite(upperWorld) || !NeckSnapshot.Finite(lowerWorld))
            {
                result.Reason = L.T("首の帯を作る体の形を読み取れません。顔・体の指定を確認してください。", "The body shape for the neck band could not be read. Check the face and body selection.");
                return Empty(result, body);
            }

            // ── 軸と原点 ──────────────────────────────────────────────
            bool neckHead = NeckSnapshot.Finite(snapshot.neck) && NeckSnapshot.Finite(snapshot.head) && (snapshot.head - snapshot.neck).sqrMagnitude > 1e-8f;
            bool chestHead = NeckSnapshot.Finite(snapshot.chest) && NeckSnapshot.Finite(snapshot.head) && (snapshot.head - snapshot.chest).sqrMagnitude > 1e-8f;
            if (neckHead) { result.Axis = (snapshot.head - snapshot.neck).normalized; result.Origin = snapshot.neck; }
            else if (chestHead) { result.Axis = (snapshot.head - snapshot.chest).normalized; result.Origin = lowerWorld; }
            else
            {
                var manual = upperWorld - lowerWorld;
                if (manual.sqrMagnitude <= 1e-8f)
                {
                    result.Reason = L.T("首の向きを決められません。骨のあるアバターか、離れた2点を指定してください。", "The neck direction could not be decided. Use an avatar with bones, or two points further apart.");
                    return Empty(result, body);
                }
                result.Axis = manual.normalized; result.Origin = lowerWorld;
            }

            // 軸まわりの角度を毎回同じ向きで測るための基準
            var reference = Mathf.Abs(Vector3.Dot(result.Axis, Vector3.up)) > .9f ? Vector3.forward : Vector3.up;
            result.BasisX = Vector3.Normalize(Vector3.Cross(reference, result.Axis));
            result.BasisZ = Vector3.Cross(result.Axis, result.BasisX);
            result.FollowsMeshRows = upperRing != null && lowerRing != null;
            if (result.FollowsMeshRows)
            {
                result.UpperRing = upperRing; result.LowerRing = lowerRing;
                var rows = new NeckMeshRows { Origin = result.Origin, Axis = result.Axis };
                if (rows.Gap(upperRing, lowerRing) < settings.minHeightGapMm / 1000f)
                { result.Reason = L.T("2本の線が近すぎます。下の線をもう1段下げてください。", "The lines are too close. Move the lower line down one more row."); return Empty(result, body); }
            }

            // ── 上下の高さ ────────────────────────────────────────────
            float upper = result.FollowsMeshRows ? upperRing.Average(result.Height) : result.Height(upperWorld);
            float lower = result.FollowsMeshRows ? lowerRing.Average(result.Height) : result.Height(lowerWorld);
            bool swapped = upper < lower;
            if (swapped)
            {
                var keepPoint = upperWorld; upperWorld = lowerWorld; lowerWorld = keepPoint;
                float keep = upper; upper = lower; lower = keep;
            }
            result.HUp = upper; result.HLow = lower;
            if (upper - lower < settings.minHeightGapMm / 1000f)
            {
                result.Reason = L.F("2本の線が近すぎます。{0:F1} mm以上離してください。", "The two lines are too close. Keep them at least {0:F1} mm apart.", settings.minHeightGapMm);
                return Empty(result, body);
            }
            if (swapped) result.Reason = L.T("上下の線が逆だったので、入れ替えて使いました。", "The two lines were the wrong way round, so they were swapped.");

            // ── 高さ・角度・半径 ──────────────────────────────────────
            var positions = body.positions;
            int count = positions.Length;
            var heights = new float[count];
            var radii = new float[count];
            result.Theta = new float[count];
            for (int i = 0; i < count; i++)
            {
                heights[i] = result.Height(positions[i]);
                radii[i] = result.Radius(positions[i]);
                result.Theta[i] = result.Angle(positions[i]);
            }

            // ── 吸着（首穴の縁の輪）。帯の上下を決める前に、縁の形を先に取る ──
            var welded = Weld(positions);
            result.HUpBySector = Enumerable.Repeat(upper, result.SectorCount).ToArray();
            int loopNodes = 0;
            if (settings.snapToBoundary && !result.FollowsMeshRows)
                loopNodes = Snap(result, body, positions, welded, heights, upperWorld, upper, settings.snapDistanceMm / 1000f);

            // ── 帯の厚み。下の線は「その場所の縁からどれだけ下か」で効く ──
            // 縁が首の後ろで下がっているアバターでは、平らな下の線のままだと
            // 前が厚く後ろが薄い帯になり、後ろの区画に色を採る場所が残らない。
            result.Thickness = result.FollowsMeshRows ? upper - lower : result.UpperAt(result.Angle(lowerWorld)) - lower;
            if (result.Thickness < settings.minHeightGapMm / 1000f)
            {
                result.Reason = L.F("下の線が、その場所の首穴の縁に近すぎます。{0:F1} mm以上離してください。", "The lower line is too close to the neck opening at that spot. Keep them at least {0:F1} mm apart.", settings.minHeightGapMm);
                return Empty(result, body);
            }
            result.HLowBySector = result.HUpBySector.Select(v => v - result.Thickness).ToArray();
            if (result.FollowsMeshRows)
                for (int s = 0; s < result.SectorCount; s++)
                {
                    float angle = (s + .5f) * 2 * Mathf.PI / result.SectorCount;
                    result.HUpBySector[s] = result.UpperAt(angle); result.HLowBySector[s] = result.LowerAt(angle);
                }

            // 頂点ごとの上端・下端（区画の中心どうしを補間した値。t と同じ物差しを使う）
            var vertexTop = new float[count];
            var vertexLow = new float[count];
            for (int i = 0; i < count; i++)
            {
                vertexTop[i] = result.UpperAt(result.Theta[i]);
                vertexLow[i] = result.LowerAt(result.Theta[i]);
            }

            // ── ①高さで面を拾う（区画ごとの上端・下端で） ────────────
            float margin = settings.marginMm / 1000f;
            int faces = body.triangles.Length / 3;
            var candidate = new bool[faces];
            var nearTop = new List<float>();
            var everyRadius = new List<float>();
            for (int face = 0; face < faces; face++)
            {
                bool inside = false;
                for (int corner = 0; corner < 3; corner++)
                {
                    int vertex = body.triangles[face * 3 + corner];
                    if (heights[vertex] >= vertexLow[vertex] - margin && heights[vertex] <= vertexTop[vertex] + margin) { inside = true; break; }
                }
                if (!inside) continue;
                candidate[face] = true;
                for (int corner = 0; corner < 3; corner++)
                {
                    int vertex = body.triangles[face * 3 + corner];
                    everyRadius.Add(radii[vertex]);
                    if (Mathf.Abs(heights[vertex] - vertexTop[vertex]) <= TopBand) nearTop.Add(radii[vertex]);
                }
            }
            if (everyRadius.Count == 0)
            {
                result.Reason = L.T("その高さには体の面がありません。線の位置を確認してください。", "There is no body surface at that height. Check where the lines are.");
                return Empty(result, body);
            }
            float topRadius = Median(nearTop.Count > 0 ? nearTop : everyRadius);
            result.RadiusLimit = Mathf.Max(topRadius * Mathf.Max(settings.radiusFactor, 1f), 1e-4f);

            // ── ②半径で落とす ────────────────────────────────────────
            for (int face = 0; face < faces; face++)
            {
                if (!candidate[face]) continue;
                var centre = (positions[body.triangles[face * 3]] + positions[body.triangles[face * 3 + 1]] + positions[body.triangles[face * 3 + 2]]) / 3f;
                if (result.Radius(centre) > result.RadiusLimit) candidate[face] = false;
            }

            // ── ③上端に接する面からつながっているものだけ ────────────
            var band = Grow(body, positions, candidate, welded, heights, vertexTop, settings.growAngleDeg);
            if (band.Count == 0)
            {
                result.Reason = L.T("首の帯になる面が見つかりません。線の位置と、顔・体の指定を確認してください。", "No surface was found for the neck band. Check the lines and the face and body selection.");
                return Empty(result, body);
            }
            result.Triangles = band.OrderBy(f => f).ToArray();

            // ── 頂点ごとの t ──────────────────────────────────────────
            result.T = new float[count];
            result.InBand = new bool[count];
            foreach (int face in result.Triangles)
                for (int corner = 0; corner < 3; corner++)
                    result.InBand[body.triangles[face * 3 + corner]] = true;
            for (int i = 0; i < count; i++)
            {
                if (!result.InBand[i]) continue;
                result.T[i] = Mathf.Clamp01((heights[i] - vertexLow[i]) / Mathf.Max(vertexTop[i] - vertexLow[i], 1e-6f));
            }

            // ── 表示用の輪 ────────────────────────────────────────────
            if (!result.FollowsMeshRows) Rings(result, positions, heights);

            result.Valid = true;
            result.Summary = Describe(result, band.Count, loopNodes, settings);
            return result;
        }

        private static NeckBandResult Empty(NeckBandResult result, NeckSurface body)
        {
            int count = body?.positions?.Length ?? 0;
            result.Valid = false;
            result.SectorCount = DefaultSectors;
            result.HUpBySector = result.HUpBySector ?? Enumerable.Repeat(result.HUp, DefaultSectors).ToArray();
            result.HLowBySector = result.HLowBySector ?? Enumerable.Repeat(result.HLow, result.HUpBySector.Length).ToArray();
            result.Triangles = result.Triangles ?? Array.Empty<int>();
            result.T = result.T ?? new float[count];
            result.InBand = result.InBand ?? new bool[count];
            result.Theta = result.Theta ?? new float[count];
            result.UpperRing = result.UpperRing ?? Array.Empty<Vector3>();
            result.LowerRing = result.LowerRing ?? Array.Empty<Vector3>();
            result.Summary = result.Summary ?? result.Reason ?? "";
            return result;
        }

        // ── つながりで広げる ──────────────────────────────────────────

        // 統合版 BodyRegionTopology.Grow と同じ考え方。辺は「位置が同じ（1e-5 m で溶接）かつ
        // UV が同じ」ときだけつながり、面どうしの折れ角が大きければそこで止める。
        private static HashSet<int> Grow(NeckSurface body, Vector3[] positions, bool[] candidate, int[] welded,
                                         float[] heights, float[] vertexTop, float angleDeg)
        {
            var result = new HashSet<int>();
            var indices = body.triangles;
            int faces = indices.Length / 3;
            var uv = body.uv != null && body.uv.Length == positions.Length ? body.uv : null;

            var keys = new Dictionary<(int, Vector2), int>();
            int Key(int vertex)
            {
                var key = (welded[vertex], uv != null ? uv[vertex] : Vector2.zero);
                if (!keys.TryGetValue(key, out int id)) keys.Add(key, id = keys.Count);
                return id;
            }

            var edges = new Dictionary<long, List<int>>();
            var normals = new Vector3[faces];
            var members = new List<int>();
            for (int face = 0; face < faces; face++)
            {
                if (!candidate[face]) continue;
                members.Add(face);
                int a = indices[face * 3], b = indices[face * 3 + 1], c = indices[face * 3 + 2];
                normals[face] = FaceNormal(positions[a], positions[b], positions[c]);
                for (int e = 0; e < 3; e++)
                {
                    int x = Key(indices[face * 3 + e]), y = Key(indices[face * 3 + (e + 1) % 3]);
                    long edge = Edge(x, y);
                    if (!edges.TryGetValue(edge, out var list)) edges.Add(edge, list = new List<int>());
                    list.Add(face);
                }
            }

            var adjacent = new Dictionary<int, HashSet<int>>();
            float cosine = Mathf.Cos(Mathf.Clamp(angleDeg, 0, 180) * Mathf.Deg2Rad);
            foreach (var list in edges.Values)
                for (int a = 0; a < list.Count; a++) for (int b = a + 1; b < list.Count; b++)
                {
                    int x = list[a], y = list[b];
                    if (x == y || normals[x].sqrMagnitude == 0 || normals[y].sqrMagnitude == 0 ||
                        Vector3.Dot(normals[x], normals[y]) + 1e-6f < cosine) continue;
                    if (!adjacent.TryGetValue(x, out var first)) adjacent.Add(x, first = new HashSet<int>());
                    if (!adjacent.TryGetValue(y, out var second)) adjacent.Add(y, second = new HashSet<int>());
                    first.Add(y); second.Add(x);
                }

            var queue = new Queue<int>();
            foreach (int face in members)
            {
                bool touchesTop = false;
                for (int corner = 0; corner < 3; corner++)
                {
                    int vertex = indices[face * 3 + corner];
                    if (heights[vertex] >= vertexTop[vertex] - TopBand) { touchesTop = true; break; }
                }
                if (touchesTop && result.Add(face)) queue.Enqueue(face);
            }
            // 上端に触れる面が 1 枚も無いときは、帯そのものが上の線に届いていない。
            // 黙って全部を選ぶより、候補のうち最も上端に近い面から広げた方が使い手に近い。
            if (result.Count == 0 && members.Count > 0)
            {
                int best = members.OrderByDescending(f => Enumerable.Range(0, 3).Max(c => heights[indices[f * 3 + c]] - vertexTop[indices[f * 3 + c]])).First();
                result.Add(best); queue.Enqueue(best);
            }
            while (queue.Count > 0)
                if (adjacent.TryGetValue(queue.Dequeue(), out var next))
                    foreach (int face in next) if (result.Add(face)) queue.Enqueue(face);
            return result;
        }

        // ── 首穴の縁への吸着 ──────────────────────────────────────────

        // 戻り値は採用した輪の頂点数（吸着しなかったら 0）。
        private static int Snap(NeckBandResult result, NeckSurface body, Vector3[] positions, int[] welded,
                                float[] heights, Vector3 upperWorld, float upper, float snapDistance)
        {
            var indices = body.triangles;
            var uses = new Dictionary<long, int>();
            for (int i = 0; i < indices.Length; i += 3)
                for (int j = 0; j < 3; j++)
                {
                    int a = welded[indices[i + j]], b = welded[indices[i + (j + 1) % 3]];
                    if (a == b) continue;
                    long edge = Edge(a, b);
                    uses[edge] = uses.TryGetValue(edge, out int used) ? used + 1 : 1;
                }

            var neighbours = new Dictionary<int, HashSet<int>>();
            foreach (var pair in uses)
            {
                if (pair.Value != 1) continue;
                int a = (int)(pair.Key >> 32), b = (int)pair.Key;
                if (!neighbours.TryGetValue(a, out var first)) neighbours.Add(a, first = new HashSet<int>());
                if (!neighbours.TryGetValue(b, out var second)) neighbours.Add(b, second = new HashSet<int>());
                first.Add(b); second.Add(a);
            }
            if (neighbours.Count == 0) return 0;

            // 溶接した節点の代表位置
            var node = new Dictionary<int, Vector3>();
            var nodeHeight = new Dictionary<int, float>();
            for (int i = 0; i < positions.Length; i++)
            {
                if (!neighbours.ContainsKey(welded[i]) || node.ContainsKey(welded[i])) continue;
                node[welded[i]] = positions[i]; nodeHeight[welded[i]] = heights[i];
            }

            int seed = -1; float nearest = float.PositiveInfinity;
            foreach (var pair in node)
            {
                float distance = Vector3.Distance(pair.Value, upperWorld);
                if (distance >= nearest) continue;
                nearest = distance; seed = pair.Key;
            }
            if (seed < 0) return 0;
            if (nearest > snapDistance && Mathf.Abs(nodeHeight[seed] - upper) > snapDistance) return 0;

            var loop = new HashSet<int> { seed };
            var queue = new Queue<int>(); queue.Enqueue(seed);
            while (queue.Count > 0)
                foreach (int next in neighbours[queue.Dequeue()])
                    if (loop.Add(next)) queue.Enqueue(next);
            if (loop.Count < 8 || loop.Any(n => neighbours[n].Count != 2)) return 0;

            var sums = new float[result.SectorCount];
            var counts = new int[result.SectorCount];
            foreach (int n in loop)
            {
                int sector = result.Sector(result.Angle(node[n]));
                sums[sector] += nodeHeight[n]; counts[sector]++;
            }
            if (counts.All(c => c == 0)) return 0;
            var values = new float[result.SectorCount];
            for (int s = 0; s < result.SectorCount; s++) values[s] = counts[s] > 0 ? sums[s] / counts[s] : 0;
            Fill(values, counts.Select(c => c > 0).ToArray(), upper);
            // 縁が下の線より下がっていても、帯の下端が同じ形で下へ付いていくので構わない。
            // 読み取れない値だけを拒む（厚みが足りるかは Compute 側で見る）。
            if (values.Any(v => !NeckSnapshot.Finite(v))) return 0;
            result.HUpBySector = values;
            result.Snapped = true;
            return loop.Count;
        }

        // ── 表示用の輪 ────────────────────────────────────────────────

        private static void Rings(NeckBandResult result, Vector3[] positions, float[] heights)
        {
            var upperSum = new float[RingPoints]; var upperCount = new int[RingPoints];
            var lowerSum = new float[RingPoints]; var lowerCount = new int[RingPoints];
            var every = new List<float>();
            for (int i = 0; i < positions.Length; i++)
            {
                if (!result.InBand[i]) continue;
                every.Add(result.Radius(positions[i]));
                int bin = Mathf.Clamp(Mathf.FloorToInt(result.Theta[i] / (2 * Mathf.PI / RingPoints)), 0, RingPoints - 1);
                if (result.T[i] >= .75f) { upperSum[bin] += result.Radius(positions[i]); upperCount[bin]++; }
                if (result.T[i] <= .25f) { lowerSum[bin] += result.Radius(positions[i]); lowerCount[bin]++; }
            }
            float fallback = every.Count > 0 ? Median(every) : result.RadiusLimit;
            result.UpperRing = new Vector3[RingPoints];
            result.LowerRing = new Vector3[RingPoints];
            for (int i = 0; i < RingPoints; i++)
            {
                float angle = (i + .5f) * (2 * Mathf.PI / RingPoints);
                var radial = result.BasisX * Mathf.Cos(angle) + result.BasisZ * Mathf.Sin(angle);
                float up = upperCount[i] > 0 ? upperSum[i] / upperCount[i] : fallback;
                float down = lowerCount[i] > 0 ? lowerSum[i] / lowerCount[i] : fallback;
                result.UpperRing[i] = result.Origin + result.Axis * result.UpperAt(angle) + radial * up;
                result.LowerRing[i] = result.Origin + result.Axis * result.LowerAt(angle) + radial * down;
            }
        }

        // ── 道具 ──────────────────────────────────────────────────────

        private static string Describe(NeckBandResult result, int faces, int loopNodes, NeckBandSettings settings)
        {
            var text = new StringBuilder();
            text.Append(L.F("帯の面 {0} 枚／帯の頂点 {1} 個／上の線 {2:F1} mm／下の線 {3:F1} mm／厚み {4:F1} mm／半径上限 {5:F1} mm／区画 {6}",
                "Band faces {0}, band vertices {1}, upper line {2:F1} mm, lower line {3:F1} mm, thickness {4:F1} mm, radius limit {5:F1} mm, sectors {6}",
                faces, result.InBand.Count(v => v), result.HUp * 1000f, result.HLow * 1000f, result.Thickness * 1000f, result.RadiusLimit * 1000f, result.SectorCount));
            text.Append('\n');
            text.Append(result.FollowsMeshRows
                ? L.T("選んだ2本の線に沿って、首を一周する範囲を作りました。", "The region follows the two selected lines all the way around the neck.")
                : result.Snapped
                ? L.F("上端は首穴の縁へ吸着し、下端も同じ形で {2:F1} mm 下をなぞります（輪の頂点 {0} 個、区画ごとの高さの差 {1:F2} mm）", "Top snapped to the open edge and the bottom follows it {2:F1} mm below ({0} loop vertices, {1:F2} mm spread between sectors)", loopNodes, (result.HUpBySector.Max() - result.HUpBySector.Min()) * 1000f, result.Thickness * 1000f)
                : L.F("上端も下端も平面のまま（{0:F1} mm 以内に使える首穴の縁が見つからない、または吸着は切ってある）", "Top and bottom left as flat planes (no usable open edge within {0:F1} mm, or snapping is off)", settings.snapDistanceMm));
            if (result.Reason != null) { text.Append('\n'); text.Append(result.Reason); }
            return text.ToString();
        }

        // 面の向き。Vector3.normalized は長さ 1e-5 未満を「ゼロ」に丸めてしまうので使えない。
        // 首まわりの細かい三角形（たとえば高さ 1.5 mm × 幅 6.5 mm）は外積の長さが約 1e-5 になり、
        // そのまま .normalized に渡すと向きが消えて、その面が隣どうしのつながりから外れる。
        // つぶれた三角形だけをゼロにしたいので、辺の長さに対する相対的な細さで判定する。
        internal static Vector3 FaceNormal(Vector3 a, Vector3 b, Vector3 c)
        {
            var first = b - a; var second = c - a;
            var cross = Vector3.Cross(first, second);
            float length = cross.magnitude, scale = first.magnitude * second.magnitude;
            if (!(length > 0) || !(scale > 0) || length < scale * 1e-6f) return Vector3.zero;
            return cross / length;
        }

        private static long Edge(int a, int b) => ((long)Math.Min(a, b) << 32) | (uint)Math.Max(a, b);

        private static float Median(List<float> values)
        {
            if (values.Count == 0) return 0;
            var sorted = values.ToArray(); Array.Sort(sorted);
            return sorted.Length % 2 == 1 ? sorted[sorted.Length / 2] : (sorted[sorted.Length / 2 - 1] + sorted[sorted.Length / 2]) * .5f;
        }

        // 位置が 1e-5 m 以内の頂点を同じ節点にまとめる（NeckDetection の溶接と同じ規則）。
        internal static int[] Weld(Vector3[] positions)
        {
            var map = new int[positions.Length];
            var cells = new Dictionary<Vector3Int, List<int>>();
            var representatives = new List<int>();
            for (int i = 0; i < positions.Length; i++)
            {
                var point = positions[i];
                var cell = new Vector3Int(Mathf.FloorToInt(point.x / WeldDistance), Mathf.FloorToInt(point.y / WeldDistance), Mathf.FloorToInt(point.z / WeldDistance));
                int found = -1;
                for (int x = -1; x <= 1 && found < 0; x++) for (int y = -1; y <= 1 && found < 0; y++) for (int z = -1; z <= 1 && found < 0; z++)
                    if (cells.TryGetValue(cell + new Vector3Int(x, y, z), out var bucket))
                        foreach (int r in bucket) if ((positions[representatives[r]] - point).sqrMagnitude <= WeldDistance * WeldDistance) { found = r; break; }
                if (found < 0)
                {
                    found = representatives.Count; representatives.Add(i);
                    if (!cells.TryGetValue(cell, out var bucket)) cells[cell] = bucket = new List<int>();
                    bucket.Add(found);
                }
                map[i] = found;
            }
            return map;
        }

        /// <summary>空いている区画を、円周方向に両隣から埋める。</summary>
        internal static void Fill(float[] values, bool[] has, float fallback)
        {
            int n = values.Length;
            if (n == 0) return;
            if (!has.Any(v => v)) { for (int i = 0; i < n; i++) values[i] = fallback; return; }
            var filled = (float[])values.Clone();
            for (int i = 0; i < n; i++)
            {
                if (has[i]) continue;
                int forward = 0; while (forward < n && !has[(i + forward) % n]) forward++;
                int backward = 0; while (backward < n && !has[((i - backward) % n + n) % n]) backward++;
                float a = values[((i - backward) % n + n) % n], b = values[(i + forward) % n];
                filled[i] = Mathf.Lerp(a, b, backward / (float)(backward + forward));
            }
            Array.Copy(filled, values, n);
        }

        /// <summary>区画の中心どうしを円周方向に線形補間して、その角度での値を返す。</summary>
        internal static float Circular(float[] values, float angle, float fallback)
        {
            if (values == null || values.Length == 0) return fallback;
            int n = values.Length;
            float step = 2 * Mathf.PI / n;
            float position = angle / step - .5f;
            int first = Mathf.FloorToInt(position);
            float blend = position - first;
            return Mathf.Lerp(values[((first % n) + n) % n], values[(((first + 1) % n) + n) % n], blend);
        }

        /// <summary>区画の中心どうしを円周方向に線形補間する（倍率用）。</summary>
        internal static Vector3 Circular(Vector3[] values, float angle, Vector3 fallback)
        {
            if (values == null || values.Length == 0) return fallback;
            int n = values.Length;
            float step = 2 * Mathf.PI / n;
            float position = angle / step - .5f;
            int first = Mathf.FloorToInt(position);
            float blend = position - first;
            return Vector3.Lerp(values[((first % n) + n) % n], values[(((first + 1) % n) + n) % n], blend);
        }
    }
}
