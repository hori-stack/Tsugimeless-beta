using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    // Product entry points repeat the check at execution time. Internal algorithms remain
    // independently testable with authored fixtures; they are not license or UI entry points.
    internal static class NeckLicensedActions
    {
        internal static NeckBakeResult Bake(Material body, NeckSnapshot snapshot, NeckBandResult band, NeckReferenceResult reference)
        {
            if (!TsugimelessLicense.Require(out var reason)) return new NeckBakeResult { Reason = reason, Summary = reason };
            return NeckBake.Bake(body, snapshot, band, reference, true);
        }
        internal static NeckApplyResult Apply(GameObject root, Renderer renderer, int slot, Material baseline, NeckBakeResult bake,
            Material face, string shapeStamp, Vector3[] upper, Vector3[] lower)
        {
            if (!TsugimelessLicense.Require(out var reason)) return new NeckApplyResult { Reason = reason };
            return NeckHistoryStore.Apply(root, renderer, slot, baseline, bake, face, shapeStamp, upper, lower);
        }
    }
}
