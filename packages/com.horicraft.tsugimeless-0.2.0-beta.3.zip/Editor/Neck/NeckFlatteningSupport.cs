using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    // N03A is deliberately narrower than color evaluation. No caller in the normal UI yet.
    internal static class NeckFlatteningSupport
    {
        internal static string Refuse(string detail) => L.F("この設定はまだ1枚にまとめられません（{0}）。", "This setup cannot be flattened yet ({0}).", detail);

        internal static string MaterialReason(Material material)
        {
            string reason = SeamColorEvaluator.Validate(material);
            if (reason != null) return reason;
            // Only the installed standard opaque shader, not a shader merely named like lilToon.
            string path = AssetDatabase.GetAssetPath(material.shader).Replace('\\', '/');
            bool knownShader = (material.shader.name == "lilToon" && path.EndsWith("/lts.shader", StringComparison.OrdinalIgnoreCase))
                || (material.shader.name == "Hidden/lilToonOutline" && path.EndsWith("/lts_o.shader", StringComparison.OrdinalIgnoreCase));
            if (!knownShader
                || material.GetTag("RenderType", false) != "Opaque" || material.renderQueue > 2500)
                return Refuse("standard opaque lilToon");
            var main = material.GetTexture("_MainTex") as Texture2D;
            if (!main || main.width > UvMaskRasterizer.MaxSize || main.height > UvMaskRasterizer.MaxSize)
                return Refuse("MainTex / size");
            if (!SeamColorEvaluator.IdentityUv(material, "_MainTex")) return Refuse("_MainTex_ST");
            var textures = new List<string> { "_MainTex", "_MainColorAdjustMask" };
            foreach (string layer in new[] { "2nd", "3rd" })
            {
                if (material.GetFloat("_UseMain" + layer + "Tex") == 0) continue;
                string p = "_Main" + layer;
                if (material.GetFloat(p + "TexBlendMode") != 0 || material.GetFloat(p + "EnableLighting") != 1)
                    return Refuse(p + ": normal blend / lighting=1 required");
                if (!material.GetTexture(p + "Tex")) return Refuse(p + "Tex: missing");
                textures.Add(p + "Tex"); textures.Add(p + "BlendMask");
            }
            foreach (string name in textures)
            {
                if (!SeamColorEvaluator.IdentityUv(material, name)) return Refuse(name + "_ST");
                var texture = material.GetTexture(name) as Texture2D;
                if (!texture) continue; // A missing mask is the shader's white mask.
                if (texture.width != main.width || texture.height != main.height) return Refuse(name + ": size differs");
                if (texture.filterMode != main.filterMode || texture.wrapModeU != main.wrapModeU || texture.wrapModeV != main.wrapModeV
                    || texture.anisoLevel != main.anisoLevel || texture.mipmapCount != main.mipmapCount)
                    return Refuse(name + ": sampler differs");
            }
            return null;
        }

        internal static string ClipReason(AnimationClip clip, string targetPath)
        {
            if (!clip) return Refuse("animation clip missing");
            foreach (var binding in AnimationUtility.GetCurveBindings(clip).Concat(AnimationUtility.GetObjectReferenceCurveBindings(clip)))
            {
                if (binding.path != targetPath || binding.type == null || !typeof(Renderer).IsAssignableFrom(binding.type)) continue;
                string property = binding.propertyName;
                if (property.StartsWith("m_Materials", StringComparison.Ordinal)
                    || property.StartsWith("material._Main", StringComparison.Ordinal)
                    || property.StartsWith("material._Color", StringComparison.Ordinal)
                    || property.StartsWith("material._UseMain", StringComparison.Ordinal))
                    return Refuse("animation: " + clip.name + " / " + property);
            }
            return null;
        }

        // A material-only experiment is not evidence that a whole avatar is static.
        internal static string SceneReason(GameObject root, Renderer renderer, out int inspectedClips)
        {
            inspectedClips = 0;
            if (!root || !renderer || !(renderer.transform == root.transform || renderer.transform.IsChildOf(root.transform)))
                return Refuse("avatar / renderer");
            if (EditorApplication.isPlayingOrWillChangePlaymode || AnimationMode.InAnimationMode()) return Refuse("Play / Animation preview");
            if (renderer.HasPropertyBlock()) return Refuse("existing renderer overrides not assessed");
            var clips = new List<KeyValuePair<AnimationClip, Transform>>();
            foreach (var animator in root.GetComponentsInChildren<Animator>(true))
                Add(animator.runtimeAnimatorController, animator.transform, clips);
            foreach (var legacy in root.GetComponentsInChildren<Animation>(true))
                foreach (AnimationState state in legacy) clips.Add(new KeyValuePair<AnimationClip, Transform>(state.clip, legacy.transform));
#if TSUGIMELESS_HAS_VRCSDK
            foreach (var descriptor in root.GetComponentsInChildren<VRC.SDKBase.VRC_AvatarDescriptor>(true))
            {
                var serialized = new SerializedObject(descriptor);
                foreach (string field in new[] { "baseAnimationLayers", "specialAnimationLayers" })
                {
                    var layers = serialized.FindProperty(field);
                    if (layers == null || !layers.isArray) return Refuse("VRC animation layers not assessed");
                    for (int i = 0; i < layers.arraySize; i++)
                    {
                        var layer = layers.GetArrayElementAtIndex(i);
                        var useDefault = layer.FindPropertyRelative("isDefault");
                        var controller = layer.FindPropertyRelative("animatorController");
                        if (useDefault == null || controller == null) return Refuse("VRC animation layer schema");
                        if (!useDefault.boolValue) Add(controller.objectReferenceValue as RuntimeAnimatorController, descriptor.transform, clips);
                    }
                }
            }
#endif
            foreach (var item in clips)
            {
                if (!(renderer.transform == item.Value || renderer.transform.IsChildOf(item.Value))) continue;
                inspectedClips++;
                string reason = ClipReason(item.Key, AnimationUtility.CalculateTransformPath(renderer.transform, item.Value));
                if (reason != null) return reason;
            }
            foreach (var script in root.GetComponentsInChildren<MonoBehaviour>(true))
            {
                if (!script) return Refuse("missing script: dynamic setup not assessed");
                var type = script.GetType(); string ns = type.Namespace ?? "";
                // Generators can add clips after this audit. Do not infer safety from a stopped Animator.
                if (ns.StartsWith("nadena.dev.modular_avatar", StringComparison.Ordinal)
                    || ns.StartsWith("lilToon.lilycalInventory", StringComparison.Ordinal)
                    || type.Name.IndexOf("MergeAnimator", StringComparison.OrdinalIgnoreCase) >= 0)
                    return Refuse("generated animation not assessed: " + type.Name);
            }
            return null;
        }

        private static void Add(RuntimeAnimatorController controller, Transform root, List<KeyValuePair<AnimationClip, Transform>> clips)
        {
            if (!controller) return;
            foreach (var clip in controller.animationClips) clips.Add(new KeyValuePair<AnimationClip, Transform>(clip, root));
        }
    }
}
