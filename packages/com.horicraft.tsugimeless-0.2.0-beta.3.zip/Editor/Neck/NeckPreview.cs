using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace HoriCraft.Tsugimeless.Editor
{
    // Temporary _MainTex override through MaterialPropertyBlock (evaluation decision 5).
    // Never assigns sharedMaterials, never writes a material asset, never records Undo.
    // The block that the slot already carried is kept during the preview and put back on Hide.
    internal static class NeckPreview
    {
        private const double Interval = .5;
        private static MaterialPropertyBlock restore;   // the block the slot had before Show; null when it had none
        private static Texture source;
        private static Material slotMaterial;
        private static int slotCount;
        private static double due;
        private static bool hooked;
        private static NeckNdmfPreviewPause ndmfPause;

        internal static bool Active { get; private set; }
        internal static Renderer Target { get; private set; }
        internal static int Slot { get; private set; }
        internal static string Notice { get; private set; }
        internal static bool PausesOtherPreviews => Active && ndmfPause != null;

        // Recalculation starts from the saved baseline. Restore every baseline texture in
        // the temporary block, so a previous result in a different layer cannot stack with it.
        // Non-texture settings must still agree: a property block cannot restore render state.
        internal static bool ShowBaseline(Renderer renderer, int slot, Material baseline, Texture texture, out string reason, string property)
        {
            reason = Refusal(renderer, slot, texture);
            if (reason != null) return false;
            Hide();
            var current = renderer.sharedMaterials[slot];
            var slotBlock = new MaterialPropertyBlock(); renderer.GetPropertyBlock(slotBlock, slot);
            var globalBlock = new MaterialPropertyBlock(); renderer.GetPropertyBlock(globalBlock);
            if (!slotBlock.isEmpty || !globalBlock.isEmpty)
            {
                reason = L.T("別の一時表示があるため、見た目を正しく比べられません。他のツールのプレビューを解除してください。", "Another temporary override prevents an accurate comparison. Turn off the other tool's preview first."); return false;
            }
            if (!SameNonTextureSettings(current, baseline))
            {
                reason = L.T("今の材質設定が、計算元と違います。履歴から元の状態へ戻すか、顔・体の指定を確認してください。", "The current material settings differ from the calculation baseline. Restore the initial state from history or check the face and body selection."); return false;
            }
            foreach (string name in baseline.GetTexturePropertyNames())
                if (!baseline.GetTexture(name) && current.GetTexture(name))
                { reason = L.T("今の材質設定が、計算元と違います。履歴から元の状態へ戻すか、顔・体の指定を確認してください。", "The current material settings differ from the calculation baseline. Restore the initial state from history or check the face and body selection."); return false; }
            if (!Show(renderer, slot, texture, out reason, property)) return false;
            try
            {
                var block = new MaterialPropertyBlock(); renderer.GetPropertyBlock(block, slot);
                foreach (string name in baseline.GetTexturePropertyNames())
                {
                    var original = baseline.GetTexture(name); if (original) block.SetTexture(name, original);
                    var scale = baseline.GetTextureScale(name); var offset = baseline.GetTextureOffset(name);
                    block.SetVector(name + "_ST", new Vector4(scale.x, scale.y, offset.x, offset.y));
                }
                block.SetTexture(property, texture); renderer.SetPropertyBlock(block, slot); return true;
            }
            catch { Hide(); throw; }
        }
        private static bool SameNonTextureSettings(Material current, Material baseline)
        {
            if (!current || !baseline || current.shader != baseline.shader || current.renderQueue != baseline.renderQueue
                || current.doubleSidedGI != baseline.doubleSidedGI || current.globalIlluminationFlags != baseline.globalIlluminationFlags
                || current.GetTag("RenderType", false) != baseline.GetTag("RenderType", false)
                || !current.shaderKeywords.OrderBy(k => k).SequenceEqual(baseline.shaderKeywords.OrderBy(k => k))) return false;
            for (int pass = 0; pass < baseline.passCount; pass++)
                if (current.GetShaderPassEnabled(baseline.GetPassName(pass)) != baseline.GetShaderPassEnabled(baseline.GetPassName(pass))) return false;
            var shader = baseline.shader;
            for (int i = 0; i < shader.GetPropertyCount(); i++)
            {
                string name = shader.GetPropertyName(i); if (shader.FindPropertyIndex(name) != i) continue;
                switch (shader.GetPropertyType(i))
                {
                    case ShaderPropertyType.Color: if (current.GetColor(name) != baseline.GetColor(name)) return false; break;
                    case ShaderPropertyType.Vector: if (current.GetVector(name) != baseline.GetVector(name)) return false; break;
                    case ShaderPropertyType.Float: case ShaderPropertyType.Range: if (current.GetFloat(name) != baseline.GetFloat(name)) return false; break;
                    case ShaderPropertyType.Int: if (current.GetInteger(name) != baseline.GetInteger(name)) return false; break;
                }
            }
            return true;
        }

        internal static bool Show(Renderer renderer, int slot, Texture texture, out string reason, string textureProperty = SeamColorEvaluator.MainTexture)
        {
            reason = Refusal(renderer, slot, texture);
            if (reason == null && (!SeamColorEvaluator.KnownTexture(textureProperty) || !renderer.sharedMaterials[slot]
                || !renderer.sharedMaterials[slot].HasProperty(textureProperty)))
                reason = L.T("補正する画像の欄が見つかりません。もう一度、色を計算してください。", "The image slot to correct was not found. Compute the colors again.");
            if (reason != null) { Notice = reason; return false; }
            Hide();
            Hook();
            if (!NeckNdmfPreviewPause.TryAcquire(out ndmfPause, out reason)) { Notice = reason; return false; }
            try
            {
                var materials = renderer.sharedMaterials;
                var previous = new MaterialPropertyBlock();
                renderer.GetPropertyBlock(previous, slot);
                restore = previous.isEmpty ? null : previous;
                Target = renderer; Slot = slot; source = texture;
                slotMaterial = materials[slot]; slotCount = materials.Length;
                Active = true;
                var block = new MaterialPropertyBlock();
                renderer.GetPropertyBlock(block, slot);     // keep every other override this slot already had
                block.SetTexture(textureProperty, texture);
                renderer.SetPropertyBlock(block, slot);
                Notice = null; due = EditorApplication.timeSinceStartup + Interval;
                SceneView.RepaintAll();
                return true;
            }
            catch { Hide(); throw; }
        }

        internal static void Hide()
        {
            bool repaint = Active;
            try
            {
                if (Active && Target)
                {
                    var materials = Target.sharedMaterials;
                    if (Slot >= 0 && Slot < materials.Length) Target.SetPropertyBlock(restore, Slot);
                }
            }
            finally
            {
                Active = false; Target = null; Slot = 0; source = null; slotMaterial = null; slotCount = 0; restore = null; Notice = null;
                var pause = ndmfPause; ndmfPause = null; pause?.Dispose();
                if (repaint) SceneView.RepaintAll();
            }
        }

        // Cheap staleness guard; the window does not have to poll. Exposed so tests can drive it without waiting.
        internal static void Tick(double now)
        {
            if (!Active || now < due) return;
            due = now + Interval;
            var materials = Target ? Target.sharedMaterials : null;
            bool lost = materials == null || materials.Length != slotCount || Slot < 0 || Slot >= materials.Length
                        || materials[Slot] != slotMaterial || !source;
            if (!lost) return;
            Hide();
            Notice = L.T("対象が変わったため、プレビューを解除しました。", "The target changed, so the preview was turned off.");
        }

        private static string Refusal(Renderer renderer, int slot, Texture texture)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                return L.T("Play中はプレビューできません。停止してからやり直してください。", "Preview is not available during Play. Stop Play and try again.");
            if (!renderer) return L.T("プレビューする描画部品が見つかりません。", "The renderer to preview was not found.");
            if (slot < 0 || slot >= renderer.sharedMaterials.Length) return L.T("指定した材質欄がありません。", "The specified material slot does not exist.");
            if (!texture) return L.T("プレビューに使う画像がありません。", "There is no image to use for the preview.");
            return null;
        }

        private static void Hook()
        {
            if (hooked) return;
            hooked = true;
            AssemblyReloadEvents.beforeAssemblyReload += Hide;
            EditorApplication.playModeStateChanged += OnPlayModeChanged;
            EditorApplication.update += OnUpdate;
        }

        private static void OnPlayModeChanged(PlayModeStateChange change)
        {
            if (change == PlayModeStateChange.ExitingEditMode) Hide();
        }

        private static void OnUpdate() => Tick(EditorApplication.timeSinceStartup);
    }
}
