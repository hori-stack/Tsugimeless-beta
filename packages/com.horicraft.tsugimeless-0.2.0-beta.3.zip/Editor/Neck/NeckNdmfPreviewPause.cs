using System;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    // Optional connection to NDMF's public, transient counter. Never changes Enable Previews.
    // Keep reflection here so NDMF is not a required assembly/package dependency.
    internal sealed class NeckNdmfPreviewPause : IDisposable
    {
        private PropertyInfo counter;

        private NeckNdmfPreviewPause(PropertyInfo counter) { this.counter = counter; }

        internal static bool TryAcquire(out NeckNdmfPreviewPause pause, out string reason)
        {
            pause = null; reason = null;
            var type = AppDomain.CurrentDomain.GetAssemblies()
                .Select(a => a.GetType("nadena.dev.ndmf.preview.NDMFPreview", false)).FirstOrDefault(t => t != null);
            if (type == null) return true;
            var property = type.GetProperty("DisablePreviewDepth", BindingFlags.Public | BindingFlags.Static);
            if (property == null || property.PropertyType != typeof(int)
                || property.GetGetMethod() == null || property.GetSetMethod() == null)
            { reason = Unavailable(); return false; }
            try
            {
                int before = (int)property.GetValue(null);
                if (before < 0 || before == int.MaxValue) { reason = Unavailable(); return false; }
                // Keep the lease before setting: even a setter failure must release our increment.
                var acquired = new NeckNdmfPreviewPause(property);
                try { property.SetValue(null, before + 1); }
                catch
                {
                    if ((int)property.GetValue(null) == before + 1) acquired.Dispose();
                    throw;
                }
                pause = acquired; return true;
            }
            catch (Exception) { reason = Unavailable(); return false; }
        }

        public void Dispose()
        {
            var property = counter; counter = null;
            if (property == null) return;
            try
            {
                int current = (int)property.GetValue(null);
                // Other tools may also hold a pause. Release only ours, never restore a stale count.
                // NDMF can reset the count on Play; do not make it negative in that case.
                if (current > 0) property.SetValue(null, current - 1);
            }
            catch (Exception)
            {
                Debug.LogWarning(L.T("他のプレビューの再開を確認できませんでした。Unityのスクリプト再読み込み後に表示を確認してください。", "Could not confirm resuming other previews. Check the display after Unity reloads scripts."));
            }
        }

        private static string Unavailable() => L.T("他のプレビューを一時停止できないため、補正を仮表示できません。NDMFのバージョンを確認してください。", "Cannot show the correction because other previews could not be paused. Check the NDMF version.");
    }
}
