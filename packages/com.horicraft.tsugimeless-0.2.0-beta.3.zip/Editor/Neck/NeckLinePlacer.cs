using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace HoriCraft.Tsugimeless.Editor
{
    /// <summary>どの段階まで線を置いたか。D-N1 の「上の線 → 下の線 → 確認」の順を保持する。</summary>
    internal enum NeckLineStage { Idle, PlacingUpper, PlacingLower, Adjust }

    /// <summary>
    /// SceneView で首の 2 本の線を置く（設計 §2 項目4・§4・D-N1）。
    ///
    /// 置く順は本人指定で固定。①顔側の上の線（グラデーションの 100% 側）→
    /// ②体側の下の線（0% 側）→ ③丸をドラッグして微調整。全自動にせず、
    /// 1 つずつ押して進める体験にするための部品なので、ここでは
    /// <b>線の位置を決めて知らせるだけ</b>で、帯の計算も材質の変更も行わない。
    ///
    /// 守っていること:
    ///  - Alt を押している間は何もしない（Unity 標準のカメラ操作が最優先）
    ///  - 置く段階の間だけ左クリックを受け取る。Idle では購読ごと外す
    ///  - 右クリックのドラッグ（カメラの見回し）は奪わない。やめるのは Esc と
    ///    ドラッグを伴わない右クリック（ContextClick）だけ
    ///  - シーンの物を一切変更しない。Undo も使わない
    ///  - 点は<b>アバタールートのローカル</b>で持つ。ワールドで持つと
    ///    アバターを動かした瞬間に線だけ置き去りになる
    /// </summary>
    internal sealed class NeckLinePlacer : IDisposable
    {
        /// <summary>三角形が平行・裏返りと判定される閾値。距離ゼロの自己ヒットも弾く。</summary>
        private const float Epsilon = 1e-7f;
        /// <summary>顔側＝水色、体側＝黄色。NeckOverlay の診断表示と同じ配色。</summary>
        private static readonly Color UpperColor = new Color(0, 1, 1, 1);
        private static readonly Color LowerColor = new Color(1, .92f, .05f, 1);
        private const float DotSize = .035f;
        private const float HandleSize = .06f;

        private readonly Vector3[] segment = new Vector3[2];
        private IReadOnlyList<Renderer> targets;
        private Vector3[] upperRing, lowerRing;
        private Vector3 upperLocal, lowerLocal;
        private bool hooked, consumedDown;

        internal NeckLineStage Stage { get; private set; } = NeckLineStage.Idle;
        internal bool HasUpper { get; private set; }
        internal bool HasLower { get; private set; }
        internal GameObject Root { get; private set; }
        internal bool AllowFreeAdjust { get; private set; } = true;
        /// <summary>アバタールートのローカル座標。Root が無ければワールドと同じ。</summary>
        internal Vector3 UpperLocal => upperLocal;
        internal Vector3 LowerLocal => lowerLocal;
        internal Vector3 UpperWorld => ToWorld(upperLocal);
        internal Vector3 LowerWorld => ToWorld(lowerLocal);

        /// <summary>点を置いた・動かした・やめた・段階が変わったときに通知する。</summary>
        internal event Action Changed;

        /// <summary>当たり判定の差し替え口（テスト用）。null を返したら「当たらなかった」。</summary>
        internal Func<Ray, Vector3?> PickOverride;

        /// <summary>いま何をすればよいかの 1 行。ウィンドウの説明欄がそのまま出す。</summary>
        internal string Hint
        {
            get
            {
                switch (Stage)
                {
                    case NeckLineStage.PlacingUpper:
                        return L.T("シーンで、顔側の上の線を置く場所をクリックしてください。やめるときはEscキーを押します。", "Click in the Scene view where the upper line (face side) belongs. Press Escape to stop.");
                    case NeckLineStage.PlacingLower:
                        return L.T("シーンで、体側の下の線を置く場所をクリックしてください。やめるときはEscキーを押します。", "Click in the Scene view where the lower line (body side) belongs. Press Escape to stop.");
                    case NeckLineStage.Adjust:
                        return !AllowFreeAdjust ? L.T("ウィンドウの矢印で線の位置を調整できます。", "Use the arrows in the window to adjust the lines.")
                            : L.T("丸をドラッグすると線の位置を調整できます。置き直すときはボタンを押してください。", "Drag a sphere to adjust a line. Use the buttons to place one again.");
                    default:
                        return string.Empty;
                }
            }
        }

        // ── 出入り口 ──────────────────────────────────────────────────

        /// <summary>上の線から置き始める。置いてあった点は捨てる。</summary>
        internal void Begin(GameObject root, IReadOnlyList<Renderer> pickTargets)
        {
            if (root == null) { Clear(); return; }
            Root = root; targets = pickTargets; AllowFreeAdjust = true;
            HasUpper = HasLower = false; upperLocal = lowerLocal = Vector3.zero;
            upperRing = lowerRing = null; consumedDown = false;
            Stage = NeckLineStage.PlacingUpper;
            Hook(); SceneView.RepaintAll(); Raise();
        }

        /// <summary>上の線だけ置き直す（「上の線を置き直す」ボタン）。</summary>
        internal void BeginUpper() => Resume(NeckLineStage.PlacingUpper);

        /// <summary>下の線だけ置き直す（「下の線を置き直す」ボタン）。</summary>
        internal void BeginLower() => Resume(NeckLineStage.PlacingLower);

        private void Resume(NeckLineStage stage)
        {
            if (Root == null) { Clear(); return; }
            consumedDown = false; Stage = stage; AllowFreeAdjust = true;
            Hook(); SceneView.RepaintAll(); Raise();
        }

        /// <summary>
        /// 首の輪を重ねて描く（帯の計算側から渡す）。null で消える。
        /// これは表示だけの差し替えなので <see cref="Changed"/> は出さない
        /// （受け手が Changed の中で輪を作ると、際限なく呼び合うことになる）。
        /// </summary>
        internal void SetRings(Vector3[] upperWorld, Vector3[] lowerWorld)
        {
            upperRing = upperWorld != null && upperWorld.Length >= 2 ? upperWorld : null;
            lowerRing = lowerWorld != null && lowerWorld.Length >= 2 ? lowerWorld : null;
            SceneView.RepaintAll();
        }

        internal void SetLines(GameObject root, IReadOnlyList<Renderer> pickTargets, Vector3 upper, Vector3 lower, bool freeAdjust)
        {
            if (!root || !NeckSnapshot.Finite(upper) || !NeckSnapshot.Finite(lower)) return;
            Root = root; targets = pickTargets;
            upperLocal = ToLocal(upper); lowerLocal = ToLocal(lower);
            HasUpper = HasLower = true; AllowFreeAdjust = freeAdjust;
            consumedDown = false; Stage = NeckLineStage.Adjust;
            Hook(); SceneView.RepaintAll(); Raise();
        }

        /// <summary>置くのをやめる。2 本そろっていれば微調整へ、そうでなければ何もしない状態へ戻る。置いた点は残す。</summary>
        internal void Cancel()
        {
            consumedDown = false;
            Stage = HasUpper && HasLower ? NeckLineStage.Adjust : NeckLineStage.Idle;
            if (Stage == NeckLineStage.Idle) Unhook();
            SceneView.RepaintAll(); Raise();
        }

        /// <summary>線を全部捨てて最初の状態へ戻す。</summary>
        internal void Clear()
        {
            Stage = NeckLineStage.Idle; HasUpper = HasLower = false;
            upperLocal = lowerLocal = Vector3.zero; upperRing = lowerRing = null;
            targets = null; Root = null; consumedDown = false;
            Unhook(); SceneView.RepaintAll(); Raise();
        }

        /// <summary>購読を外す。何度呼んでも安全。</summary>
        public void Dispose()
        {
            Unhook(); Stage = NeckLineStage.Idle; targets = null; PickOverride = null;
        }

        private void Hook()
        {
            if (hooked) return;
            hooked = true; SceneView.duringSceneGui += OnSceneGui;
        }

        private void Unhook()
        {
            if (!hooked) return;
            hooked = false; SceneView.duringSceneGui -= OnSceneGui;
        }

        private void Raise() => Changed?.Invoke();

        private Vector3 ToWorld(Vector3 local) => Root != null ? Root.transform.TransformPoint(local) : local;
        private Vector3 ToLocal(Vector3 world) => Root != null ? Root.transform.InverseTransformPoint(world) : world;

        // ── クリックの受け取り ────────────────────────────────────────

        /// <summary>左クリック 1 回ぶんの状態変化。テストはここを直接叩く。</summary>
        internal void SimulateClick(Ray ray)
        {
            if (Stage != NeckLineStage.PlacingUpper && Stage != NeckLineStage.PlacingLower) return;
            if (!Pick(ray, out var world)) return;
            SetPoint(world);
        }

        private bool Pick(Ray ray, out Vector3 world)
        {
            if (PickOverride != null)
            {
                var result = PickOverride(ray);
                world = result ?? Vector3.zero;
                return result.HasValue && NeckSnapshot.Finite(world);
            }
            return TryPick(ray, out world);
        }

        private void SetPoint(Vector3 world)
        {
            if (!NeckSnapshot.Finite(world)) return;
            if (Stage == NeckLineStage.PlacingUpper) { upperLocal = ToLocal(world); HasUpper = true; }
            else { lowerLocal = ToLocal(world); HasLower = true; }
            // 2 本そろったら微調整へ。片方だけなら残っている方を続けて置く
            Stage = HasUpper && HasLower ? NeckLineStage.Adjust
                : HasUpper ? NeckLineStage.PlacingLower : NeckLineStage.PlacingUpper;
            SceneView.RepaintAll(); Raise();
        }

        // ── SceneView ─────────────────────────────────────────────────

        private void OnSceneGui(SceneView view)
        {
            if (Stage == NeckLineStage.Idle) return;
            // アバターごと消えたら線の意味が無くなる。掴んだままにしない
            if (Root == null) { Clear(); return; }
            var e = Event.current;
            if (e == null) return;

            // 番号の取得はイベントの種類で分岐させない。Layout と Repaint で
            // 取る数が変わると、SceneView 上の他の操作の番号までずれる
            int id = GUIUtility.GetControlID(FocusType.Passive);
            bool placing = Stage == NeckLineStage.PlacingUpper || Stage == NeckLineStage.PlacingLower;

            // Alt 併用は Unity 標準のカメラ操作。線は描いたままにして、掴めなくするだけにする
            if (!e.alt)
            {
                if (placing) { HandleUtility.AddDefaultControl(id); HandlePlacing(e); }
                else if (Stage == NeckLineStage.Adjust && AllowFreeAdjust) HandleAdjust(view, e);
            }
            if (Event.current.type == EventType.Repaint) Draw(view);
        }

        private void HandlePlacing(Event e)
        {
            switch (e.type)
            {
                case EventType.MouseDown when e.button == 0:
                    consumedDown = true; e.Use();
                    if (Pick(HandleUtility.GUIPointToWorldRay(e.mousePosition), out var world)) SetPoint(world);
                    break;
                case EventType.MouseUp when e.button == 0:
                    // MouseDown を消費した後の標準選択（MouseUp 側）も抑止する
                    if (consumedDown) { consumedDown = false; e.Use(); }
                    break;
                case EventType.ContextClick:
                    // ドラッグを伴わない右クリックでやめる。右ドラッグ（見回し）は奪わない
                    e.Use(); Cancel();
                    break;
                case EventType.KeyDown when e.keyCode == KeyCode.Escape:
                    e.Use(); Cancel();
                    break;
            }
        }

        private void HandleAdjust(SceneView view, Event e)
        {
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape) return;   // 微調整中の Esc は何もしない
            if (HasUpper)
            {
                var world = UpperWorld; var moved = MoveDot(world, UpperColor);
                if (moved != world) { upperLocal = ToLocal(Project(view, moved)); SceneView.RepaintAll(); Raise(); }
            }
            if (HasLower)
            {
                var world = LowerWorld; var moved = MoveDot(world, LowerColor);
                if (moved != world) { lowerLocal = ToLocal(Project(view, moved)); SceneView.RepaintAll(); Raise(); }
            }
        }

        /// <summary>動かせる丸 1 つ。動かなければ渡した場所がそのまま返る。</summary>
        private Vector3 MoveDot(Vector3 world, Color color)
        {
            float size = HandleUtility.GetHandleSize(world) * HandleSize;
            var previous = Handles.color;
            Handles.color = color;
            EditorGUI.BeginChangeCheck();
            var moved = Handles.FreeMoveHandle(world, size, Vector3.zero, Handles.SphereHandleCap);
            bool changed = EditorGUI.EndChangeCheck();
            Handles.color = previous;
            return changed ? moved : world;
        }

        /// <summary>
        /// 動かした先を面へ落とし直す。丸は空中も動くので、そのまま使うと
        /// 線が肌から浮く。カメラから動かした先へ向けたレイで当て直し、
        /// 当たらなければ動かした場所をそのまま使う（手応えを切らさない）。
        /// </summary>
        private Vector3 Project(SceneView view, Vector3 moved)
        {
            var camera = view != null ? view.camera : null;
            if (camera == null || !NeckSnapshot.Finite(moved)) return moved;
            Ray ray;
            if (camera.orthographic)
            {
                var forward = camera.transform.forward;
                ray = new Ray(moved - forward * Mathf.Max(1, camera.farClipPlane), forward);
            }
            else
            {
                var direction = moved - camera.transform.position;
                if (direction.sqrMagnitude <= Epsilon) return moved;
                ray = new Ray(camera.transform.position, direction.normalized);
            }
            return Pick(ray, out var world) ? world : moved;
        }

        // ── 当たり判定 ────────────────────────────────────────────────

        /// <summary>
        /// いま見えている形へレイを飛ばして、当たった場所を返す。
        /// SkinnedMeshRenderer は現在ポーズをベイクした形に当てる（NeckSnapshot.Capture と同じ行列）。
        /// 首の形は 3 万三角形ほどなので、毎回ベイクし直しても間に合う。
        /// </summary>
        internal bool TryPick(Ray ray, out Vector3 world)
        {
            world = Vector3.zero;
            if (targets == null || targets.Count == 0) return false;

            float nearest = float.PositiveInfinity;
            Mesh baked = null;
            try
            {
                for (int i = 0; i < targets.Count; i++)
                {
                    var renderer = targets[i];
                    if (renderer == null || !renderer.enabled || !renderer.gameObject.activeInHierarchy) continue;
                    Mesh mesh; Matrix4x4 matrix;
                    if (renderer is SkinnedMeshRenderer skin)
                    {
                        if (skin.sharedMesh == null) continue;
                        if (baked == null) baked = new Mesh { hideFlags = HideFlags.HideAndDontSave };
                        skin.BakeMesh(baked, false);
                        mesh = baked;
                        // BakeMesh(false) は位置・回転だけを外に出した形を返す。
                        // ここで拡大率まで掛けると二重になる（NeckSnapshot.Capture と同じ）
                        matrix = Matrix4x4.TRS(skin.transform.position, skin.transform.rotation, Vector3.one);
                    }
                    else
                    {
                        var filter = renderer.GetComponent<MeshFilter>();
                        mesh = filter != null ? filter.sharedMesh : null;
                        if (mesh == null) continue;
                        matrix = renderer.localToWorldMatrix;
                    }
                    if (!TryPickInMesh(ray, mesh, matrix, out float distance)) continue;
                    if (distance < nearest) nearest = distance;
                }
            }
            finally { if (baked != null) UnityEngine.Object.DestroyImmediate(baked); }

            if (float.IsPositiveInfinity(nearest)) return false;
            world = ray.origin + ray.direction * nearest;
            return NeckSnapshot.Finite(world);
        }

        /// <summary>
        /// 1 つのメッシュに当てる。レイの方を形のローカル空間へ移して計算する
        /// （頂点を全部ワールドへ変換するより軽い）。行列は一次変換なので、
        /// ローカルで求めた係数はそのままワールドの距離として使える。
        /// </summary>
        private static bool TryPickInMesh(Ray ray, Mesh mesh, Matrix4x4 matrix, out float distance)
        {
            distance = 0;
            if (mesh == null) return false;
            float determinant = matrix.determinant;
            if (!NeckSnapshot.Finite(determinant) || Mathf.Abs(determinant) < 1e-12f) return false;
            var inverse = matrix.inverse;
            var origin = inverse.MultiplyPoint3x4(ray.origin);
            var direction = inverse.MultiplyVector(ray.direction);
            if (direction.sqrMagnitude <= Epsilon) return false;
            if (!mesh.bounds.IntersectRay(new Ray(origin, direction))) return false;

            var points = mesh.vertices;
            if (points.Length == 0) return false;
            // 鏡像（拡大率が負）の形では表裏が入れ替わる。符号で吸収する
            float sign = determinant < 0 ? -1 : 1;
            float nearest = float.PositiveInfinity;
            for (int sub = 0; sub < mesh.subMeshCount; sub++)
            {
                if (mesh.GetTopology(sub) != MeshTopology.Triangles) continue;
                var triangles = mesh.GetTriangles(sub);
                for (int t = 0; t + 2 < triangles.Length; t += 3)
                {
                    int ia = triangles[t], ib = triangles[t + 1], ic = triangles[t + 2];
                    if (ia < 0 || ib < 0 || ic < 0 || ia >= points.Length || ib >= points.Length || ic >= points.Length) continue;
                    if (!RayTriangle(origin, direction, points[ia], points[ib], points[ic], sign, out float hit)) continue;
                    if (hit < nearest) nearest = hit;
                }
            }
            if (float.IsPositiveInfinity(nearest)) return false;
            distance = nearest;
            return true;
        }

        /// <summary>
        /// レイと三角形の交差（Möller–Trumbore）。<b>表からの当たりだけ</b>採る。
        /// det = −dot(面の向き, レイの向き) なので、det が正なら表を向いている。
        /// 裏まで採ると、首の内側や口の中に線が落ちる。
        /// </summary>
        private static bool RayTriangle(Vector3 origin, Vector3 direction, Vector3 a, Vector3 b, Vector3 c, float sign, out float distance)
        {
            distance = 0;
            var edge1 = b - a; var edge2 = c - a;
            var pv = Vector3.Cross(direction, edge2);
            float det = Vector3.Dot(edge1, pv);
            if (det * sign <= Epsilon) return false;   // 平行、または裏を向いている
            float invDet = 1f / det;
            var tv = origin - a;
            float u = Vector3.Dot(tv, pv) * invDet;
            if (u < 0 || u > 1) return false;
            var qv = Vector3.Cross(tv, edge1);
            float v = Vector3.Dot(direction, qv) * invDet;
            if (v < 0 || u + v > 1) return false;
            distance = Vector3.Dot(edge2, qv) * invDet;
            return distance > Epsilon;   // 後ろ向きの当たりは採らない
        }

        // ── 描画 ──────────────────────────────────────────────────────
        // NeckOverlay と同じ作法（zTest=Always・遠い側は細く薄く・体側は破線）だが、
        // あちらは診断表示の持ち物なので、書き換えずにここへ写している。

        private void Draw(SceneView view)
        {
            if (view == null || view.camera == null) return;
            var center = Center();
            var oldDepth = Handles.zTest;
            var oldColor = Handles.color;
            try
            {
                // 線は髪や肌の上からでも見えないと置けない。遠い側だけ細く薄くする
                Handles.zTest = CompareFunction.Always;
                using (new Handles.DrawingScope(Matrix4x4.identity))
                {
                    for (int pass = 0; pass < 2; pass++)
                    {
                        if (upperRing != null) DrawRing(view, upperRing, center, pass, false, UpperColor);
                        if (lowerRing != null) DrawRing(view, lowerRing, center, pass, true, LowerColor);
                    }
                    if (HasUpper) DrawPoint(UpperWorld, UpperColor, L.T("上の線（顔側・100%）", "Upper line (face side, 100%)"));
                    if (HasLower) DrawPoint(LowerWorld, LowerColor, L.T("下の線（体側・0%）", "Lower line (body side, 0%)"));
                }
            }
            finally { Handles.zTest = oldDepth; Handles.color = oldColor; }
        }

        private void DrawRing(SceneView view, Vector3[] ring, Vector3 center, int pass, bool dashed, Color color)
        {
            var tint = new Color(color.r, color.g, color.b, pass == 0 ? .3f : 1);
            for (int i = 0; i < ring.Length; i++)
            {
                var a = ring[i]; var b = ring[(i + 1) % ring.Length];
                if (!NeckSnapshot.Finite(a) || !NeckSnapshot.Finite(b)) continue;
                if (Far(view, center, a, b) != (pass == 0)) continue;
                if (dashed) Dashed(view, a, b, pass == 0 ? 2 : 5, tint);
                else Stroke(a, b, pass == 0 ? 3 : 6, tint);
            }
        }

        private void DrawPoint(Vector3 world, Color color, string label)
        {
            if (!NeckSnapshot.Finite(world)) return;
            float size = HandleUtility.GetHandleSize(world) * DotSize;
            Handles.color = Color.black; Handles.DotHandleCap(0, world, Quaternion.identity, size * 1.5f, EventType.Repaint);
            Handles.color = color; Handles.DotHandleCap(0, world, Quaternion.identity, size, EventType.Repaint);
            Handles.Label(world + Vector3.up * size * 2, label);
        }

        /// <summary>遠い側／近い側を分ける基準点。輪があればその平均、無ければ置いた点。</summary>
        private Vector3 Center()
        {
            var total = Vector3.zero; int count = 0;
            foreach (var ring in new[] { upperRing, lowerRing })
            {
                if (ring == null) continue;
                foreach (var p in ring) { if (NeckSnapshot.Finite(p)) { total += p; count++; } }
            }
            if (count == 0)
            {
                if (HasUpper) { total += UpperWorld; count++; }
                if (HasLower) { total += LowerWorld; count++; }
            }
            return count == 0 ? Vector3.zero : total / count;
        }

        private static bool Far(SceneView view, Vector3 center, Vector3 a, Vector3 b)
        {
            var towardCamera = view.camera.orthographic ? -view.camera.transform.forward : view.camera.transform.position - center;
            return Vector3.Dot((a + b) * .5f - center, towardCamera) < 0;
        }

        private void Stroke(Vector3 a, Vector3 b, float width, Color color)
        {
            segment[0] = a; segment[1] = b;
            Handles.color = new Color(0, 0, 0, color.a * .9f); Handles.DrawAAPolyLine(width + 4, segment);
            Handles.color = color; Handles.DrawAAPolyLine(width, segment);
        }

        private void Dashed(SceneView view, Vector3 a, Vector3 b, float width, Color color)
        {
            if (view.camera.WorldToViewportPoint(a).z <= 0 || view.camera.WorldToViewportPoint(b).z <= 0) return;
            float length = Vector2.Distance(HandleUtility.WorldToGUIPoint(a), HandleUtility.WorldToGUIPoint(b));
            if (!NeckSnapshot.Finite(length) || length < .1f) return;
            int count = Mathf.Min(128, Mathf.CeilToInt(length / 14));
            for (int j = 0; j < count; j++)
            {
                float start = j * 14f / length, end = Mathf.Min((j * 14f + 7) / length, 1);
                if (start >= 1) break;
                Stroke(Vector3.Lerp(a, b, start), Vector3.Lerp(a, b, end), width, color);
            }
        }
    }
}
