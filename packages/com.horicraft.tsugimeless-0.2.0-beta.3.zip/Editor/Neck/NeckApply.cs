using System;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace HoriCraft.Tsugimeless.Editor
{
    internal sealed class NeckApplyResult
    {
        internal bool Ok;
        internal string Reason;
        internal Material Variant;
        internal Material Original;
        internal string PngPath, MaterialPath;
    }

    // Bake into a copy of the chosen skin texture (MainTex or supported second layer) and wear it through a
    // Material Variant under Assets/HoriCraft/Tsugimeless/<avatar>/. The original material, its texture and
    // its importer are only ever read. Restore reassigns the parent material and keeps the generated files.
    internal static class NeckApply
    {
        internal const string Suffix = "_Neck";
        internal const string RootFolder = "Assets/HoriCraft/Tsugimeless";
        private static readonly int[] SizeSteps = { 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384 };
        internal static int LiveResources { get; private set; }

        internal static string FolderFor(GameObject root) => RootFolder + "/" + Sanitize(root ? root.name : null);

        internal static NeckApplyResult Apply(GameObject root, Renderer renderer, int slot, RenderTexture candidateLinear, string suffix = Suffix, string textureProperty = SeamColorEvaluator.MainTexture)
        {
            var result = new NeckApplyResult();
            if (string.IsNullOrEmpty(suffix)) suffix = Suffix;
            Texture2D readback = null;
            try
            {
                if (EditorApplication.isPlayingOrWillChangePlaymode)
                    return Fail(result, L.T("Play中は適用できません。停止してからやり直してください。", "Applying is not available during Play. Stop Play and try again."));
                if (!root || !renderer) return Fail(result, L.T("アバター全体と描画部品を指定してください。", "Specify the whole avatar and the renderer."));
                var materials = renderer.sharedMaterials;
                if (slot < 0 || slot >= materials.Length) return Fail(result, L.T("指定した材質欄がありません。", "The specified material slot does not exist."));
                var current = materials[slot];
                if (!current) return Fail(result, L.T("材質欄に材質が入っていません。", "The material slot is empty."));
                // Re-applying replaces the same files instead of stacking a second variant on top of the first.
                var original = Generated(current, root, suffix) ? current.parent : current;
                if (!original) return Fail(result, L.T("材質欄に材質が入っていません。", "The material slot is empty."));
                if (!original.shader) return Fail(result, L.T("元の材質にシェーダーがありません。", "The original material has no shader."));
                if (!SeamColorEvaluator.KnownTexture(textureProperty))
                    return Fail(result, L.T("補正する画像の欄が見つかりません。もう一度、色を計算してください。", "The image slot to correct was not found. Compute the colors again."));
                if (textureProperty == SeamColorEvaluator.SecondTexture)
                {
                    string unsupported = SeamColorEvaluator.SecondLayerReason(original);
                    if (unsupported != null) return Fail(result, unsupported);
                }
                var mainTex = original.HasProperty(textureProperty) ? original.GetTexture(textureProperty) as Texture2D : null;
                if (!mainTex) return Fail(result, L.T("元の材質に基本の画像がありません。", "The original material has no base image."));
                if (!candidateLinear) return Fail(result, L.T("作った画像がありません。", "The generated image is missing."));
                if (candidateLinear.width != mainTex.width || candidateLinear.height != mainTex.height)
                    return Fail(result, L.T("作った画像の大きさが、元の画像と違います。", "The generated image size differs from the original image."));
                result.Original = original;

                string folder = FolderFor(root);
                if (!EnsureFolder(folder))
                    return Fail(result, L.F("書き出し先のフォルダ「{0}」を作れませんでした。", "Could not create the output folder {0}.", folder));
                string stem = Sanitize(original.name) + suffix;
                result.PngPath = folder + "/" + stem + ".png";
                result.MaterialPath = folder + "/" + stem + ".mat";

                // The source importer decides whether the PNG stores gamma-encoded colour; it is read, never written.
                string sourcePath = AssetDatabase.GetAssetPath(mainTex);
                var sourceImporter = string.IsNullOrEmpty(sourcePath) ? null : AssetImporter.GetAtPath(sourcePath) as TextureImporter;
                bool srgb = sourceImporter == null || sourceImporter.sRGBTexture;

                readback = ReadBack(candidateLinear, srgb);
                var bytes = readback.EncodeToPNG();
                if (bytes == null || bytes.Length == 0) return Fail(result, L.T("画像を書き出せませんでした。", "Could not write out the image."));
                File.WriteAllBytes(SystemPath(result.PngPath), bytes);
                AssetDatabase.ImportAsset(result.PngPath, ImportAssetOptions.ForceUpdate);
                CopyImportSettings(result.PngPath, sourceImporter, srgb, readback.width, readback.height);
                var baked = AssetDatabase.LoadAssetAtPath<Texture2D>(result.PngPath);
                if (!baked) return Fail(result, L.T("書き出した画像を読み込めませんでした。", "Could not load the image that was written out."));

                var variant = AssetDatabase.LoadAssetAtPath<Material>(result.MaterialPath);
                bool created = !variant;
                if (created) variant = new Material(original.shader);
                else if (variant.shader != original.shader) variant.shader = original.shader;
                variant.parent = original;
                variant.RevertAllPropertyOverrides();   // Own only the selected image, leaving all other settings inherited.
                variant.SetTexture(textureProperty, baked);
                if (created) AssetDatabase.CreateAsset(variant, result.MaterialPath);
                else EditorUtility.SetDirty(variant);

                Undo.RecordObject(renderer, L.T("ツギメレス: 首の補正を適用", "Tsugimeless: apply neck correction"));
                materials = renderer.sharedMaterials;
                materials[slot] = variant;
                renderer.sharedMaterials = materials;
                EditorUtility.SetDirty(renderer);
                if (PrefabUtility.IsPartOfPrefabInstance(renderer)) PrefabUtility.RecordPrefabInstancePropertyModifications(renderer);
                AssetDatabase.SaveAssetIfDirty(variant);   // Never save unrelated dirty materials in the user's project.
                if (NeckPreview.Active && NeckPreview.Target == renderer && NeckPreview.Slot == slot) NeckPreview.Hide();

                result.Ok = true;
                result.Variant = variant;
                return result;
            }
            catch (Exception exception)
            {
                return Fail(result, L.F("適用できませんでした（{0}）。", "Could not apply ({0}).", exception.Message));
            }
            finally
            {
                if (readback) { Object.DestroyImmediate(readback); LiveResources--; }
            }
        }

        internal static bool IsApplied(Renderer renderer, int slot, out Material original) => IsApplied(RootOf(renderer), renderer, slot, out original);

        internal static bool IsApplied(GameObject root, Renderer renderer, int slot, out Material original)
        {
            original = null;
            if (!renderer) return false;
            var materials = renderer.sharedMaterials;
            if (slot < 0 || slot >= materials.Length || !Generated(materials[slot], root, Suffix)) return false;
            original = materials[slot].parent;
            return original;
        }

        internal static bool Restore(Renderer renderer, int slot, out string reason)
        {
            reason = null;
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            { reason = L.T("Play中は適用できません。停止してからやり直してください。", "Applying is not available during Play. Stop Play and try again."); return false; }
            if (!IsApplied(renderer, slot, out var original))
            { reason = L.T("この材質欄には、ツギメレスで作った材質が入っていません。", "This material slot does not hold a material made by Tsugimeless."); return false; }
            Undo.RecordObject(renderer, L.T("ツギメレス: 首の補正を元に戻す", "Tsugimeless: restore the original neck material"));
            var materials = renderer.sharedMaterials;
            materials[slot] = original;
            renderer.sharedMaterials = materials;      // the generated .png / .mat stay on disk
            EditorUtility.SetDirty(renderer);
            if (PrefabUtility.IsPartOfPrefabInstance(renderer)) PrefabUtility.RecordPrefabInstancePropertyModifications(renderer);
            return true;
        }

        internal static GameObject RootOf(Renderer renderer)
        {
            if (!renderer) return null;
            var resolved = AvatarSelection.Resolve(renderer.gameObject).Root;
            return resolved ? resolved : renderer.transform.root.gameObject;
        }

        private static bool Generated(Material material, GameObject root, string suffix)
        {
            if (!material || !material.parent || !material.name.EndsWith(suffix, StringComparison.Ordinal)) return false;
            string path = AssetDatabase.GetAssetPath(material);
            return !string.IsNullOrEmpty(path) && path.StartsWith(FolderFor(root) + "/", StringComparison.Ordinal);
        }

        private static NeckApplyResult Fail(NeckApplyResult result, string reason)
        {
            result.Ok = false; result.Reason = reason; return result;
        }

        // The candidate holds what the shader samples from _MainTex (decoded / linear). An sRGB slot stores
        // gamma-encoded bytes, so the conversion happens here instead of relying on a ReadPixels side effect.
        private static Texture2D ReadBack(RenderTexture candidate, bool srgb)
        {
            var readback = new Texture2D(candidate.width, candidate.height, TextureFormat.RGBA32, false, true) { hideFlags = HideFlags.HideAndDontSave };
            LiveResources++;
            var previousTarget = RenderTexture.active;
            bool previousWrite = GL.sRGBWrite;
            bool ok = false;
            try
            {
                GL.sRGBWrite = false;
                RenderTexture.active = candidate;
                readback.ReadPixels(new Rect(0, 0, candidate.width, candidate.height), 0, 0, false);
                readback.Apply(false);
                if (srgb)
                {
                    var pixels = readback.GetPixels();
                    for (int i = 0; i < pixels.Length; i++)
                    {
                        var c = pixels[i];
                        float alpha = c.a;
                        c = c.gamma; c.a = alpha;     // alpha is never gamma-encoded
                        pixels[i] = c;
                    }
                    readback.SetPixels(pixels);
                    readback.Apply(false);
                }
                ok = true;
                return readback;
            }
            finally
            {
                RenderTexture.active = previousTarget;
                GL.sRGBWrite = previousWrite;
                if (!ok) { Object.DestroyImmediate(readback); LiveResources--; }
            }
        }

        // Mirrors RecipeBaker: read the source importer, write only the generated one.
        private static void CopyImportSettings(string assetPath, TextureImporter origin, bool srgb, int width, int height)
        {
            if (!(AssetImporter.GetAtPath(assetPath) is TextureImporter importer)) return;
            importer.textureType = TextureImporterType.Default;
            importer.textureShape = TextureImporterShape.Texture2D;
            importer.sRGBTexture = srgb;
            if (origin != null)
            {
                importer.alphaSource = origin.alphaSource;
                importer.alphaIsTransparency = origin.alphaIsTransparency;
                importer.npotScale = origin.npotScale;
                importer.mipmapEnabled = origin.mipmapEnabled;
                importer.wrapMode = origin.wrapMode;
                importer.filterMode = origin.filterMode;
                importer.anisoLevel = origin.anisoLevel;
                importer.textureCompression = origin.textureCompression;
                importer.compressionQuality = origin.compressionQuality;
                importer.maxTextureSize = Mathf.Max(origin.maxTextureSize, SizeStep(width, height));
            }
            else
            {
                importer.alphaSource = TextureImporterAlphaSource.FromInput;
                importer.alphaIsTransparency = true;
                importer.mipmapEnabled = true;
                importer.wrapMode = TextureWrapMode.Repeat;
                importer.filterMode = FilterMode.Bilinear;
                importer.textureCompression = TextureImporterCompression.Compressed;
                importer.maxTextureSize = SizeStep(width, height);
            }
            importer.crunchedCompression = false;   // re-baking a crunched texture degrades it every time
            importer.isReadable = false;            // nothing reads this back from the CPU at runtime
            importer.SaveAndReimport();
        }

        private static int SizeStep(int width, int height)
        {
            int longest = Mathf.Max(width, height);
            foreach (int step in SizeSteps) if (step >= longest) return step;
            return SizeSteps[SizeSteps.Length - 1];
        }

        private static bool EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return true;
            int cut = path.LastIndexOf('/');
            if (cut <= 0) return false;
            string parent = path.Substring(0, cut), leaf = path.Substring(cut + 1);
            return EnsureFolder(parent) && !string.IsNullOrEmpty(AssetDatabase.CreateFolder(parent, leaf));
        }

        private static string Sanitize(string name)
        {
            var builder = new StringBuilder();
            var invalid = Path.GetInvalidFileNameChars();
            foreach (char c in name ?? string.Empty)
                builder.Append(c == '/' || c == '\\' || Array.IndexOf(invalid, c) >= 0 ? '_' : c);
            string safe = builder.ToString().Trim().TrimEnd('.');
            return safe.Length == 0 ? "Avatar" : safe;
        }

        private static string SystemPath(string assetPath) => Path.Combine(Path.GetDirectoryName(Application.dataPath) ?? string.Empty, assetPath);
    }
}
