using System;
using System.Text;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    /// <summary>焼き込みの結果。候補の画像は呼び出し側が Dispose で手放す。</summary>
    internal sealed class NeckBakeResult : IDisposable
    {
        internal bool Valid;
        internal string Reason;
        internal string TextureProperty = SeamColorEvaluator.MainTexture;

        /// <summary>TextureProperty の画像と同じ空間・大きさの候補（linear float）。</summary>
        internal RenderTexture Candidate;

        /// <summary>帯の中での目標との誤差。</summary>
        internal float MaxError, MeanError;

        /// <summary>帯の中で許容 0.001 に届かなかった画素の数。</summary>
        internal int UnreachablePixels;
        internal int TotalPixels, BandPixels;

        internal bool PreservedOutside;

        /// <summary>帯の外で、返す候補を再評価した色と現在の色の最大差。</summary>
        internal float OutsideMaxDifference;
        internal string Summary;

        private bool released;
        public void Dispose()
        {
            if (released) return;
            released = true;
            if (Candidate) { Candidate.Release(); UnityEngine.Object.DestroyImmediate(Candidate); NeckBake.Released(); }
            Candidate = null;
        }
    }

    /// <summary>
    /// 帯と倍率から「この MainTex を入れれば、いまの材質設定を通したときに目標の色になる」画像を作る。
    ///
    /// 元材質の設定は書き換えず、画像を複製する。MainTexで届かないときは対応する2nd画像を試す。
    /// ソルバーが既存の設定込みで逆算するので、首以外の見え方は変わらない。
    /// 作った画像は RenderTexture のまま返し、PNG もアセットも書かない。
    /// </summary>
    internal static class NeckBake
    {
        /// <summary>帯の中で許容誤差に届かない画素がこの割合までなら適用可。割合は常に表示する。</summary>
        internal const float MaxUnreachableRatio = .02f;
        /// <summary>解放し忘れの検査用。テストの後片付けで 0 に戻ることを見る。</summary>
        internal static int LiveResources { get; private set; }
        internal static void Acquired() => LiveResources++;
        internal static void Released() => LiveResources--;

        internal static NeckBakeResult Bake(Material body, NeckSnapshot snapshot, NeckBandResult band, NeckReferenceResult reference, bool preserveOutside)
        {
            var first = BakeTexture(body, snapshot, band, reference, preserveOutside, SeamColorEvaluator.MainTexture);
            if (first.Valid || first.UnreachablePixels == 0 || !body || !body.HasProperty("_UseMain2ndTex") || body.GetFloat("_UseMain2ndTex") == 0)
                return first;
            string reason = SeamColorEvaluator.SecondLayerReason(body);
            if (reason != null) { first.Reason = reason; first.Summary = Describe(first); return first; }
            first.Dispose();
            return BakeTexture(body, snapshot, band, reference, preserveOutside, SeamColorEvaluator.SecondTexture);
        }

        private static NeckBakeResult BakeTexture(Material body, NeckSnapshot snapshot, NeckBandResult band, NeckReferenceResult reference, bool preserveOutside, string textureProperty)
        {
            var result = new NeckBakeResult { Summary = "", TextureProperty = textureProperty };
            if (!body || snapshot?.body == null || band == null || !band.Valid || reference == null || !reference.Valid)
            {
                result.Reason = band != null && !band.Valid ? band.Reason
                    : reference != null && !reference.Valid ? reference.Reason
                    : L.T("焼き込みに必要な材質・帯・倍率がそろっていません。", "The material, band and gains needed for the bake are not ready.");
                result.Summary = result.Reason;
                return result;
            }
            string environment = NeckGoal.EnvironmentReason();
            if (environment != null) { result.Reason = environment; result.Summary = environment; return result; }

            SeamColorEvaluator evaluator = null;
            Texture2D weight = null, gain = null;
            SeamColorImage current = null, goal = null, candidate = null, check = null, final = null;
            try
            {
                if (!SeamColorEvaluator.TryCreate(body, out evaluator, out string reason, textureProperty))
                { result.Reason = reason; result.Summary = reason; return result; }
                Acquired();
                if (!SeamColorEvaluator.IdentityUv(body, "_MainTex"))
                {
                    result.Reason = L.T("基本の画像を拡縮・移動しているため、首の範囲を正しく写せません。この設定での補正は未対応です。",
                        "The base image is scaled or offset, so the neck region cannot be mapped reliably. Correction with this setting is not supported yet.");
                    result.Summary = result.Reason; return result;
                }

                // 評価用の材質は _MainTex が無いとき白 1 枚を挿すので、元の材質側で確かめる。
                var main = body.GetTexture(textureProperty);
                if (!main) { result.Reason = L.T("この材質には焼き込む元の画像がありません。", "This material has no source image to bake into."); result.Summary = result.Reason; return result; }
                int width = main.width, height = main.height;
                if (width <= 0 || height <= 0 || width > UvMaskRasterizer.MaxSize || height > UvMaskRasterizer.MaxSize)
                {
                    result.Reason = L.F("画像の大きさ {0}x{1} は扱える範囲（{2} まで）を超えています。", "The image size {0}x{1} is beyond the supported limit of {2}.", width, height, UvMaskRasterizer.MaxSize);
                    result.Summary = result.Reason; return result;
                }
                result.TotalPixels = width * height;

                // ── 帯の濃さと倍率を UV へ焼く ────────────────────────
                var surface = snapshot.body;
                var triangles = new int[band.Triangles.Length * 3];
                for (int k = 0; k < band.Triangles.Length; k++)
                    for (int corner = 0; corner < 3; corner++)
                        triangles[k * 3 + corner] = surface.triangles[band.Triangles[k] * 3 + corner];

                weight = UvMaskRasterizer.CreateWeighted(surface.uv, triangles, band.T, width, height);
                if (weight) Acquired();
                gain = UvMaskRasterizer.CreateWeightedRgb(surface.uv, triangles, reference.VertexGain, width, height, NeckGoal.GainScale);
                if (gain) Acquired();
                if (!weight || !gain)
                {
                    result.Reason = L.T("帯を画像の上に写せません。UVを確認してください。", "The band could not be drawn onto the image. Check the UVs.");
                    result.Summary = result.Reason; return result;
                }

                // ── 目標をつくり、MainTex 空間の候補を逆算する ────────
                current = evaluator.Evaluate(); Acquired();
                goal = NeckGoal.Create(current, weight, gain);
                candidate = evaluator.Candidate(goal.Texture); Acquired();
                // Verify the exact image that will be previewed, including the outside-copy step.
                if (preserveOutside)
                {
                    final = NeckGoal.PreserveOutside(candidate, main, weight);
                    result.PreservedOutside = true;
                }
                check = evaluator.Evaluate(final != null ? final.Texture : candidate.Texture); Acquired();

                var inside = WeightMask(weight, result.TotalPixels, out int bandPixels);
                var outside = new bool[inside.Length];
                for (int i = 0; i < inside.Length; i++) outside[i] = !inside[i];
                result.BandPixels = bandPixels;

                var checkPixels = check.Read();
                var goalPixels = goal.Read();
                var currentPixels = current.Read();
                SeamColorSolver.Measure(checkPixels, goalPixels, inside, out result.MaxError, out result.MeanError, out result.UnreachablePixels, out _);
                SeamColorSolver.Measure(checkPixels, currentPixels, outside, out result.OutsideMaxDifference, out _, out _, out _);

                if (preserveOutside)
                {
                    result.Candidate = final.Detach();
                    final = null;
                }
                else
                {
                    // 数（Acquired）はそのまま結果へ引き継ぐ。解放は NeckBakeResult.Dispose が行う。
                    result.Candidate = candidate.Detach();
                    candidate = null;
                }

                // A few saturated or layer-covered pixels must not block the whole neck; the ratio is always reported.
                float unreachableRatio = result.BandPixels > 0 ? (float)result.UnreachablePixels / result.BandPixels : 1f;
                result.Valid = SeamColorEvaluator.Finite(result.MaxError) && result.BandPixels > 0 && unreachableRatio <= MaxUnreachableRatio;
                if (!result.Valid)
                    result.Reason = L.T("指定した色への到達を確認できません。補正は適用できません。", "The requested color could not be verified. This correction cannot be applied.");
                result.Summary = Describe(result);
                return result;
            }
            catch
            {
                result.Dispose();
                throw;
            }
            finally
            {
                if (check != null) { check.Dispose(); Released(); }
                if (goal != null) { goal.Dispose(); Released(); }
                if (current != null) { current.Dispose(); Released(); }
                if (candidate != null) { candidate.Dispose(); Released(); }
                if (final != null) { final.Dispose(); Released(); }
                if (gain) { UnityEngine.Object.DestroyImmediate(gain); Released(); }
                if (weight) { UnityEngine.Object.DestroyImmediate(weight); Released(); }
                if (evaluator != null) { evaluator.Dispose(); Released(); }
            }
        }

        // 帯の濃さの画像から「帯の中か」を取り出す。R8 でも RGBA32 でも先頭の 1 バイトが濃さ。
        private static bool[] WeightMask(Texture2D weight, int pixels, out int inside)
        {
            var mask = new bool[pixels];
            inside = 0;
            int stride = weight.format == TextureFormat.R8 ? 1 : 4;
            var data = weight.GetPixelData<byte>(0);
            for (int i = 0; i < pixels && i * stride < data.Length; i++)
            {
                mask[i] = data[i * stride] > 0;
                if (mask[i]) inside++;
            }
            return mask;
        }

        private static string Describe(NeckBakeResult result)
        {
            var text = new StringBuilder();
            text.Append("Texture: ").Append(result.TextureProperty).Append('\n');
            text.Append(L.F("帯の画素 {0} / 全体 {1}（{2:F1}%）", "Band pixels {0} of {1} ({2:F1}%)",
                result.BandPixels, result.TotalPixels, result.TotalPixels > 0 ? 100f * result.BandPixels / result.TotalPixels : 0f)).Append('\n');
            text.Append(L.F("帯の中の誤差 最大 {0:G4} / 平均 {1:G4}／届かなかった画素 {2}（{3:F2}%）", "Error inside the band: max {0:G4}, mean {1:G4}, pixels that fell short {2} ({3:F2}%)",
                result.MaxError, result.MeanError, result.UnreachablePixels, result.BandPixels > 0 ? 100f * result.UnreachablePixels / result.BandPixels : 0f)).Append('\n');
            text.Append(L.F("帯の外の差 最大 {0:G4}（1/255 = {1:G4}）", "Largest change outside the band: {0:G4} (1/255 = {1:G4})",
                result.OutsideMaxDifference, 1f / 255f)).Append('\n');
            text.Append(result.PreservedOutside
                ? L.T("帯の外は元の画像の画素をそのまま使いました。", "Outside the band the original image pixels were kept as they are.")
                : L.T("帯の外もソルバーの結果をそのまま使っています。", "Outside the band the solver result is used as it is."));
            if (result.Reason != null) { text.Append('\n'); text.Append(result.Reason); }
            return text.ToString();
        }
    }
}
