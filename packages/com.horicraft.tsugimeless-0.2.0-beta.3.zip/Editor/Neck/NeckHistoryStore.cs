using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    internal sealed class NeckHistoryState
    {
        internal NeckTargetIdentity Target;
        internal NeckHistoryInitial Initial;
        internal readonly List<NeckHistoryEntry> Entries = new List<NeckHistoryEntry>();
        internal readonly List<string> Warnings = new List<string>();
    }
    internal static class NeckHistoryStore
    {
        internal const string Root = NeckApply.RootFolder + "/History";
        internal static string Folder(NeckTargetIdentity target) => Root + "/" + target.key;
        private static string InitialPath(NeckTargetIdentity target) => Folder(target) + "/Initial/record.json";

        internal static NeckHistoryState Read(GameObject root, Renderer renderer, int slot)
        {
            var result = new NeckHistoryState { Target = NeckTargetIdentity.Create(root, renderer, slot) };
            string initialPath = InitialPath(result.Target);
            if (!File.Exists(initialPath)) return result;
            result.Initial = JsonUtility.FromJson<NeckHistoryInitial>(File.ReadAllText(initialPath));
            if (result.Initial == null || result.Initial.formatVersion != 1) throw new InvalidOperationException("history-format-not-supported");
            if (!result.Target.Same(result.Initial.target)) throw new InvalidOperationException("history-target-changed");
            // Checking the initial snapshot also verifies the original external textures/shader.
            VerifySaved(result.Initial.initial, result.Target); VerifySaved(result.Initial.baseline, result.Target);
            string applications = Folder(result.Target) + "/Applications";
            if (Directory.Exists(applications))
                foreach (string path in Directory.GetFiles(applications, "record.json", SearchOption.AllDirectories).OrderBy(p => p))
                {
                    try
                    {
                        var entry = JsonUtility.FromJson<NeckHistoryEntry>(File.ReadAllText(path));
                        if (entry == null || entry.formatVersion != 1) throw new InvalidOperationException("history-format-not-supported");
                        if (!result.Target.Same(entry.target) || !Guid.TryParseExact(entry.id, "N", out _)
                            || Path.GetFileName(Path.GetDirectoryName(path)) != entry.id) throw new InvalidOperationException("history-entry-target-mismatch");
                        VerifySaved(entry.material, result.Target); result.Entries.Add(entry);
                    }
                    catch (Exception e) { result.Warnings.Add(Path.GetFileName(Path.GetDirectoryName(path)) + ": " + e.Message); }
                }
            result.Entries.Sort((a, b) => string.Compare(a.utc, b.utc, StringComparison.Ordinal));
            return result;
        }

        internal static bool TryBaseline(GameObject root, Renderer renderer, int slot, out Material baseline, out string reason)
        {
            baseline = null; reason = null;
            try
            {
                // Unsaved scenes can calculate a transient preview. Only persistent history needs an ID.
                var current = renderer && slot >= 0 && slot < renderer.sharedMaterials.Length ? renderer.sharedMaterials[slot] : null;
                if (!current) throw new InvalidOperationException("material-slot-missing");
                NeckHistoryState history;
                try { history = Read(root, renderer, slot); }
                catch (InvalidOperationException e) when (e.Message == "save-scene-before-history")
                {
                    if (AssetDatabase.GetAssetPath(current).StartsWith(Root + "/", StringComparison.Ordinal)) throw;
                    baseline = LegacyBaseline(root, renderer, slot); return true;
                }
                if (history.Initial == null)
                {
                    if (AssetDatabase.GetAssetPath(current).StartsWith(Root + "/", StringComparison.Ordinal)) throw new InvalidOperationException("history-from-another-target");
                    baseline = LegacyBaseline(root, renderer, slot); return true;
                }
                RequireKnownCurrent(history, current);
                baseline = VerifySaved(history.Initial.baseline, history.Target); return true;
            }
            catch (Exception e) { reason = NeckHistoryAssets.Reason(e); return false; }
        }
        private static Material LegacyBaseline(GameObject root, Renderer renderer, int slot)
        {
            var current = renderer.sharedMaterials[slot];
            if (NeckApply.IsApplied(root, renderer, slot, out var source)) return source;
            if (current.name.EndsWith(NeckApply.Suffix, StringComparison.Ordinal)
                && AssetDatabase.GetAssetPath(current).StartsWith(NeckApply.RootFolder + "/", StringComparison.Ordinal))
                throw new InvalidOperationException("generated-material-origin-unknown");
            return current;
        }
        private static Material VerifySaved(NeckSavedMaterial saved, NeckTargetIdentity target)
        {
            if (saved?.asset == null) throw new InvalidOperationException("history-material-missing");
            string path = AssetDatabase.GUIDToAssetPath(saved.asset.guid);
            if (!path.StartsWith(Folder(target) + "/", StringComparison.Ordinal)) throw new InvalidOperationException("history-material-outside-target");
            return saved.LoadVerified();
        }
        private static void RequireKnownCurrent(NeckHistoryState history, Material current)
        {
            if (current == history.Initial.original?.Load<Material>() || current == history.Initial.initial.asset.Load<Material>()) return;
            if (history.Entries.Any(e => e.material.asset.Load<Material>() == current)) return;
            throw new InvalidOperationException("current-material-is-not-in-this-history");
        }
        private static NeckHistoryState Begin(GameObject root, Renderer renderer, int slot, Material computedFrom)
        {
            var history = Read(root, renderer, slot);
            if (!TryBaseline(root, renderer, slot, out var baseline, out var reason)) throw new InvalidOperationException(reason);
            if (!computedFrom || NeckHistoryAssets.MaterialState(baseline) != NeckHistoryAssets.MaterialState(computedFrom))
                throw new InvalidOperationException("calculation-source-changed");
            if (history.Initial != null) return history;
            var current = renderer.sharedMaterials[slot];
            string folder = Folder(history.Target) + "/Initial/" + Guid.NewGuid().ToString("N");
            NeckHistoryAssets.EnsureFolder(folder);
            var initial = NeckHistoryAssets.Snapshot(current, folder + "/Initial.mat");
            var baselineSnapshot = baseline == current ? initial : NeckHistoryAssets.Snapshot(baseline, folder + "/Baseline.mat");
            var record = new NeckHistoryInitial { utc = DateTime.UtcNow.ToString("O"), avatarName = root.name, rendererName = renderer.name,
                target = history.Target, original = NeckAssetReference.Of(current), originalState = NeckHistoryAssets.MaterialState(current), legacy = current != baseline,
                initial = NeckSavedMaterial.Capture(initial), baseline = NeckSavedMaterial.Capture(baselineSnapshot) };
            record.initial.LoadVerified(); record.baseline.LoadVerified();
            NeckHistoryAssets.WriteNew(InitialPath(history.Target), JsonUtility.ToJson(record, true));
            history.Initial = record; return history;
        }

        internal static NeckApplyResult Apply(GameObject root, Renderer renderer, int slot, Material computedFrom,
            NeckBakeResult bake, Material face, string shapeStamp, Vector3[] upper, Vector3[] lower)
        {
            var result = new NeckApplyResult();
            try
            {
                if (EditorApplication.isPlayingOrWillChangePlaymode || AnimationMode.InAnimationMode()) throw new InvalidOperationException("stop-play-or-animation");
                if (bake?.Valid != true || !bake.Candidate || bake.BandPixels <= 0 || bake.UnreachablePixels > bake.BandPixels * NeckBake.MaxUnreachableRatio
                    || !SeamColorEvaluator.Finite(bake.MaxError) || !SeamColorEvaluator.Finite(bake.MeanError)) throw new InvalidOperationException("valid-correction-required");
                if (!SeamColorEvaluator.KnownTexture(bake.TextureProperty)) throw new InvalidOperationException("unknown-image-slot");
                var history = Begin(root, renderer, slot, computedFrom);
                var baseline = VerifySaved(history.Initial.baseline, history.Target);
                if (bake.TextureProperty == SeamColorEvaluator.SecondTexture && SeamColorEvaluator.SecondLayerReason(baseline) != null)
                    throw new InvalidOperationException("unsupported-second-layer");
                var originalTexture = baseline.GetTexture(bake.TextureProperty) as Texture2D;
                if (!originalTexture || originalTexture.width != bake.Candidate.width || originalTexture.height != bake.Candidate.height)
                    throw new InvalidOperationException("image-size-changed");
                string id = Guid.NewGuid().ToString("N"), folder = Folder(history.Target) + "/Applications/" + id;
                NeckHistoryAssets.EnsureFolder(folder);
                result.PngPath = folder + "/Neck.png"; result.MaterialPath = folder + "/Neck.mat";
                var texture = NeckHistoryImage.Save(bake.Candidate, originalTexture, result.PngPath);
                NeckHistoryImage.Verify(baseline, bake.TextureProperty, bake.Candidate, texture, out float max, out float mean);
                var material = NeckHistoryAssets.Snapshot(baseline, result.MaterialPath);
                material.SetTexture(bake.TextureProperty, texture); AssetDatabase.SaveAssetIfDirty(material);
                var package = UnityEditor.PackageManager.PackageInfo.FindForAssetPath("Packages/com.horicraft.tsugimeless/package.json");
                var record = new NeckHistoryEntry { id = id, utc = DateTime.UtcNow.ToString("O"), target = history.Target,
                    material = NeckSavedMaterial.Capture(material), textureProperty = bake.TextureProperty, shapeStamp = shapeStamp,
                    upper = upper ?? Array.Empty<Vector3>(), lower = lower ?? Array.Empty<Vector3>(),
                    face = face ? NeckAssetReference.Of(face) : null, faceState = face ? NeckHistoryAssets.MaterialState(face) : "",
                    correctionMaxError = bake.MaxError, correctionMeanError = bake.MeanError, bandPixels = bake.BandPixels,
                    unreachablePixels = bake.UnreachablePixels, savedMaxError = max, savedMeanError = mean,
                    toolVersion = package?.version ?? "unknown", lilToonVersion = LilToonMaterialRead.Version(baseline) ?? "unknown" };
                VerifySaved(record.material, history.Target);
                if (!history.Target.Same(NeckTargetIdentity.Create(root, renderer, slot))) throw new InvalidOperationException("target-changed-during-write");
                RequireKnownCurrent(history, renderer.sharedMaterials[slot]);
                NeckHistoryAssets.WriteNew(folder + "/record.json", JsonUtility.ToJson(record, true));
                Assign(renderer, slot, material);
                result.Ok = true; result.Variant = material; result.Original = history.Initial.original.Load<Material>(); return result;
            }
            catch (Exception e) { result.Reason = NeckHistoryAssets.Reason(e); return result; }
        }
        internal static bool Restore(GameObject root, Renderer renderer, int slot, string entryId, out string reason)
        {
            reason = null;
            try
            {
                if (EditorApplication.isPlayingOrWillChangePlaymode || AnimationMode.InAnimationMode()) throw new InvalidOperationException("stop-play-or-animation");
                var history = Read(root, renderer, slot); if (history.Initial == null) throw new InvalidOperationException("no-history");
                RequireKnownCurrent(history, renderer.sharedMaterials[slot]); Material material;
                if (string.IsNullOrEmpty(entryId))
                {
                    var original = history.Initial.original.Load<Material>();
                    material = original && NeckHistoryAssets.MaterialState(original) == history.Initial.originalState ? original : VerifySaved(history.Initial.initial, history.Target);
                    if (material != original) reason = L.T("元の材質が変更されていたため、開始時に保存した材質へ戻しました。", "The source material changed, so the saved initial material was restored.");
                }
                else
                {
                    var entry = history.Entries.SingleOrDefault(e => e.id == entryId);
                    if (entry == null) throw new InvalidOperationException("history-entry-missing-or-changed");
                    material = VerifySaved(entry.material, history.Target);
                }
                Assign(renderer, slot, material); return true;
            }
            catch (Exception e) { reason = NeckHistoryAssets.Reason(e); return false; }
        }
        private static void Assign(Renderer renderer, int slot, Material material)
        {
            if (NeckPreview.Active && NeckPreview.Target == renderer && NeckPreview.Slot == slot) NeckPreview.Hide();
            Undo.RecordObject(renderer, L.T("ツギメレス: 仕上がりを切り替える", "Tsugimeless: switch result"));
            var materials = renderer.sharedMaterials; materials[slot] = material; renderer.sharedMaterials = materials;
            EditorUtility.SetDirty(renderer);
            if (PrefabUtility.IsPartOfPrefabInstance(renderer)) PrefabUtility.RecordPrefabInstancePropertyModifications(renderer);
        }
    }
}
