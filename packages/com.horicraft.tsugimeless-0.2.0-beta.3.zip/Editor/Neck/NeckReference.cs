using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    /// <summary>基準色を採るときの調整値。既定値は fable-evaluation §5 V2 のもの。</summary>
    internal sealed class NeckReferenceSettings
    {
        /// <summary>上の線から上下へ何 mm ぶんを採るか。</summary>
        internal float bandMm = 10f;

        /// <summary>軸まわりの区画の数。</summary>
        internal int sectors = 12;

        /// <summary>倍率の下限・上限。</summary>
        internal float minGain = .5f, maxGain = 2f;

        /// <summary>この数に足りない区画は「不足」として隣から埋める。</summary>
        internal int minSamples = 20;

        /// <summary>面の上に置く点の間隔（mm）。点 1 つが受け持つ面積は、この 2 乗。</summary>
        internal float sampleSpacingMm = 2f;

        /// <summary>三角形 1 枚から採る点の上限。細長い面 1 枚に点が集まりすぎるのを防ぐ。</summary>
        internal int maxPerTriangle = 64;

        /// <summary>顔側・体側それぞれの点数の上限。超えるときは間隔を一律に広げる。</summary>
        internal int maxSamples = 12000;

        /// <summary>顔側で見る半径を、帯の半径上限の何倍までにするか。顎は首より太い。</summary>
        internal float faceRadiusFactor = 2.5f;

        /// <summary>上の線より下にある顔側の面も、この mm ぶんは候補に入れる（線は区画ごとの近似なので）。</summary>
        internal float faceBelowMm = 2f;
    }

    /// <summary>区画 1 つぶんの測定結果。</summary>
    internal sealed class NeckSector
    {
        internal int index, faceSamples, bodySamples;
        internal Color faceAverage, bodyAverage;

        /// <summary>顔÷体（チャンネル別・linear）。</summary>
        internal Vector3 gain, smoothedGain;

        /// <summary>自前の測定では決められず、隣の区画から埋めた。</summary>
        internal bool interpolated;
    }

    internal sealed class NeckReferenceResult
    {
        internal bool Valid;
        internal string Reason;
        internal NeckSector[] Sectors;

        /// <summary>体の頂点ごとの倍率。帯の外は (1,1,1)。</summary>
        internal Vector3[] VertexGain;
        internal string Summary;
    }

    /// <summary>
    /// 上の線のすぐ上（顔側）とすぐ下（体側）の肌色を、軸まわりの区画ごとに平均し、
    /// 「体をどれだけ顔へ寄せるか」の倍率を出す。
    ///
    /// 色は <see cref="NeckColorSampler"/> が lilToon と同じ式で GPU 評価した値（linear）。
    /// 区画に分けるのは、顎の下に影が焼き込まれているテクスチャで前後の差を吸収するため。
    /// 単一の倍率だと、前を合わせると後ろがずれる。
    ///
    /// 点は頂点ではなく「面の上」に置く。実機の首は粗く（Milltina の帯は三角形 162 枚・頂点 119 個）、
    /// 頂点だけでは 1 区画あたり数点しか採れないため。候補の面は半径ではなく
    /// 「上の線からの距離」で選ぶ。顎は首より太いので、顔側を首の半径で切ると全部落ちる。
    /// </summary>
    internal static class NeckReference
    {
        /// <summary>1 つの側から採った点（区画ごとの UV）と、その採り方。</summary>
        private sealed class NeckSamples
        {
            internal List<Vector2>[] uv;
            internal int total;
            internal float spacingMm;

            /// <summary>点が多すぎたので、間隔を広げた・間引いた。</summary>
            internal bool reduced;
        }

        internal static NeckReferenceResult Compute(NeckSnapshot snapshot, NeckBandResult band,
                                                    NeckMaterialRead faceRead, NeckMaterialRead bodyRead,
                                                    NeckReferenceSettings settings = null)
        {
            settings = settings ?? new NeckReferenceSettings();
            int count = snapshot?.body?.positions?.Length ?? 0;
            var result = new NeckReferenceResult { VertexGain = Ones(count), Sectors = Array.Empty<NeckSector>(), Summary = "" };

            if (snapshot?.face == null || snapshot.body == null || band == null || !band.Valid)
            {
                result.Reason = band?.Reason ?? L.T("首の帯が決まっていないので、基準の色を採れません。", "The neck band is not decided yet, so the reference color cannot be measured.");
                result.Summary = result.Reason;
                return result;
            }
            string reason = NeckColorSampler.EnvironmentReason()
                ?? LilToonMaterialRead.ColorReason(faceRead) ?? LilToonMaterialRead.ColorReason(bodyRead);
            if (reason != null)
            {
                result.Reason = L.T("この材質と環境では、肌の色を読み取れません。", "The skin color cannot be read with this material and environment.") + " " + reason;
                result.Summary = result.Reason;
                return result;
            }
            if (snapshot.face.uv == null || snapshot.face.uv.Length != snapshot.face.positions.Length
                || snapshot.body.uv == null || snapshot.body.uv.Length != snapshot.body.positions.Length)
            {
                result.Reason = L.T("顔か体のUVが無いため、肌の色を読み取れません。", "The face or body has no UV, so the skin color cannot be read.");
                result.Summary = result.Reason;
                return result;
            }

            int sectors = Mathf.Max(1, settings.sectors);
            float reach = Mathf.Max(settings.bandMm, 0) / 1000f;
            float below = Mathf.Max(settings.faceBelowMm, 0) / 1000f;
            float faceRadius = band.RadiusLimit * Mathf.Max(settings.faceRadiusFactor, 1f);
            Func<float, int> sectorOf;
            if (sectors == band.SectorCount) sectorOf = band.Sector;
            else sectorOf = angle => Mathf.Clamp(Mathf.FloorToInt(angle / (2 * Mathf.PI / sectors)), 0, sectors - 1);

            var face = Gather(snapshot.face, FaceCandidates(snapshot.face, band, reach, below, faceRadius),
                              band, sectors, sectorOf, -below, reach, settings);
            var body = Gather(snapshot.body, BodyCandidates(snapshot.body, band, reach),
                              band, sectors, sectorOf, -reach, float.PositiveInfinity, settings);

            var faceColors = Evaluate(faceRead, face.uv, out string sampleReason);
            var bodyColors = sampleReason == null ? Evaluate(bodyRead, body.uv, out sampleReason) : null;
            if (sampleReason != null || bodyColors == null)
            {
                result.Reason = sampleReason; result.Summary = sampleReason; return result;
            }

            // ── 区画ごとの平均と倍率 ──────────────────────────────────
            var table = new NeckSector[sectors];
            for (int s = 0; s < sectors; s++)
            {
                var entry = new NeckSector { index = s, faceSamples = faceColors[s].Count, bodySamples = bodyColors[s].Count };
                entry.faceAverage = Average(faceColors[s]);
                entry.bodyAverage = Average(bodyColors[s]);
                entry.interpolated = entry.faceSamples < settings.minSamples || entry.bodySamples < settings.minSamples;
                var gain = Vector3.one;
                for (int c = 0; c < 3; c++)
                {
                    if (entry.bodyAverage[c] <= 1e-4f) { entry.interpolated = true; continue; }
                    gain[c] = Mathf.Clamp(entry.faceAverage[c] / entry.bodyAverage[c], settings.minGain, settings.maxGain);
                }
                entry.gain = gain;
                table[s] = entry;
            }
            if (table.All(e => e.interpolated))
            {
                result.Sectors = table;
                result.Reason = L.F("首まわりのどの区画でも、色を比べられる場所が {0} 点に届きませんでした。", "No sector around the neck reached {0} comparable samples.", settings.minSamples);
                // 失敗のときこそ、どこを何点採ったのかを残す（実機の調査用）。
                result.Summary = result.Reason + "\n" + Describe(table, faceRead, bodyRead, settings, face, body, faceRadius);
                return result;
            }

            // 足りない区画は円周方向に両隣から埋める
            var values = table.Select(e => e.gain).ToArray();
            var has = table.Select(e => !e.interpolated).ToArray();
            FillGains(values, has);
            for (int s = 0; s < sectors; s++) table[s].gain = values[s];

            // 1:2:1 で円周方向にならす
            for (int s = 0; s < sectors; s++)
            {
                var previous = values[(s - 1 + sectors) % sectors];
                var next = values[(s + 1) % sectors];
                table[s].smoothedGain = (previous + values[s] * 2f + next) / 4f;
            }

            // ── 頂点ごとの倍率 ────────────────────────────────────────
            var smoothed = table.Select(e => e.smoothedGain).ToArray();
            for (int i = 0; i < count; i++)
                result.VertexGain[i] = band.InBand[i] ? NeckBand.Circular(smoothed, band.Theta[i], Vector3.one) : Vector3.one;

            result.Sectors = table;
            result.Valid = true;
            result.Summary = Describe(table, faceRead, bodyRead, settings, face, body, faceRadius);
            return result;
        }

        // ── 採る場所を集める ──────────────────────────────────────────

        /// <summary>
        /// 体側の候補：帯の面のうち、上の線から <paramref name="reach"/> ぶん下までに重心がある面。
        /// 1 枚も無いときだけ、帯の面（頂点が帯の中にあるもの）をそのまま使う。
        /// </summary>
        private static List<int> BodyCandidates(NeckSurface body, NeckBandResult band, float reach)
        {
            var result = new List<int>();
            if (band.Triangles == null || body.triangles == null) return result;
            foreach (int face in band.Triangles)
            {
                if (!Centre(body, face, out var centre)) continue;
                float angle = band.Angle(centre);
                if (band.Height(centre) >= band.UpperAt(angle) - reach) result.Add(face);
            }
            if (result.Count > 0) return result;
            foreach (int face in band.Triangles)
            {
                if (!Centre(body, face, out _)) continue;
                bool inside = true;
                for (int corner = 0; corner < 3; corner++)
                {
                    int vertex = body.triangles[face * 3 + corner];
                    if (band.InBand != null && vertex < band.InBand.Length && band.InBand[vertex]) continue;
                    inside = false; break;
                }
                if (inside) result.Add(face);
            }
            return result;
        }

        /// <summary>
        /// 顔側の候補：上の線をまたぐ帯（線の <paramref name="below"/> 下〜<paramref name="reach"/> 上）に
        /// 重心がある面で、軸からの半径が <paramref name="radiusLimit"/> まで。
        /// 線をまたぐ面は残し、線より下の点だけを点ごとに落とす。
        /// </summary>
        private static List<int> FaceCandidates(NeckSurface face, NeckBandResult band, float reach, float below, float radiusLimit)
        {
            var result = new List<int>();
            if (face.triangles == null) return result;
            int faces = face.triangles.Length / 3;
            for (int k = 0; k < faces; k++)
            {
                if (!Centre(face, k, out var centre)) continue;
                if (band.Radius(centre) > radiusLimit) continue;
                float top = band.UpperAt(band.Angle(centre));
                float height = band.Height(centre);
                if (height < top - below || height > top + reach) continue;
                result.Add(k);
            }
            return result;
        }

        private static bool Centre(NeckSurface surface, int face, out Vector3 centre)
        {
            centre = Vector3.zero;
            var indices = surface.triangles;
            if (indices == null || face < 0 || face * 3 + 2 >= indices.Length) return false;
            centre = (surface.positions[indices[face * 3]] + surface.positions[indices[face * 3 + 1]] + surface.positions[indices[face * 3 + 2]]) / 3f;
            return true;
        }

        /// <summary>
        /// 候補の面の上に点を置き、上の線からの高さで選り分けて区画ごとの UV に振り分ける。
        /// 点が多すぎるときは、目標の面積を広げて（＝間隔を広げて）全体を抑える。
        /// </summary>
        private static NeckSamples Gather(NeckSurface surface, List<int> faces, NeckBandResult band, int sectors,
                                          Func<float, int> sectorOf, float lowOffset, float highOffset,
                                          NeckReferenceSettings settings)
        {
            var result = new NeckSamples { uv = Enumerable.Range(0, sectors).Select(_ => new List<Vector2>()).ToArray() };
            float spacing = Mathf.Max(settings.sampleSpacingMm, .01f) / 1000f;
            float target = spacing * spacing;
            var indices = surface.triangles;

            double area = 0;
            foreach (int face in faces)
            {
                if (!Corners(surface, face, out var a, out var b, out var c)) continue;
                area += .5 * Vector3.Cross(b - a, c - a).magnitude;
            }
            int cap = Mathf.Max(settings.maxSamples, sectors);
            if (area > 0 && area / target > cap) { target = (float)(area / cap); result.reduced = true; }
            result.spacingMm = Mathf.Sqrt(target) * 1000f;

            var points = new List<(Vector3 position, Vector2 uv)>();
            foreach (int face in faces)
            {
                if (!Corners(surface, face, out var a, out var b, out var c)) continue;
                int i0 = indices[face * 3], i1 = indices[face * 3 + 1], i2 = indices[face * 3 + 2];
                points.Clear();
                SurfaceSamples(a, b, c, surface.uv[i0], surface.uv[i1], surface.uv[i2], target, settings.maxPerTriangle, points);
                foreach (var point in points)
                {
                    float angle = band.Angle(point.position);
                    float height = band.Height(point.position) - band.UpperAt(angle);
                    if (height < lowOffset || height > highOffset) continue;
                    result.uv[sectorOf(angle)].Add(point.uv);
                }
            }

            // 1 区画あたりの上限を超えたら等間隔で間引く（GPU 採取の回数を抑える）。
            int limit = Mathf.Max(NeckColorSampler.ReferenceLimit / Mathf.Max(sectors, 1), NeckColorSampler.BatchLimit);
            for (int s = 0; s < sectors; s++)
            {
                if (result.uv[s].Count > limit)
                {
                    int stride = Mathf.CeilToInt(result.uv[s].Count / (float)limit);
                    result.uv[s] = result.uv[s].Where((_, i) => i % stride == 0).Take(limit).ToList();
                    result.reduced = true;
                }
                result.total += result.uv[s].Count;
            }
            return result;
        }

        private static bool Corners(NeckSurface surface, int face, out Vector3 a, out Vector3 b, out Vector3 c)
        {
            a = b = c = Vector3.zero;
            var indices = surface.triangles;
            if (indices == null || face < 0 || face * 3 + 2 >= indices.Length) return false;
            a = surface.positions[indices[face * 3]];
            b = surface.positions[indices[face * 3 + 1]];
            c = surface.positions[indices[face * 3 + 2]];
            return true;
        }

        /// <summary>
        /// 三角形の面の上に、目標の面積ごとに 1 点の割合で点を置く。
        /// 重心座標を k×k の格子に割り、小さな三角形の重心を採る（毎回同じ結果になる）。
        /// 位置と UV は同じ重心座標で補間するので、点はかならず面の内側に入る。
        /// </summary>
        /// <returns>置いた点の数（k×k）。</returns>
        internal static int SurfaceSamples(Vector3 a, Vector3 b, Vector3 c, Vector2 ua, Vector2 ub, Vector2 uc,
                                           float targetArea, int maxPerTriangle, List<(Vector3 position, Vector2 uv)> output)
        {
            if (output == null) return 0;
            int cap = Mathf.Max(maxPerTriangle, 1);
            float area = Vector3.Cross(b - a, c - a).magnitude * .5f;
            int wanted = 1;
            if (targetArea > 0 && area > targetArea && !float.IsNaN(area) && !float.IsInfinity(area))
                wanted = Mathf.Clamp(Mathf.CeilToInt(area / targetArea), 1, cap);
            int k = Mathf.Max(1, Mathf.CeilToInt(Mathf.Sqrt(wanted)));
            k = Mathf.Min(k, Mathf.Max(1, Mathf.FloorToInt(Mathf.Sqrt(cap))));

            var ab = b - a; var ac = c - a;
            var uab = ub - ua; var uac = uc - ua;
            float step = 1f / (3f * k);
            int added = 0;
            for (int i = 0; i < k; i++)
                for (int j = 0; i + j < k; j++)
                {
                    // 上向きの小三角形 (i,j),(i+1,j),(i,j+1) の重心
                    float u = (3 * i + 1) * step, v = (3 * j + 1) * step;
                    output.Add((a + ab * u + ac * v, ua + uab * u + uac * v));
                    added++;
                    if (i + j >= k - 1) continue;
                    // 下向きの小三角形 (i+1,j),(i,j+1),(i+1,j+1) の重心
                    u = (3 * i + 2) * step; v = (3 * j + 2) * step;
                    output.Add((a + ab * u + ac * v, ua + uab * u + uac * v));
                    added++;
                }
            return added;
        }

        // 区画ごとの UV を、1024 点ずつまとめて GPU で評価する。
        private static List<Color>[] Evaluate(NeckMaterialRead read, List<Vector2>[] buckets, out string reason)
        {
            reason = null;
            var result = Enumerable.Range(0, buckets.Length).Select(_ => new List<Color>()).ToArray();
            for (int s = 0; s < buckets.Length; s++)
            {
                var points = buckets[s];
                for (int start = 0; start < points.Count; start += NeckColorSampler.BatchLimit)
                {
                    int size = Mathf.Min(NeckColorSampler.BatchLimit, points.Count - start);
                    var uv = new Vector2[size];
                    for (int i = 0; i < size; i++) uv[i] = points[start + i];
                    if (uv.Any(v => !LilToonMaterialRead.Finite(v.x) || !LilToonMaterialRead.Finite(v.y)))
                    {
                        reason = L.T("読み取れないUVがあるため、肌の色を比べられません。", "Some UV coordinates cannot be read, so the skin colors cannot be compared.");
                        return result;
                    }
                    try
                    {
                        var sampled = NeckColorSampler.Sample(read, uv);
                        for (int i = 0; i < size; i++) result[s].Add(sampled[i * 2 + 1]);
                    }
                    catch (Exception e) when (e is NotSupportedException || e is ArgumentException || e is InvalidOperationException || e is ArithmeticException)
                    {
                        reason = L.T("この材質と環境では、肌の色を読み取れません。", "The skin color cannot be read with this material and environment.") + " " + e.Message;
                        return result;
                    }
                }
            }
            return result;
        }

        private static Color Average(List<Color> values)
        {
            if (values == null || values.Count == 0) return Color.clear;
            float r = 0, g = 0, b = 0;
            foreach (var value in values) { r += value.r; g += value.g; b += value.b; }
            return new Color(r / values.Count, g / values.Count, b / values.Count, 1);
        }

        private static Vector3[] Ones(int count)
        {
            var values = new Vector3[count];
            for (int i = 0; i < count; i++) values[i] = Vector3.one;
            return values;
        }

        /// <summary>足りない区画を、円周方向に両隣から埋める。</summary>
        internal static void FillGains(Vector3[] values, bool[] has)
        {
            int n = values.Length;
            if (n == 0 || !has.Any(v => v)) return;
            var filled = (Vector3[])values.Clone();
            for (int i = 0; i < n; i++)
            {
                if (has[i]) continue;
                int forward = 0; while (forward < n && !has[(i + forward) % n]) forward++;
                int backward = 0; while (backward < n && !has[((i - backward) % n + n) % n]) backward++;
                var a = values[((i - backward) % n + n) % n];
                var b = values[(i + forward) % n];
                filled[i] = Vector3.Lerp(a, b, backward / (float)(backward + forward));
            }
            Array.Copy(filled, values, n);
        }

        private static string Describe(NeckSector[] table, NeckMaterialRead faceRead, NeckMaterialRead bodyRead,
                                       NeckReferenceSettings settings, NeckSamples face, NeckSamples body, float faceRadius)
        {
            var text = new StringBuilder();
            if (faceRead != null && bodyRead != null && faceRead.source == bodyRead.source)
                text.Append(L.T("顔と体が同じ材質です。倍率は1に近くなります。", "The face and body share one material, so the gains stay close to 1.")).Append('\n');
            text.Append(L.F("面の上で採った点 顔 {0} 点／体 {1} 点（点の間隔 顔 {2:F2} mm／体 {3:F2} mm）",
                "Surface samples: face {0}, body {1} (spacing face {2:F2} mm, body {3:F2} mm)",
                face.total, body.total, face.spacingMm, body.spacingMm)).Append('\n');
            if (face.reduced || body.reduced)
                text.Append(L.T("点が多すぎたので、間隔を広げて数を抑えました。", "There were too many samples, so the spacing was widened to keep the count down.")).Append('\n');
            text.Append(L.F("顔側は軸から {0:F1} mm まで見ています（帯の半径上限の {1:F1} 倍）",
                "The face side reaches {0:F1} mm from the axis ({1:F1}x the band radius limit)",
                faceRadius * 1000f, Mathf.Max(settings.faceRadiusFactor, 1f))).Append('\n');
            text.Append(L.F("区画 {0}／不足して隣から埋めた区画 {1}", "Sectors {0}, filled from neighbours {1}", table.Length, table.Count(e => e.interpolated))).Append('\n');
            foreach (var entry in table)
                text.Append(L.F("区画{0}: 顔{1}点 体{2}点 倍率 {3:F3}, {4:F3}, {5:F3}", "Sector {0}: face {1}, body {2}, gain {3:F3}, {4:F3}, {5:F3}",
                    entry.index, entry.faceSamples, entry.bodySamples, entry.smoothedGain.x, entry.smoothedGain.y, entry.smoothedGain.z)).Append('\n');
            return text.ToString();
        }
    }
}
