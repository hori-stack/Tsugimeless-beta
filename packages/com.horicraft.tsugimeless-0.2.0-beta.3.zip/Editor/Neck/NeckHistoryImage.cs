using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace HoriCraft.Tsugimeless.Editor
{
    internal static class NeckHistoryImage
    {
        internal static Texture2D Preview(RenderTexture candidate, Texture2D original)
        {
            var importer = AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(original)) as TextureImporter;
            if (!importer) throw new InvalidOperationException("source-image-importer-missing");
            if (importer.mipmapEnabled && (!Mathf.IsPowerOfTwo(candidate.width) || !Mathf.IsPowerOfTwo(candidate.height)))
                throw new InvalidOperationException("preview-mip-size-not-supported");
            Texture2D raw = null, preview = null; var previous = RenderTexture.active;
            try
            {
                raw = new Texture2D(candidate.width, candidate.height, TextureFormat.RGBAFloat, false, true) { hideFlags = HideFlags.HideAndDontSave };
                RenderTexture.active = candidate; raw.ReadPixels(new Rect(0, 0, candidate.width, candidate.height), 0, 0, false); raw.Apply(false);
                var pixels = raw.GetPixels();
                for (int i = 0; i < pixels.Length; i++)
                {
                    var color = pixels[i];
                    for (int c = 0; c < 4; c++) if (!SeamColorEvaluator.Finite(color[c]) || color[c] < 0 || color[c] > 1) throw new InvalidOperationException("image-outside-png-range");
                    if (importer.sRGBTexture) { float alpha = color.a; color = color.gamma; color.a = alpha; }
                    pixels[i] = color;
                }
                preview = new Texture2D(candidate.width, candidate.height, TextureFormat.RGBA32, importer.mipmapEnabled, !importer.sRGBTexture)
                { name = "Tsugimeless PNG preview", hideFlags = HideFlags.HideAndDontSave, filterMode = importer.filterMode,
                    wrapModeU = importer.wrapModeU, wrapModeV = importer.wrapModeV, wrapModeW = importer.wrapModeW, anisoLevel = importer.anisoLevel };
                preview.SetPixels(pixels);
                // Texture2D.Apply's default mip chain is not the same as the importer's.
                // Average the quantized base in linear light, retaining float precision
                // between levels, then encode each level. This matches PNG Box import.
                FillMips(preview, importer.sRGBTexture);
                preview.Apply(false, false); return preview;
            }
            catch { if (preview) Object.DestroyImmediate(preview); throw; }
            finally { RenderTexture.active = previous; if (raw) Object.DestroyImmediate(raw); }
        }
        private static void FillMips(Texture2D texture, bool srgb)
        {
            if (texture.mipmapCount <= 1) return;
            var values = texture.GetPixels(0); int width = texture.width, height = texture.height;
            if (srgb) for (int i = 0; i < values.Length; i++) { float alpha = values[i].a; values[i] = values[i].linear; values[i].a = alpha; }
            for (int mip = 1; mip < texture.mipmapCount; mip++)
            {
                int w = Math.Max(1, width / 2), h = Math.Max(1, height / 2);
                var next = new Color[w * h]; var encoded = new Color[next.Length];
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++)
                {
                    Color sum = Color.clear;
                    for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++)
                        sum += values[Math.Min(height - 1, y * 2 + dy) * width + Math.Min(width - 1, x * 2 + dx)];
                    sum *= .25f; next[y * w + x] = sum;
                    var color = srgb ? sum.gamma : sum; color.a = sum.a; encoded[y * w + x] = color;
                }
                texture.SetPixels(encoded, mip); values = next; width = w; height = h;
            }
        }
        internal static Texture2D Save(RenderTexture candidate, Texture2D original, string path)
        {
            if (File.Exists(path)) throw new IOException("image-already-exists");
            var importer = AssetImporter.GetAtPath(AssetDatabase.GetAssetPath(original)) as TextureImporter;
            if (!importer) throw new InvalidOperationException("source-image-importer-missing");
            Texture2D png = null;
            try
            {
                png = Preview(candidate, original);
                using (var stream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                { byte[] bytes = png.EncodeToPNG(); stream.Write(bytes, 0, bytes.Length); }
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
                var target = AssetImporter.GetAtPath(path) as TextureImporter;
                if (!target) throw new IOException("generated-importer-missing");
                target.textureType = TextureImporterType.Default; target.textureShape = TextureImporterShape.Texture2D;
                target.sRGBTexture = importer.sRGBTexture;
                // Alpha and RGB already contain the source importer's result. Do not derive
                // alpha from the corrected RGB or dilate RGB a second time on this copy.
                target.alphaSource = TextureImporterAlphaSource.FromInput; target.alphaIsTransparency = false;
                target.mipmapFilter = TextureImporterMipFilter.BoxFilter;
                target.mipmapEnabled = importer.mipmapEnabled; target.wrapModeU = importer.wrapModeU; target.wrapModeV = importer.wrapModeV; target.wrapModeW = importer.wrapModeW;
                target.filterMode = importer.filterMode; target.anisoLevel = importer.anisoLevel; target.npotScale = TextureImporterNPOTScale.None;
                target.maxTextureSize = Mathf.Max(32, Mathf.NextPowerOfTwo(Mathf.Max(candidate.width, candidate.height)));
                target.textureCompression = TextureImporterCompression.Uncompressed; target.crunchedCompression = false; target.isReadable = false;
                target.SaveAndReimport();
                var result = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
                if (!result || result.width != candidate.width || result.height != candidate.height) throw new IOException("generated-image-size-changed");
                return result;
            }
            finally { if (png) Object.DestroyImmediate(png); }
        }
        internal static void Verify(Material baseline, string property, RenderTexture candidate, Texture2D imported, out float maximum, out float mean)
        {
            maximum = mean = 0;
            if (!SeamColorEvaluator.TryCreate(baseline, out var evaluator, out var reason, property)) throw new InvalidOperationException(reason);
            using (evaluator)
            using (var expected = evaluator.Evaluate(candidate))
            using (var actual = evaluator.Evaluate(imported))
            {
                var left = expected.Read(); var right = actual.Read(); double sum = 0; float alphaMax = 0;
                for (int i = 0; i < left.Length; i++)
                {
                    for (int c = 0; c < 3; c++)
                    {
                        float difference = Mathf.Abs(left[i][c] - right[i][c]);
                        if (!SeamColorEvaluator.Finite(difference)) throw new InvalidOperationException("saved-image-nonfinite");
                        maximum = Mathf.Max(maximum, difference); sum += difference;
                    }
                    float alphaDifference = Mathf.Abs(left[i].a - right[i].a);
                    if (!SeamColorEvaluator.Finite(alphaDifference)) throw new InvalidOperationException("saved-image-alpha-nonfinite");
                    alphaMax = Mathf.Max(alphaMax, alphaDifference);
                }
                mean = (float)(sum / (left.Length * 3));
                if (maximum > .01f || mean > .001f || alphaMax > 1f / 255f + 1e-6f)
                    throw new InvalidOperationException("saved-image-differs-from-preview: " + maximum + "/" + mean + "/" + alphaMax);
            }
        }
    }
}
