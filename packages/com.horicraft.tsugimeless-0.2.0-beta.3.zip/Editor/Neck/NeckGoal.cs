using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace HoriCraft.Tsugimeless.Editor
{
    /// <summary>
    /// 目標の画像を作る小さな合成。
    ///
    /// <b>goal = 現在の最終色 × lerp(1, 倍率, 帯の濃さ)</b>。帯の外は濃さ 0 なので goal は現在の色と同じになり、
    /// ソルバーは元の MainTex をそのまま答えにできる（＝帯の外は動かない）。
    ///
    /// 倍率は 1 を超えるので 8bit 画像には入らない。<see cref="GainScale"/> で割って入れ、
    /// シェーダー側が同じ値で戻す。
    /// </summary>
    internal static class NeckGoal
    {
        internal const string ShaderName = "Hidden/HoriCraft/TsugimelessNeckGoal";

        /// <summary>倍率の画像を 8bit へ入れるときに割る値（NeckReferenceSettings.maxGain と合わせる）。</summary>
        internal const float GainScale = 2f;

        internal static string EnvironmentReason()
        {
            var shader = Shader.Find(ShaderName);
            if (!shader || !shader.isSupported || ShaderUtil.ShaderHasError(shader)
                || !SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.ARGBFloat)
                || SystemInfo.graphicsDeviceType == GraphicsDeviceType.Null)
                return L.T("この環境では目標の色を作れません。", "The goal image cannot be built in this environment.");
            return null;
        }

        /// <summary>現在の最終色・帯の濃さ・倍率から目標の画像を作る。呼び出し側が破棄する。</summary>
        internal static SeamColorImage Create(SeamColorImage current, Texture weight, Texture gain)
        {
            if (current?.Texture == null) throw new ArgumentNullException(nameof(current));
            return Render(current.Texture, 0, material =>
            {
                material.SetTexture("_WeightTex", weight ? weight : Texture2D.blackTexture);
                material.SetTexture("_GainTex", gain ? gain : Texture2D.whiteTexture);
                material.SetFloat("_GainScale", gain ? GainScale : 1f);
            });
        }

        /// <summary>帯の外を元の MainTex の画素へ戻す。呼び出し側が破棄する。</summary>
        internal static SeamColorImage PreserveOutside(SeamColorImage candidate, Texture source, Texture weight)
        {
            if (candidate?.Texture == null) throw new ArgumentNullException(nameof(candidate));
            if (!source) throw new ArgumentNullException(nameof(source));
            if (source.width != candidate.Texture.width || source.height != candidate.Texture.height)
                throw new ArgumentException("Image sizes must match.");
            return Render(candidate.Texture, 1, material =>
            {
                material.SetTexture("_SourceTex", source);
                material.SetTexture("_WeightTex", weight ? weight : Texture2D.blackTexture);
            });
        }

        private static SeamColorImage Render(Texture input, int pass, Action<Material> configure)
        {
            string reason = EnvironmentReason();
            if (reason != null) throw new NotSupportedException(reason);
            Material material = null;
            SeamColorImage result = null;
            var active = RenderTexture.active;
            bool srgb = GL.sRGBWrite;
            try
            {
                material = new Material(Shader.Find(ShaderName)) { hideFlags = HideFlags.HideAndDontSave };
                NeckBake.Acquired();
                configure(material);
                result = new SeamColorImage(input.width, input.height, input);
                NeckBake.Acquired();
                GL.sRGBWrite = false;
                Graphics.Blit(input, result.Texture, material, pass);
                return result;
            }
            catch { if (result != null) { result.Dispose(); NeckBake.Released(); } throw; }
            finally
            {
                RenderTexture.active = active; GL.sRGBWrite = srgb;
                if (material) { UnityEngine.Object.DestroyImmediate(material); NeckBake.Released(); }
            }
        }
    }
}
