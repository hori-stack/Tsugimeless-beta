using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using Object = UnityEngine.Object;

namespace HoriCraft.Tsugimeless.Editor
{
    // Experimental, not called by NeckBake/NeckApply or the product window.
    internal static class NeckFlattening
    {
        internal static bool TryBake(Material source, out NeckFlattenedImage result, out string reason)
        {
            result = null;
            reason = NeckFlatteningSupport.MaterialReason(source);
            if (reason != null) return false;
            string stamp = LilToonMaterialRead.Capture(source).signature;
            if (!SeamColorEvaluator.TryCreate(source, out var evaluator, out reason)) return false;
            using (evaluator)
            {
                var image = evaluator.Evaluate();
                try
                {
                    var pixels = image.Read();
                    int invalid = 0;
                    foreach (var pixel in pixels)
                        for (int c = 0; c < 4; c++)
                            if (!SeamColorEvaluator.Finite(pixel[c]) || pixel[c] < 0 || pixel[c] > 1) { invalid++; break; }
                    if (invalid != 0)
                    {
                        reason = NeckFlatteningSupport.Refuse("out-of-range pixels: " + invalid);
                        return false;
                    }
                    if (stamp != LilToonMaterialRead.Capture(source).signature)
                    { reason = NeckFlatteningSupport.Refuse("input changed"); return false; }
                    result = new NeckFlattenedImage(source, stamp, image, pixels);
                    image = null;
                    return true;
                }
                finally { image?.Dispose(); }
            }
        }
    }

    internal sealed class NeckFlattenedImage : IDisposable
    {
        internal const string NormalizedProperties = "_MainTex, _MainTex_ST=(1,1,0,0), _Color=(1,1,1,1), _MainTexHSVG=(0,1,1,1), _MainGradationStrength=0, _UseMain2ndTex=0, _UseMain3rdTex=0";
        private readonly Material source;
        private readonly string stamp;
        private Texture2D image;
        internal readonly Color[] Pixels;
        internal readonly bool Srgb;
        internal Texture Texture => image;
        internal readonly FilterMode Filter;
        internal readonly TextureWrapMode WrapU, WrapV;
        internal readonly bool Mipmaps;
        internal readonly int Aniso;

        internal NeckFlattenedImage(Material source, string stamp, SeamColorImage image, Color[] pixels)
        {
            this.source = source; this.stamp = stamp; Pixels = pixels;
            var texture = source.GetTexture("_MainTex");
            Srgb = GraphicsFormatUtility.IsSRGBFormat(texture.graphicsFormat);
            Filter = texture.filterMode; WrapU = texture.wrapModeU; WrapV = texture.wrapModeV;
            Mipmaps = ((Texture2D)texture).mipmapCount > 1; Aniso = texture.anisoLevel;
            this.image = new Texture2D(texture.width, texture.height, TextureFormat.RGBAFloat, Mipmaps, true)
                { hideFlags = HideFlags.HideAndDontSave, filterMode = Filter, wrapModeU = WrapU, wrapModeV = WrapV, anisoLevel = Aniso };
            try { this.image.SetPixels(pixels); this.image.Apply(Mipmaps, false); }
            catch { Object.DestroyImmediate(this.image); this.image = null; throw; }
            image.Dispose();
        }

        private void RequireCurrent()
        {
            if (image == null) throw new ObjectDisposedException(nameof(NeckFlattenedImage));
            if (!source || stamp != LilToonMaterialRead.Capture(source).signature) throw new InvalidOperationException("Flattening input changed; recompute.");
        }
        internal bool Matches(Material material) => image && source && material == source && stamp == LilToonMaterialRead.Capture(source).signature;

        internal Material CreateMaterial(Texture replacement = null)
        {
            RequireCurrent();
            var material = new Material(source) { hideFlags = HideFlags.HideAndDontSave };
            material.SetTexture("_MainTex", replacement ? replacement : Texture);
            material.SetTextureScale("_MainTex", Vector2.one); material.SetTextureOffset("_MainTex", Vector2.zero);
            material.SetColor("_Color", Color.white);
            material.SetVector("_MainTexHSVG", new Vector4(0, 1, 1, 1));
            material.SetFloat("_MainGradationStrength", 0);
            material.SetFloat("_UseMain2ndTex", 0); material.SetFloat("_UseMain3rdTex", 0);
            return material;
        }

        internal void FillBlock(MaterialPropertyBlock block)
        {
            RequireCurrent();
            if (block == null) throw new ArgumentNullException(nameof(block));
            block.SetTexture("_MainTex", Texture); block.SetVector("_MainTex_ST", new Vector4(1, 1, 0, 0));
            block.SetColor("_Color", Color.white); block.SetVector("_MainTexHSVG", new Vector4(0, 1, 1, 1));
            block.SetFloat("_MainGradationStrength", 0); block.SetFloat("_UseMain2ndTex", 0); block.SetFloat("_UseMain3rdTex", 0);
        }

        internal byte[] EncodePng()
        {
            RequireCurrent();
            var output = new Texture2D(Texture.width, Texture.height, TextureFormat.RGBA32, false, true) { hideFlags = HideFlags.HideAndDontSave };
            try
            {
                var values = new Color[Pixels.Length];
                for (int i = 0; i < Pixels.Length; i++)
                { values[i] = Srgb ? Pixels[i].gamma : Pixels[i]; values[i].a = Pixels[i].a; }
                output.SetPixels(values); output.Apply(false);
                return output.EncodeToPNG();
            }
            finally { Object.DestroyImmediate(output); }
        }

        public void Dispose() { if (image) Object.DestroyImmediate(image); image = null; }
    }

    // Experimental scope: never assigns a material slot or writes an asset.
    internal sealed class NeckFlatteningPreview : IDisposable
    {
        private static readonly HashSet<NeckFlatteningPreview> Live = new HashSet<NeckFlatteningPreview>();
        private readonly Renderer renderer;
        private readonly int slot, count;
        private readonly Material source;
        private readonly Texture texture;
        private readonly NeckFlattenedImage result;
        private readonly MaterialPropertyBlock original;
        private bool disposed;
        static NeckFlatteningPreview()
        {
            AssemblyReloadEvents.beforeAssemblyReload += ReleaseAll;
            EditorApplication.playModeStateChanged += PlayModeChanged;
            EditorApplication.update += Tick;
            EditorApplication.quitting += ReleaseAll;
        }
        internal NeckFlatteningPreview(Renderer renderer, int slot, NeckFlattenedImage image)
        {
            if (!renderer || image == null || slot < 0 || slot >= renderer.sharedMaterials.Length)
                throw new ArgumentException("Preview target");
            if (EditorApplication.isPlayingOrWillChangePlaymode || AnimationMode.InAnimationMode()) throw new InvalidOperationException("Stop Play and Animation preview.");
            if (!image.Matches(renderer.sharedMaterials[slot])) throw new InvalidOperationException("Preview material changed; recompute.");
            foreach (var active in Live)
                if (active.renderer == renderer && active.slot == slot) throw new InvalidOperationException("Preview already active.");
            this.renderer = renderer; this.slot = slot; count = renderer.sharedMaterials.Length;
            source = renderer.sharedMaterials[slot]; texture = image.Texture; result = image;
            original = new MaterialPropertyBlock(); renderer.GetPropertyBlock(original, slot);
            var block = new MaterialPropertyBlock();
            if (original.isEmpty) renderer.GetPropertyBlock(block); else renderer.GetPropertyBlock(block, slot);
            image.FillBlock(block);
            renderer.SetPropertyBlock(block, slot); Live.Add(this);
        }
        internal static void ReleaseAll()
        { foreach (var active in new List<NeckFlatteningPreview>(Live)) active.Dispose(); }
        internal static void PlayModeChanged(PlayModeStateChange change)
        { if (change == PlayModeStateChange.ExitingEditMode) ReleaseAll(); }
        internal static void Tick()
        {
            foreach (var active in new List<NeckFlatteningPreview>(Live))
                if (!active.renderer || !active.texture || active.renderer.sharedMaterials.Length != active.count
                    || active.renderer.sharedMaterials[active.slot] != active.source || !active.result.Matches(active.source)) active.Dispose();
        }
        public void Dispose()
        {
            if (disposed) return;
            disposed = true;
            if (renderer && slot < renderer.sharedMaterials.Length) renderer.SetPropertyBlock(original.isEmpty ? null : original, slot);
            Live.Remove(this);
        }
    }
}
