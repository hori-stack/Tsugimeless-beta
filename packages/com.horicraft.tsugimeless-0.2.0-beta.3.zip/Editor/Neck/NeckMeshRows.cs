using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    // One row is a closed cycle of actual mesh edges at one graph step from the prior row.
    // This deliberately does not claim to reconstruct the artist's pre-triangulation quad loops.
    internal sealed class NeckMeshRows
    {
        internal readonly List<Vector3[]> Rings = new List<Vector3[]>();
        internal string Reason;
        internal readonly List<string> MatchDetails = new List<string>();
        internal Vector3 Origin, Axis;
        internal Vector3[] ContactRing;
        internal bool Valid => Rings.Count >= 2;
        internal Vector3[][] Lines;
        internal int Upper = -1, Lower = -1;

        internal static NeckMeshRows Build(NeckSnapshot snapshot, NeckResult detection)
        {
            var result = new NeckMeshRows();
            if (snapshot?.body?.positions == null || detection == null || !detection.Candidate || detection.Pairs.Count < 8)
            { result.Reason = "unique-neck-required"; return result; }
            result.Origin = snapshot.neck;
            var axis = snapshot.head - snapshot.neck;
            if (axis.sqrMagnitude <= 1e-8f) { result.Reason = "neck-axis-required"; return result; }
            result.Axis = axis.normalized;
            var surface = snapshot.body;
            var weld = NeckBand.Weld(surface.positions);
            var nodes = Enumerable.Range(0, weld.Length).GroupBy(i => weld[i]).ToDictionary(g => g.Key, g => surface.positions[g.First()]);
            var graph = new Dictionary<int, HashSet<int>>();
            var uses = new Dictionary<long, int>();
            for (int t = 0; t < surface.triangles.Length; t += 3)
            {
                int a = weld[surface.triangles[t]], b = weld[surface.triangles[t + 1]], c = weld[surface.triangles[t + 2]];
                if (a == b || b == c || c == a) continue;
                foreach (var edge in new[] { (a, b), (b, c), (c, a) })
                {
                    Connect(graph, edge.Item1, edge.Item2);
                    long key = Edge(edge.Item1, edge.Item2);
                    uses[key] = uses.TryGetValue(key, out int n) ? n + 1 : 1;
                }
            }
            var boundary = new Dictionary<int, HashSet<int>>();
            foreach (var use in uses.Where(p => p.Value == 1)) Connect(boundary, (int)(use.Key >> 32), (int)use.Key);
            // Measure the visible seam separately from the hidden body opening.
            var contactRing = detection.Pairs.Select(p => p.body.position).ToArray();
            result.ContactRing = contactRing;
            if (!result.AroundAxis(contactRing)) { result.Reason = "contact-axis-mismatch"; return result; }
            var remaining = new HashSet<int>(boundary.Keys);
            var candidates = new List<int[]>();
            while (remaining.Count > 0)
            {
                int start = remaining.Min();
                var component = new HashSet<int> { start }; var queue = new Queue<int>(); queue.Enqueue(start); remaining.Remove(start);
                while (queue.Count > 0)
                    foreach (int next in boundary[queue.Dequeue()])
                        if (component.Add(next)) { remaining.Remove(next); queue.Enqueue(next); }
                if (!Cycle(component, boundary, out var loop)) continue;
                var points = loop.Select(n => nodes[n]).ToArray();
                float forwardDistance = contactRing.Max(p => DistanceToRing(p, points));
                float reverseDistance = points.Max(p => DistanceToRing(p, contactRing));
                result.MatchDetails.Add($"nodes={loop.Length}; contact-to-edge-mm={forwardDistance * 1000:G5}; edge-to-contact-mm={reverseDistance * 1000:G5}; detection-threshold-mm={detection.thresholdMm:G5}");
                // The body opening can sit behind the face: it need not coincide with the visible seam.
                // Keep only complete openings around the neck axis and inside the detector's bone band.
                float length = Vector3.Distance(snapshot.head, snapshot.chest);
                var boneAxis = (snapshot.head - snapshot.chest).normalized;
                float neckHeight = Vector3.Dot(snapshot.neck - snapshot.chest, boneAxis);
                if (result.AroundAxis(points) && points.All(p =>
                {
                    float h = Vector3.Dot(p - snapshot.chest, boneAxis);
                    float radius = Vector3.ProjectOnPlane(p - snapshot.neck, boneAxis).magnitude;
                    return h >= neckHeight - .15f * length && h <= 1.1f * length && radius >= .03f * length && radius <= .65f * length;
                })) candidates.Add(loop);
            }
            if (candidates.Count != 1) { result.Reason = "body-open-cycle-count=" + candidates.Count; return result; }
            var ordered = candidates[0];
            var seed = new HashSet<int>(ordered);
            var seen = new HashSet<int>(seed);
            var acceptedNodes = new HashSet<int>();
            float baseRadius = seed.Average(n => result.Radial(nodes[n]).magnitude);
            for (int step = 0; step < 16; step++)
            {
                var ring = ordered.Select(n => nodes[n]).ToArray();
                if (seed.Any(n => graph[n].Any(v => uses[Edge(n, v)] > 2))) { result.Reason = "nonmanifold-row"; break; }
                if (!result.AroundAxis(ring)) { result.Reason = "folded-row"; break; }
                if (ring.Any(p => result.Radial(p).magnitude > baseRadius * 1.6f)) { result.Reason = "outside-neck-radius"; break; }
                if (result.Rings.Count > 0 && ring.Average(result.Height) >= result.Rings.Last().Average(result.Height) - .0001f)
                { result.Reason = "row-not-below"; break; }
                result.Rings.Add(ring);
                acceptedNodes.UnionWith(seed);
                var next = new HashSet<int>(seed.SelectMany(n => graph[n]).Where(n => !seen.Contains(n)));
                if (!Cycle(next, graph, out ordered)) { result.Reason = "next-row-not-a-single-cycle"; break; }
                seen.UnionWith(next); seed = next;
            }
            if (result.Valid)
            {
                if (detection.Pairs.Any(p => p.body.vertices == null || !p.body.vertices.Any(i => i >= 0 && i < weld.Length && acceptedNodes.Contains(weld[i]))))
                { result.Reason = "contact-not-on-traced-body-strip"; return result; }
                var choices = result.Rings.ToList(); choices.Add(contactRing);
                result.Lines = choices.OrderByDescending(r => r.Average(result.Height)).ToArray();
                result.Upper = Array.IndexOf(result.Lines, contactRing);
                // The visible contact must lie within the body rows, not beyond the traced strip.
                if (result.Gap(result.Rings[0], contactRing) < -.0001f || result.Gap(contactRing, result.Rings.Last()) < -.0001f)
                { result.Reason = "contact-outside-body-rows"; result.Lines = null; return result; }
                result.Lower = Enumerable.Range(result.Upper + 1, result.Lines.Length - result.Upper - 1)
                    .Where(i => result.CanUse(result.Upper, i))
                    .OrderBy(i => Mathf.Abs(contactRing.Average(result.Height) - result.Lines[i].Average(result.Height) - .025f))
                    .DefaultIfEmpty(-1).First();
            }
            return result;
        }

        internal bool Ready => Lines != null && CanUse(Upper, Lower);
        internal bool CanUse(int upper, int lower)
            => Lines != null && upper >= 0 && lower > upper && lower < Lines.Length && Gap(Lines[upper], Lines[lower]) >= .003f;
        internal float Gap(Vector3[] upper, Vector3[] lower)
        {
            if (upper == null || lower == null || upper.Length < 8 || lower.Length < 8) return float.NegativeInfinity;
            float gap = float.PositiveInfinity;
            foreach (var point in upper.Concat(lower))
            {
                var radial = Radial(point);
                float delta = At(upper, Origin, Axis, radial) - At(lower, Origin, Axis, radial);
                if (!NeckSnapshot.Finite(delta)) return float.NegativeInfinity;
                gap = Mathf.Min(gap, delta);
            }
            return gap;
        }
        // Intersect the real polygon edge with the radial half-plane. The display line and
        // the 100%/0% values at its vertices therefore use exactly the same boundary.
        internal static float At(Vector3[] ring, Vector3 origin, Vector3 axis, Vector3 radial)
        {
            var plane = Vector3.Cross(axis, radial.normalized);
            for (int i = 0; i < ring.Length; i++)
            {
                var a = ring[i] - origin; var b = ring[(i + 1) % ring.Length] - origin;
                float da = Vector3.Dot(a, plane), db = Vector3.Dot(b, plane), denominator = da - db;
                if (Mathf.Abs(denominator) < 1e-10f) continue;
                float t = da / denominator;
                if (t < -1e-5f || t > 1.00001f) continue;
                var hit = Vector3.Lerp(a, b, Mathf.Clamp01(t));
                if (Vector3.Dot(hit, radial) > 0) return Vector3.Dot(hit, axis);
            }
            return float.NaN;
        }

        internal float Height(Vector3 p) => Vector3.Dot(p - Origin, Axis);
        private static float DistanceToRing(Vector3 point, Vector3[] ring)
        {
            float distance = float.PositiveInfinity;
            for (int i = 0; i < ring.Length; i++)
            {
                var a = ring[i]; var edge = ring[(i + 1) % ring.Length] - a;
                float t = edge.sqrMagnitude > 0 ? Mathf.Clamp01(Vector3.Dot(point - a, edge) / edge.sqrMagnitude) : 0;
                distance = Mathf.Min(distance, (point - a - t * edge).magnitude);
            }
            return distance;
        }
        private Vector3 Radial(Vector3 p) => p - Origin - Axis * Height(p);
        private bool AroundAxis(Vector3[] ring)
        {
            float total = 0, sign = 0;
            for (int i = 0; i < ring.Length; i++)
            {
                var a = Radial(ring[i]); var b = Radial(ring[(i + 1) % ring.Length]);
                if (a.sqrMagnitude < 1e-10f || b.sqrMagnitude < 1e-10f) return false;
                float angle = Vector3.SignedAngle(a, b, Axis);
                if (Mathf.Abs(angle) < .01f || Mathf.Abs(angle) >= 90 || (sign != 0 && Mathf.Sign(angle) != sign)) return false;
                sign = Mathf.Sign(angle); total += angle;
            }
            return Mathf.Abs(Mathf.Abs(total) - 360) < .1f;
        }
        private static bool Cycle(HashSet<int> members, Dictionary<int, HashSet<int>> graph, out int[] ordered)
        {
            ordered = Array.Empty<int>();
            if (members.Count < 8 || members.Any(n => !graph.ContainsKey(n) || graph[n].Count(members.Contains) != 2)) return false;
            var walk = new List<int>(); int first = members.Min(), previous = -1, current = first;
            do
            {
                if (walk.Contains(current)) return false;
                walk.Add(current);
                int next = graph[current].Where(n => n != previous && members.Contains(n)).Min();
                previous = current; current = next;
            } while (current != first && walk.Count <= members.Count);
            if (walk.Count != members.Count) return false;
            ordered = walk.ToArray(); return true;
        }
        private static long Edge(int a, int b) => ((long)Math.Min(a, b) << 32) | (uint)Math.Max(a, b);
        private static void Connect(Dictionary<int, HashSet<int>> graph, int a, int b)
        {
            if (!graph.TryGetValue(a, out var aa)) graph[a] = aa = new HashSet<int>();
            if (!graph.TryGetValue(b, out var bb)) graph[b] = bb = new HashSet<int>();
            aa.Add(b); bb.Add(a);
        }
    }
}
