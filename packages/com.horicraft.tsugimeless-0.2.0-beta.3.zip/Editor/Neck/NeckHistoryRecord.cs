using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace HoriCraft.Tsugimeless.Editor
{
    [Serializable] internal sealed class NeckAssetReference
    {
        public string guid;
        public long localId;
        internal static NeckAssetReference Of(Object value)
        {
            if (!value || !AssetDatabase.TryGetGUIDAndLocalFileIdentifier(value, out string guid, out long id))
                throw new InvalidOperationException("asset-reference-missing");
            return new NeckAssetReference { guid = guid, localId = id };
        }
        internal T Load<T>() where T : Object => AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GUIDToAssetPath(guid))
            .OfType<T>().FirstOrDefault(item => AssetDatabase.TryGetGUIDAndLocalFileIdentifier(item, out string g, out long id) && g == guid && id == localId);
        internal string Token => guid + ":" + localId;
    }
    [Serializable] internal sealed class NeckDependency
    {
        public string guid, importedHash;
        internal bool Unchanged => !string.IsNullOrEmpty(AssetDatabase.GUIDToAssetPath(guid))
            && AssetDatabase.GetAssetDependencyHash(AssetDatabase.GUIDToAssetPath(guid)).ToString() == importedHash;
    }
    [Serializable] internal sealed class NeckSavedMaterial
    {
        public NeckAssetReference asset;
        public string state, fileHash;
        public NeckDependency[] dependencies;
        internal Material LoadVerified()
        {
            var material = asset?.Load<Material>();
            if (!material || NeckHistoryAssets.MaterialState(material) != state
                || NeckHistoryAssets.FileHash(AssetDatabase.GetAssetPath(material)) != fileHash
                || dependencies == null || dependencies.Any(d => !d.Unchanged))
                throw new InvalidOperationException("saved-material-or-dependency-changed");
            return material;
        }
        internal static NeckSavedMaterial Capture(Material material) => new NeckSavedMaterial
        {
            asset = NeckAssetReference.Of(material), state = NeckHistoryAssets.MaterialState(material),
            fileHash = NeckHistoryAssets.FileHash(AssetDatabase.GetAssetPath(material)), dependencies = NeckHistoryAssets.Dependencies(material)
        };
    }
    [Serializable] internal sealed class NeckTargetIdentity
    {
        public string key, sceneGuid, rootId, rendererId, meshGuid, meshHash;
        public long meshLocalId;
        public int vertexCount, slot, slotCount;
        internal static NeckTargetIdentity Create(GameObject root, Renderer renderer, int slot)
        {
            if (!root || !renderer || !renderer.transform.IsChildOf(root.transform) || root.scene != renderer.gameObject.scene
                || EditorUtility.IsPersistent(root) || !root.scene.IsValid() || !root.scene.isLoaded
                || UnityEditor.SceneManagement.EditorSceneManager.IsPreviewScene(root.scene))
                throw new InvalidOperationException("scene-target-required");
            if (slot < 0 || slot >= renderer.sharedMaterials.Length || !renderer.sharedMaterials[slot])
                throw new InvalidOperationException("material-slot-missing");
            string sceneGuid = AssetDatabase.AssetPathToGUID(root.scene.path);
            var rootId = GlobalObjectId.GetGlobalObjectIdSlow(root); var rendererId = GlobalObjectId.GetGlobalObjectIdSlow(renderer);
            if (string.IsNullOrEmpty(sceneGuid) || rootId.targetObjectId == 0 || rendererId.targetObjectId == 0
                || rootId.assetGUID.ToString() != sceneGuid || rendererId.assetGUID.ToString() != sceneGuid)
                throw new InvalidOperationException("save-scene-before-history");
            var mesh = NeckTargets.MeshOf(renderer);
            if (!mesh || !AssetDatabase.TryGetGUIDAndLocalFileIdentifier(mesh, out string meshGuid, out long meshId))
                throw new InvalidOperationException("saved-mesh-required");
            var result = new NeckTargetIdentity { sceneGuid = sceneGuid, rootId = rootId.ToString(), rendererId = rendererId.ToString(),
                slot = slot, slotCount = renderer.sharedMaterials.Length, meshGuid = meshGuid, meshLocalId = meshId, vertexCount = mesh.vertexCount,
                meshHash = AssetDatabase.GetAssetDependencyHash(AssetDatabase.GetAssetPath(mesh)).ToString() };
            result.key = NeckHistoryAssets.Hash(sceneGuid + "\n" + result.rootId + "\n" + result.rendererId + "\n" + slot);
            return result;
        }
        internal bool Same(NeckTargetIdentity other) => other != null && JsonUtility.ToJson(this) == JsonUtility.ToJson(other);
    }
    [Serializable] internal sealed class NeckHistoryInitial
    {
        public int formatVersion = 1;
        public string utc, avatarName, rendererName, originalState;
        public bool legacy;
        public NeckTargetIdentity target;
        public NeckAssetReference original;
        public NeckSavedMaterial initial, baseline;
    }
    [Serializable] internal sealed class NeckHistoryEntry
    {
        public int formatVersion = 1;
        public string id, utc, method = "texture-copy", textureProperty, toolVersion, lilToonVersion, shapeStamp;
        public string faceState;
        public NeckAssetReference face;
        public NeckTargetIdentity target;
        public NeckSavedMaterial material;
        public Vector3[] upper, lower;
        public float correctionMaxError, correctionMeanError, savedMaxError, savedMeanError;
        public int bandPixels, unreachablePixels;
    }
    internal static class NeckHistoryAssets
    {
        internal static string Hash(string text)
        {
            using (var hash = SHA256.Create()) return BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(text))).Replace("-", "").ToLowerInvariant();
        }
        internal static string FileHash(string path)
        {
            using (var stream = File.OpenRead(path)) using (var hash = SHA256.Create())
                return BitConverter.ToString(hash.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
        }
        internal static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            int cut = path.LastIndexOf('/'); if (cut < 1) throw new IOException("invalid-output-folder");
            EnsureFolder(path.Substring(0, cut));
            if (string.IsNullOrEmpty(AssetDatabase.CreateFolder(path.Substring(0, cut), path.Substring(cut + 1)))) throw new IOException("output-folder-unavailable");
        }
        internal static void WriteNew(string path, string text)
        {
            // Incomplete records never have the committed .json name. Both paths are under the
            // generated target folder; no existing output is replaced or removed.
            string pending = path + ".pending-" + Guid.NewGuid().ToString("N");
            using (var stream = new FileStream(pending, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            using (var writer = new StreamWriter(stream, new UTF8Encoding(false))) writer.Write(text);
            File.Move(pending, path); AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
        }
        internal static string MaterialState(Material source)
        {
            if (!source || !source.shader) return "missing";
            var text = new StringBuilder(source.shader.name).Append('|').Append(AssetDatabase.GetAssetPath(source.shader));
            text.Append('|').Append(source.renderQueue).Append('|').Append(source.enableInstancing).Append('|').Append(source.doubleSidedGI).Append('|').Append((int)source.globalIlluminationFlags);
            foreach (string keyword in source.shaderKeywords.OrderBy(k => k, StringComparer.Ordinal)) text.Append('|').Append(keyword);
            foreach (string tag in new[] { "RenderType", "Queue", "IgnoreProjector", "DisableBatching", "PreviewType", "CanUseSpriteAtlas" }) text.Append('|').Append(tag).Append('=').Append(source.GetTag(tag, false, ""));
            for (int pass = 0; pass < source.passCount; pass++) text.Append('|').Append(source.GetPassName(pass)).Append('=').Append(source.GetShaderPassEnabled(source.GetPassName(pass)));
            var shader = source.shader;
            void Value(float value) => text.Append(value.ToString("R", CultureInfo.InvariantCulture)).Append(',');
            for (int i = 0; i < shader.GetPropertyCount(); i++)
            {
                string property = shader.GetPropertyName(i); text.Append('|').Append(property).Append('=');
                switch (shader.GetPropertyType(i))
                {
                    case ShaderPropertyType.Color: var c = source.GetColor(property); for (int j = 0; j < 4; j++) Value(c[j]); break;
                    case ShaderPropertyType.Vector: var v = source.GetVector(property); for (int j = 0; j < 4; j++) Value(v[j]); break;
                    case ShaderPropertyType.Texture:
                        var texture = source.GetTexture(property);
                        if (texture) text.Append(NeckAssetReference.Of(texture).Token); else text.Append("null");
                        var scale = source.GetTextureScale(property); var offset = source.GetTextureOffset(property);
                        Value(scale.x); Value(scale.y); Value(offset.x); Value(offset.y); break;
                    case ShaderPropertyType.Int: text.Append(source.GetInteger(property)); break;
                    default: Value(source.GetFloat(property)); break;
                }
            }
            return Hash(text.ToString());
        }
        internal static NeckDependency[] Dependencies(Material material)
        {
            var paths = new HashSet<string>(StringComparer.Ordinal);
            string shader = AssetDatabase.GetAssetPath(material.shader); if (!string.IsNullOrEmpty(shader)) paths.Add(shader);
            foreach (string property in material.GetTexturePropertyNames())
            {
                var texture = material.GetTexture(property); if (!texture) continue;
                string path = AssetDatabase.GetAssetPath(texture);
                if (string.IsNullOrEmpty(path)) throw new InvalidOperationException("unsaved-texture-dependency");
                paths.Add(path);
            }
            return paths.OrderBy(p => p).Select(path => new NeckDependency { guid = AssetDatabase.AssetPathToGUID(path),
                importedHash = AssetDatabase.GetAssetDependencyHash(path).ToString() }).ToArray();
        }
        internal static Material Snapshot(Material source, string path)
        {
            if (File.Exists(path)) throw new IOException("snapshot-already-exists");
            var copy = new Material(source) { name = Path.GetFileNameWithoutExtension(path) };
            try
            {
                if (copy.parent) copy.parent = null;
                copy.CopyPropertiesFromMaterial(source);
                if (copy.parent || MaterialState(copy) != MaterialState(source)) throw new InvalidOperationException("independent-material-copy-differs");
                AssetDatabase.CreateAsset(copy, path); AssetDatabase.SaveAssetIfDirty(copy); return copy;
            }
            catch { if (!AssetDatabase.Contains(copy)) Object.DestroyImmediate(copy); throw; }
        }
        internal static string Reason(Exception exception)
        {
            switch (exception.Message)
            {
                case "preview-mip-size-not-supported":
                    return L.T("この画像の大きさでは、保存後と同じ仮表示を作れません。補正を止めました。", "This image size cannot produce a preview matching the saved result. Correction was stopped.");
                case "save-scene-before-history":
                    return L.T("あとから戻すために、このアバターが置かれたシーンを先に保存してください。ツールからは保存しません。", "Save the scene containing this avatar first so history can identify it later. The tool will not save the scene.");
                case "saved-material-or-dependency-changed":
                    return L.T("履歴で使う画像・材質・シェーダーが変更されています。当時の見た目を確認できないため、切り替えを止めました。", "An image, material, or shader used by history changed. Switching was stopped because the saved appearance cannot be verified.");
                case "history-target-changed": case "history-from-another-target": case "current-material-is-not-in-this-history":
                    return L.T("この履歴と、今のアバターや肌の材質欄が一致しません。対象を確認してください。", "This history does not match the current avatar or skin material slot. Check the target.");
                case "history-format-not-supported":
                    return L.T("この履歴の保存形式は、この版では開けません。新しいツギメレスで確認してください。", "This version cannot open the history format. Check it with a newer Tsugimeless version.");
                default: return L.T("履歴を使えません。元の状態は変更していません。", "History is unavailable. The current state was not changed.") + " " + exception.Message;
            }
        }
    }
}
