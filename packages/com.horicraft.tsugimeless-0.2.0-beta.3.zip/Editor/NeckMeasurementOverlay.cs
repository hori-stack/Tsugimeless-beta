using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace HoriCraft.Tsugimeless.Editor
{
    internal sealed class NeckMeasurementOverlay
    {
        private NeckPair pair;
        internal bool Visible => pair != null;
        internal void Show(NeckPair value) { Hide(); pair = value; if (pair != null) SceneView.duringSceneGui += Draw; SceneView.RepaintAll(); }
        internal void Hide() { SceneView.duringSceneGui -= Draw; pair = null; SceneView.RepaintAll(); }
        private void Draw(SceneView view)
        {
            if (pair == null || Event.current.type != EventType.Repaint) return;
            var depth = Handles.zTest;
            try
            {
                Handles.zTest = CompareFunction.Always;
                using (new Handles.DrawingScope(Matrix4x4.identity))
                    foreach (bool face in new[] { true, false })
                    {
                        var point = face ? pair.face.position : pair.body.position;
                        float size = HandleUtility.GetHandleSize(point) * .045f;
                        Handles.color = Color.black; Handles.DrawWireDisc(point, view.camera.transform.forward, size * 1.25f, 5);
                        Handles.color = face ? Color.cyan : Color.yellow; Handles.DrawWireDisc(point, view.camera.transform.forward, size * (face ? 1 : .7f), 3);
                    }
            }
            finally { Handles.zTest = depth; }
        }
    }
}
