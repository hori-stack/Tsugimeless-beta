using UnityEditor;

namespace HoriCraft.Tsugimeless.Editor
{
    internal static class L
    {
        internal static int Language
        {
            get => EditorPrefs.GetInt("HoriCraft.Tsugimeless.Language", 0);
            set => EditorPrefs.SetInt("HoriCraft.Tsugimeless.Language", value);
        }
        internal static string F(string ja, string en, params object[] args) => string.Format(T(ja, en), args);
        internal static string T(string ja, string en)
        {
            switch (Language)
            {
                case 1: return en;
                case 2: return LocTable.Get(ja, 0) ?? en;
                case 3: return LocTable.Get(ja, 1) ?? en;
                default: return ja;
            }
        }
    }
}
