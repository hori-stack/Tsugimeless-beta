using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    public sealed partial class TsugimelessWindow
    {
        private string licenseNotice;
        private bool licenseWasActive;
        private void BuildSettingsPage()
        {
            body.Add(TsugimelessStyles.Heading(L.T("設定", "Settings")));
            BuildLicenseCard();
            BuildTesterReportCard();
        }
        private void BuildLicenseRequiredNotice()
        {
            body.Add(new HelpBox(L.T("色の計算から先は製品版で使えます。", "Color calculation and subsequent steps require the full version."), HelpBoxMessageType.Info));
            body.Add(TsugimelessStyles.ColoredButton(L.T("設定で解除キーを登録する", "Register an unlock key in Settings"), () => Navigate(WorkflowPage.Settings), "open-license-settings"));
        }
        private void BuildLicenseCard()
        {
            licenseWasActive = TsugimelessLicense.Active;
            var card = TsugimelessStyles.Card(); card.name = "license-card";
            var heading = TsugimelessStyles.Heading(licenseWasActive ? L.T("製品版（登録済み）", "Full version (registered)") : L.T("体験版", "Trial"));
            heading.name = "license-status"; card.Add(heading);
            if (!licenseWasActive)
            {
                card.Add(TsugimelessStyles.Note(L.T("アバター選択と上下の線の調整を試せます。色を作る前に、解除キーを入力してください。", "Try avatar selection and upper/lower line adjustment. Enter an unlock key before generating colors.")));
                if (TsugimelessLicense.Status == TsugimelessLicenseCodec.Result.NotConfigured)
                    card.Add(new HelpBox(TsugimelessLicense.Message(TsugimelessLicense.Status), HelpBoxMessageType.Info));
                var input = new TextField(L.T("解除キー", "Unlock key")) { name = "license-key", isPasswordField = true, maxLength = 8192 };
                card.Add(input);
                var activate = TsugimelessStyles.ColoredButton(L.T("キーを登録する", "Register key"), () =>
                { var status = TsugimelessLicense.Activate(input.value); input.SetValueWithoutNotify(""); licenseNotice = TsugimelessLicense.Message(status); RenderBody(); }, "license-register");
                activate.SetEnabled(TsugimelessLicense.Status != TsugimelessLicenseCodec.Result.NotConfigured); card.Add(activate);
            }
            if (TsugimelessLicense.Registered)
                card.Add(TsugimelessStyles.ColoredButton(L.T("このPCのキー登録を解除する", "Unregister the key on this PC"), () =>
                { TsugimelessLicense.Remove(); DropSeamColor(); licenseNotice = null; RenderBody(); }, "license-remove"));
            if (!string.IsNullOrEmpty(licenseNotice)) card.Add(new HelpBox(licenseNotice, HelpBoxMessageType.Info));
            body.Add(card);
        }
        private void CheckLicenseChange()
        {
            bool active = TsugimelessLicense.Active;
            if (active == licenseWasActive) return;
            licenseWasActive = active;
            if (!active) DropSeamColor();
            RenderBody();
        }
    }
}
