using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    internal enum NeckDiagnosisState { Idle, Running, Measured, Partial, Unsupported, Stale, Cancelled }
    internal sealed class NeckColorReference
    {
        internal int pair, slot, triangle;
        internal bool face, measured;
        internal Vector2 uv;
        internal Color raw, evaluated;
        internal NeckMaterialRead material;
        internal string reason;
    }
    internal sealed class NeckColorPoint
    {
        internal int index;
        internal NeckPair position;
        internal readonly List<NeckColorReference> face = new List<NeckColorReference>(), body = new List<NeckColorReference>();
        internal bool Complete => face.Count > 0 && body.Count > 0 && face.Concat(body).All(r => r.measured);
        internal bool Unique => Complete && Consistent(face) && Consistent(body);
        internal static bool Consistent(List<NeckColorReference> refs) => refs.Count > 0 && refs.All(r => NeckDiagnosis.Delta(r.evaluated, refs[0].evaluated).maxColorComponent <= 1e-4f && NeckDiagnosis.Delta(r.raw, refs[0].raw).maxColorComponent <= 1e-4f);
    }
    internal sealed class NeckDiagnosis
    {
        internal const string Model = "lilToon unlit-base / S3.1 / mip 0 / linear RGB";
        internal NeckDiagnosisState state;
        internal string stamp, geometryReason, reason;
        internal float normalMean, normalMax;
        internal bool normalsMeasured;
        internal Color mean, max;
        internal int compared, sampled, batches, peakBatchBytes;
        internal long elapsedMs, maxStepMs, managedHeapDelta;
        internal readonly List<NeckColorPoint> points = new List<NeckColorPoint>();
        internal readonly List<NeckMaterialPair> materials = new List<NeckMaterialPair>();
        internal readonly Dictionary<Material, NeckMaterialRead> reads = new Dictionary<Material, NeckMaterialRead>();
        internal string[] shared = Array.Empty<string>();
        internal bool ReferenceVersion => reads.Values.Any(m => m.version != LilToonMaterialRead.VerifiedVersion);
        internal int ActiveDifferences => materials.Sum(p => p.properties.Count(v => v.different && !v.inactive && v.reason == null));
        internal int UnknownSettings => materials.Sum(p => p.properties.Count(v => v.reason != null));
        internal static Color Delta(Color a, Color b) => new Color(Mathf.Abs(a.r - b.r), Mathf.Abs(a.g - b.g), Mathf.Abs(a.b - b.b), 0);
        internal void Aggregate()
        {
            compared = sampled = 0; mean = max = new Color(0, 0, 0, 0);
            foreach (var point in points)
            {
                if (point.Complete) sampled++;
                if (!point.Unique) continue;
                compared++; var delta = Delta(point.face[0].evaluated, point.body[0].evaluated); mean += delta;
                for (int k = 0; k < 3; k++) max[k] = Mathf.Max(max[k], delta[k]);
            }
            if (compared != 0) mean /= compared;
            state = points.Count != 0 && compared == points.Count && reason == null ? NeckDiagnosisState.Measured : compared > 0 ? NeckDiagnosisState.Partial : NeckDiagnosisState.Unsupported;
        }
    }
}
