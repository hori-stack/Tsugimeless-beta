using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    internal enum SeamStep { Range, Appearance, Apply }
    public sealed partial class TsugimelessWindow
    {
        [SerializeField] private SeamStep seamStep;
        private bool seamFocusPending;
        private void UpdateWorkflowProgress()
        {
            if (workflowProgress == null) return;
            int index = page == WorkflowPage.Start ? 1 : page == WorkflowPage.Seam ? (int)seamStep + 2 : 0;
            workflowProgress.text = index == 0 ? L.T("詳しく調べる（旧）", "Inspect in detail (legacy)")
                : L.F("{0}/4　選ぶ → 上下の範囲 → 見た目 → 適用", "{0}/4  Choose → Range → Appearance → Apply", index);
        }
        private void BuildSeamSelection()
        {
            EnsureNeckTargets();
            BuildSeamTargets(SeamTargetsReady());
            var next = TsugimelessStyles.ColoredButton(L.T("次へ：上下の範囲", "Next: upper and lower range"), () => GoSeamStep(SeamStep.Range), "enter-seam", true);
            next.SetEnabled(SeamTargetsReady()); workflowFooter?.Add(next);
        }
        internal void GoSeamStep(SeamStep next)
        {
            if (!SeamTargetsReady()) return;
            if (next != SeamStep.Range && (seamBand?.Valid != true || seamStale)) return;
            if (next == SeamStep.Apply && (seamBake?.Valid != true || seamPreviewReason != null || !ColorInputCurrent())) return;
            if (next == SeamStep.Range && page == WorkflowPage.Start) seamFocusPending = true;
            if (next == SeamStep.Range) HideSeamPreview();
            seamStep = next; Navigate(WorkflowPage.Seam);
            if (seamFocusPending && seamBand?.Valid == true) { seamFocusPending = false; FocusSeam(NeckViewAngle.Front); }
        }
        private void BuildSeamPage()
        {
            EnsureNeckTargets(); bool ready = SeamTargetsReady();
            body.Add(TsugimelessStyles.Note(context.Root ? context.Root.name : NoticeText(SelectionNotice.SelectAvatar)));
            if (seamStale) body.Add(new HelpBox(L.T("アバターが変わったため、②からやり直してください。", "The avatar changed. Start again from step 2."), HelpBoxMessageType.Warning));
            switch (seamStep)
            {
                case SeamStep.Range: BuildRangeStep(ready); break;
                case SeamStep.Appearance: BuildAppearanceStep(ready); break;
                case SeamStep.Apply: BuildApplyStep(ready); break;
            }
            var back = TsugimelessStyles.ColoredButton(L.T("前の工程へ", "Previous step"),
                () => { if (seamStep == SeamStep.Range) Navigate(WorkflowPage.Start); else { HideSeamPreview(); seamStep--; RenderBody(); } }, "back-start");
            workflowFooter?.Add(back);
            if (seamStep != SeamStep.Apply)
            {
                var next = TsugimelessStyles.ColoredButton(seamStep == SeamStep.Range ? L.T("次へ：見た目", "Next: appearance") : L.T("次へ：適用", "Next: apply"),
                    () => GoSeamStep(seamStep + 1), "workflow-next", true);
                next.SetEnabled(ready && !seamStale && seamBand?.Valid == true && (seamStep == SeamStep.Range || TsugimelessLicense.Active && seamBake?.Valid == true && seamPreviewReason == null));
                workflowFooter?.Add(next);
            }
        }
        private void BuildRangeStep(bool ready)
        {
            body.Add(TsugimelessStyles.Heading(L.T("上下の線を確かめる", "Check the upper and lower lines")));
            if (ready && !placer.HasUpper && !seamAutoTried) { seamAutoPending = true; seamAutoTried = true; }
            if (!ready) body.Add(new HelpBox(L.T("顔と体を確かめて、「この顔・体を使う」を押してください。", "Check the face and body, then press Use this face and body."), HelpBoxMessageType.Info));
            var suggest = TsugimelessStyles.SmallButton(L.T("上下の線を最初の位置へ戻す", "Reset both lines to their initial positions"),
                () => { seamAutoPending = true; seamAutoReason = null; RenderBody(); }, "seam-suggest");
            suggest.SetEnabled(ready && !seamAutoPending);
            if (seamAutoPending) body.Add(TsugimelessStyles.Note(L.T("顔との境目と、近くのメッシュの段を調べています…", "Finding the face boundary and nearby mesh rows…")));
            if (!string.IsNullOrEmpty(seamAutoReason)) body.Add(new HelpBox(seamAutoReason, HelpBoxMessageType.Warning));
            var range = TsugimelessStyles.Card(); range.name = "seam-range-card";
            foreach (bool upper in new[] { true, false })
            {
                var card = new VisualElement { name = upper ? "upper-line-card" : "lower-line-card" }; card.AddToClassList("tsg-line-section");
                var heading = TsugimelessStyles.Heading(upper ? L.T("水色：顔に合わせる位置", "Cyan: match the face here") : L.T("黄色：元の体色に戻る位置", "Yellow: return to the original body color"));
                heading.AddToClassList(upper ? "tsg-upper-heading" : "tsg-lower-heading"); card.Add(heading);
                if (!upper) card.Add(TsugimelessStyles.Note(L.T("下げるほど、ゆっくり元の色に戻ります。", "Move it down for a more gradual return to the original color.")));
                BuildSeamRowButtons(card, upper, ready && !seamStale); range.Add(card);
            }
            range.Add(suggest); body.Add(range);
            if (seamBandReason != null) body.Add(new HelpBox(seamBandReason, HelpBoxMessageType.Warning));
            BuildSeamViews();
        }
        private void BuildSeamViews()
        {
            var card = TsugimelessStyles.Card(); card.name = "seam-views";
            card.Add(TsugimelessStyles.Heading(L.T("首を見る向き", "View the neck")));
            var angles = new[] { NeckViewAngle.Front, NeckViewAngle.Left, NeckViewAngle.Right, NeckViewAngle.Back };
            // Camera movement is also possible in Scene View; do not claim a persisted selected angle.
            var views = TsugimelessStyles.ChoiceBar(new[] { L.T("正面", "Front"), L.T("左ななめ", "Front left"),
                L.T("右ななめ", "Front right"), L.T("後ろ", "Back") }, angles.Select(a => "seam-view-" + a).ToArray(), -1, index => FocusSeam(angles[index]));
            views.AddToClassList("tsg-view-row"); views.SetEnabled(seamBand?.Valid == true); card.Add(views);
            if (neckView.CanRestore) card.Add(TsugimelessStyles.SmallButton(L.T("元の視点に戻す", "Restore previous view"), RestoreNeckView, "seam-restore-view"));
            body.Add(card);
        }
        private void FocusSeam(NeckViewAngle angle)
        {
            if (seamBand?.Valid != true) return;
            var result = new NeckResult { state = NeckState.Candidate };
            result.loops.Add(seamBand.UpperRing.Concat(seamBand.LowerRing).Select(p => new NeckPair { face = new NeckPoint { position = p }, body = new NeckPoint { position = p } }).ToList());
            neckView.Focus(result, neckTargets, angle); RenderBody();
        }
        private void BuildAppearanceStep(bool ready)
        {
            if (!TsugimelessLicense.Active) BuildLicenseRequiredNotice();
            body.Add(TsugimelessStyles.Heading(L.T("首の見た目を確かめる", "Check the neck appearance")));
            body.Add(TsugimelessStyles.Note(L.T("顔の色を見本に、首から下へ少しずつ元の肌色に戻します。", "Use the face as a reference and gradually return to the original skin color down the neck.")));
            body.Add(TsugimelessStyles.Note(L.T("影やツヤは変更しません。照明や形による境目は残る場合があります。", "Shadow and gloss settings are unchanged. Seams caused by lighting or shape may remain.")));
            var compute = TsugimelessStyles.ColoredButton(L.T("色を計算する", "Compute the colors"), ComputeSeamColors, "seam-step3", true);
            compute.SetEnabled(TsugimelessLicense.Active && ready && seamBand?.Valid == true && !seamStale); body.Add(compute);
            if (seamColorReason != null) body.Add(new HelpBox(seamColorReason, HelpBoxMessageType.Warning));
            if (seamPreviewReason != null) body.Add(new HelpBox(seamPreviewReason, HelpBoxMessageType.Warning));
            if (seamBake?.Valid == true)
            {
                var comparison = TsugimelessStyles.Card(); comparison.name = "seam-comparison";
                bool shown = SeamPreviewShown();
                string status = !shown ? L.T("仮表示を終了しました。計算結果は残っています。", "Preview ended. The calculated result is retained.")
                    : seamPreviewAfter ? L.T("補正後を仮表示しています。", "Previewing the corrected result.") : L.T("補正前を仮表示しています。", "Previewing the original result.");
                comparison.Add(TsugimelessStyles.Status(status, "seam-preview-status"));
                comparison.Add(TsugimelessStyles.Note(seamApplied ? L.T("この仕上がりは適用済みです。", "This result has been applied.")
                    : L.T("まだ適用していません。補正前と補正後を見比べてください。", "Not applied yet. Compare the original and corrected results.")));
                if (shown && NeckPreview.PausesOtherPreviews)
                    comparison.Add(TsugimelessStyles.Note(L.T("仮表示中は、他のツールのプレビューを一時停止します。仮表示を終了すると再開します。", "Other tools' previews are paused during this preview and resume when it ends.")));
                comparison.Add(TsugimelessStyles.ChoiceBar(new[] { L.T("補正前", "Before correction"), L.T("補正後", "Corrected") },
                    new[] { "seam-before", "seam-after" }, shown ? (seamPreviewAfter ? 1 : 0) : -1,
                    index => { if (index == 1) ShowSeamPreview(); else ShowSeamBefore(); RenderBody(); }));
                var end = TsugimelessStyles.SmallButton(L.T("仮表示を終了する", "End preview"), () => { HideSeamPreview(); RenderBody(); }, "seam-preview-off");
                end.SetEnabled(shown); comparison.Add(end); body.Add(comparison);
                BuildSeamViews();
            }
            if (seamBake != null)
            {
                var details = new Foldout { text = L.T("詳しい測定結果", "Detailed measurements"), value = false };
                details.Add(TsugimelessStyles.Note(seamBake.Summary));
                details.Add(TsugimelessStyles.Note(seamBake.TextureProperty)); body.Add(details);
            }
        }
        private void ShowSeamBefore()
        {
            if (!TsugimelessLicense.Require(out seamPreviewReason)) { HideSeamPreview(); return; }
            seamPreviewReason = null; if (!ColorInputCurrent()) return;
            var original = seamComputedFrom.GetTexture(seamBake.TextureProperty);
            if (!NeckPreview.ShowBaseline(neckTargets.Body, SeamBodySlot, seamComputedFrom, original, out var reason, seamBake.TextureProperty)) seamPreviewReason = reason;
            else seamPreviewAfter = false;
        }
        private string ColorStamp(Material baseline) => LilToonMaterialRead.Capture(SeamMaterial(true)).signature + ":" + LilToonMaterialRead.Capture(baseline).signature;
        private bool ColorInputCurrent()
        {
            if (seamBake?.Valid != true || !seamComputedFrom || !SeamTargetsReady()) return false;
            if (NeckSnapshot.Signature(neckTargets) == seamSignature && ColorStamp(seamComputedFrom) == seamColorStamp) return true;
            DropSeamColor(); seamColorReason = L.T("材質や画像が変わりました。もう一度、色を計算してください。", "A material or image changed. Compute the colors again."); return false;
        }
        private void BuildApplyStep(bool ready)
        {
            body.Add(TsugimelessStyles.Heading(L.T("確認して適用する", "Review and apply")));
            body.Add(TsugimelessStyles.Note(L.T("肌画像のコピーを作り、選んだ体の材質欄だけに使います。元画像と元材質は残します。", "Create a skin-image copy and use it only in the selected body slot. The original image and material are kept.")));
            body.Add(TsugimelessStyles.Note(L.T("適用ごとの画像を残すため、保存容量は増えます。シーンは自動保存しません。", "Keeping an image for each application uses more storage. The scene is not saved automatically.")));
            if (seamApplied)
            {
                body.Add(TsugimelessStyles.Status(L.T("適用しました。", "Applied."), "seam-applied-status"));
                body.Add(new HelpBox(L.T("この仕上がりを次回も使うには、Unityでシーンを保存してください。", "To keep this result for next time, save the scene in Unity."), HelpBoxMessageType.Info) { name = "seam-save-scene-notice" });
            }
            if (!string.IsNullOrEmpty(seamApplyReason)) body.Add(new HelpBox(seamApplyReason, HelpBoxMessageType.Warning));
            var apply = TsugimelessStyles.ConfirmButton(L.T("この仕上がりを適用する", "Apply this result"), ApplySeam, "seam-step4");
            apply.SetEnabled(TsugimelessLicense.Active && ready && seamBake?.Valid == true && !seamApplied && seamPreviewReason == null); body.Add(apply);
            if (!string.IsNullOrEmpty(seamApplyPath))
            {
                body.Add(TsugimelessStyles.EqualRow(
                    TsugimelessStyles.SmallButton(L.T("作った画像を見る", "Show generated image"), () => EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<Texture2D>(seamApplyPath)), "seam-show-image"),
                    TsugimelessStyles.SmallButton(L.T("材質を見る", "Show material"), () => { var material = SeamMaterial(false); if (material) { Selection.activeObject = material; EditorGUIUtility.PingObject(material); } }, "seam-show-material")));
            }
            body.Add(TsugimelessStyles.ColoredButton(L.T("あとから戻す", "Restore a previous result"),
                () => Navigate(WorkflowPage.History), "open-history"));
            if (seamApplied) body.Add(TsugimelessStyles.ColoredButton(L.T("範囲を調整し直す", "Adjust the range again"), () => { RetrySeamColors(); GoSeamStep(SeamStep.Range); }, "seam-again"));
        }
    }
}
