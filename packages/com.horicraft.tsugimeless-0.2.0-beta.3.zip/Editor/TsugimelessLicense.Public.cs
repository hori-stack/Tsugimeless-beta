// 本人が登録した公開鍵。秘密鍵ではありません。
namespace HoriCraft.Tsugimeless.Editor {
    internal static partial class TsugimelessLicense {
        static partial void GetPublicKey(ref string modulus, ref string exponent) {
            modulus = "0PsLGjIwh/Desxmrn3S+l/K0sr42mb6sS37RCpcxi9+zjSz77NTew9Q7FzIRLccLEjhv5nTnHFIOfE1v1oDR9avD5EDhKQks3EL9DH8+DAwDWqYsvXH+FMzFMdGEd4Wp+HhiuWg0U8ajI4WpHEfCqWJbzG5EgR5ciLYBeqg150QdU4k7KLcyvomAY14YVyir/ucNjZs1hRNa+Zyl8rl5qG5LrFX3Tx92Igg4JsrCcRjCKfC1wgFVorpowWl116qkGK/Z9nPHy6MEjFW7PySaeHT3u1hQnbs6jjoj16v2fn0h3jG/xWWkN2y1t3iHBl+TtbpkwzIzRctDJ7I7gdZK+vHvc+ZkCwb+RHuGUM80BgBr28ULr+uhRDxu9/pKDOdxPzFZEzVEqVLZiHzECOVcMjcMZ6uOyG6sJsdYESulCAQp+B2W/fRnEx3ptaIY76bQgJiqFR4tcIWsnpTO5dlFMzagFx3oaw99gwTC8fKdgKIFTMyKWZ4QuJyxER+XeCoJ";
            exponent = "AQAB";
        }
    }
}