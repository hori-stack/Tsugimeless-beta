using System.Collections.Generic;
namespace HoriCraft.Tsugimeless.Editor
{
    internal static partial class LocTable
    {
        static partial void AddFlatteningEntries(Dictionary<string, string[]> t)
        {
            t["この設定はまだ1枚にまとめられません（{0}）。"] = new[] { "暂时无法将此设置合并为一张图像（{0}）。", "이 설정은 아직 한 장으로 합칠 수 없습니다（{0}）." };
        }
    }
}
