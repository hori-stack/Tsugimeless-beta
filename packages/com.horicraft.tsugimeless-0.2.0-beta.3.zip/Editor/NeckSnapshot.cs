using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    internal sealed class NeckSurface
    {
        internal Vector3[] positions, normals;
        internal Vector2[] uv;
        internal int[] triangles;
        internal int[] triangleSlots;
        internal int[] triangleIds;
        internal NeckExcludedFace[] excluded = Array.Empty<NeckExcludedFace>();
    }
    internal sealed class NeckExcludedFace { internal int slot, triangle; internal int[] vertices; internal Vector3 center; }
    internal sealed class NeckSnapshot
    {
        internal NeckSurface face, body;
        internal Vector3 chest, neck, head;
        internal string stamp;
        internal static bool Finite(float x) => !float.IsNaN(x) && !float.IsInfinity(x);
        internal static bool Finite(Vector3 p) => Finite(p.x) && Finite(p.y) && Finite(p.z);
        internal static bool TryCreate(NeckTargets targets, out NeckSnapshot snapshot, out NeckIssue issue)
            => TryCreate(targets, out snapshot, out issue, out _);
        internal static bool TryCreate(NeckTargets targets, out NeckSnapshot snapshot, out NeckIssue issue, out string detail)
        {
            snapshot = null; issue = NeckIssue.Targets; detail = "";
            if (targets == null || !targets.Valid(out issue)) return false;
            if (EditorApplication.isPlayingOrWillChangePlaymode || AnimationMode.InAnimationMode()) { issue = NeckIssue.Animation; return false; }
            if (!TryBones(targets, out var chest, out var neck, out var head)) { issue = NeckIssue.Bones; return false; }
            if (!Finite(chest.position) || !Finite(neck.position) || !Finite(head.position) || Vector3.Distance(chest.position, head.position) < .01f) { issue = NeckIssue.BonePose; return false; }
            var acquired = new Dictionary<Renderer, Mesh>();
            try
            {
                foreach (var renderer in new[] { targets.Face, targets.Body }.Distinct())
                {
                    for (var t = renderer.transform; t != null; t = t.parent)
                        if (t.localScale.x <= 0 || t.localScale.y <= 0 || t.localScale.z <= 0) { issue = NeckIssue.Scale; return false; }
                    var matrix = renderer.localToWorldMatrix;
                    if (!Finite(matrix.determinant) || Mathf.Abs(matrix.determinant) < 1e-12f) { issue = NeckIssue.Scale; return false; }
                    if (renderer is SkinnedMeshRenderer skin)
                    {
                        if (!ValidateSkinBones(skin, targets.Root.transform, out issue, out detail)) return false;
                        foreach (var bone in skin.bones)
                            for (var t = bone; t != null; t = t.parent)
                                if (t.localScale.x <= 0 || t.localScale.y <= 0 || t.localScale.z <= 0) { issue = NeckIssue.Scale; return false; }
                        var baked = new Mesh { hideFlags = HideFlags.HideAndDontSave };
                        acquired.Add(renderer, baked); skin.BakeMesh(baked, false);
                    }
                    else acquired.Add(renderer, NeckTargets.MeshOf(renderer));
                }
                var result = new NeckSnapshot { chest = chest.position, neck = neck.position, head = head.position };
                result.face = Capture(targets.Face, targets.FaceSlots, acquired[targets.Face]);
                result.body = Capture(targets.Body, targets.BodySlots, acquired[targets.Body]);
                result.stamp = Signature(targets);
                snapshot = result; issue = NeckIssue.None; return true;
            }
            catch (Exception e) when (e is UnityException || e is ArgumentException || e is InvalidOperationException || e is IndexOutOfRangeException)
            { issue = NeckIssue.Geometry; detail = e.Message; return false; }
            finally
            {
                foreach (var pair in acquired)
                    if (pair.Key is SkinnedMeshRenderer && pair.Value != null) UnityEngine.Object.DestroyImmediate(pair.Value);
            }
        }
        internal static bool ValidateSkinBones(SkinnedMeshRenderer skin, Transform root, out NeckIssue issue, out string detail)
        {
            issue = NeckIssue.BoneWeights; detail = skin != null ? skin.name : "missing renderer";
            if (skin == null || root == null || skin.sharedMesh == null) return false;
            var mesh = skin.sharedMesh; var bones = skin.bones;
            if (bones.Length == 0) { issue = NeckIssue.MissingBone; return false; }
            // Keep rejecting references to other avatars, even when currently unweighted.
            if (bones.Any(b => b != null && !b.IsChildOf(root))) { issue = NeckIssue.OutsideBones; return false; }
            // Both arrays alias mesh-owned storage. Never dispose or retain these views.
            var counts = mesh.GetBonesPerVertex(); var weights = mesh.GetAllBoneWeights();
            if (counts.Length != mesh.vertexCount || counts.Length == 0) { detail += ": missing per-vertex weights"; return false; }
            int cursor = 0; var poses = mesh.bindposes;
            for (int vertex = 0; vertex < counts.Length; vertex++)
            {
                float total = 0;
                for (int i = 0; i < counts[vertex]; i++)
                {
                    if (cursor >= weights.Length) { detail += ": weight count mismatch"; return false; }
                    var weight = weights[cursor++];
                    if (!Finite(weight.weight) || weight.weight < 0) { detail += ": invalid weight at vertex " + vertex; return false; }
                    if (weight.weight == 0) continue;
                    int index = weight.boneIndex;
                    if (index < 0 || index >= bones.Length || index >= poses.Length)
                    { detail += ": invalid bone index at vertex " + vertex; return false; }
                    if (bones[index] == null) { issue = NeckIssue.MissingBone; detail += ": vertex " + vertex + ", bone " + index; return false; }
                    for (int e = 0; e < 16; e++)
                        if (!Finite(poses[index][e])) { detail += ": invalid bind pose at bone " + index; return false; }
                    total += weight.weight;
                }
                if (!Finite(total) || total <= 0) { detail += ": no usable weights at vertex " + vertex; return false; }
            }
            if (cursor != weights.Length) { detail += ": weight count mismatch"; return false; }
            // Null entries are safe only after proving that no positive weight uses them.
            issue = NeckIssue.None; detail = ""; return true;
        }
        internal static NeckSurface Capture(Renderer renderer, int[] slots, Mesh mesh)
        {
            var points = mesh.vertices; var normals = mesh.normals;
            if (points.Length == 0 || normals.Length != points.Length) throw new InvalidOperationException("Missing positions/normals");
            // BakeMesh(false) expresses skinned output relative to position/rotation,
            // without undoing Transform scale. Applying scale here again doubles it.
            // Static MeshRenderer vertices remain ordinary object-local coordinates.
            var matrix = renderer is SkinnedMeshRenderer
                ? Matrix4x4.TRS(renderer.transform.position, renderer.transform.rotation, Vector3.one)
                : renderer.localToWorldMatrix;
            var normalMatrix = matrix.inverse.transpose;
            for (int i = 0; i < points.Length; i++)
            {
                points[i] = matrix.MultiplyPoint3x4(points[i]); normals[i] = normalMatrix.MultiplyVector(normals[i]).normalized;
                if (!Finite(points[i]) || !Finite(normals[i])) throw new InvalidOperationException("Nonfinite mesh");
            }
            var triangles = new List<int>(); var triangleSlots = new List<int>(); var triangleIds = new List<int>(); var excluded = new List<NeckExcludedFace>();
            foreach (int slot in slots.OrderBy(s => s))
            {
                var indices = mesh.GetTriangles(slot);
                if (indices.Any(i => i < 0 || i >= points.Length)) throw new InvalidOperationException("Invalid skin indices");
                for (int i = 0; i < indices.Length; i += 3)
                {
                    int a = indices[i], b = indices[i + 1], c = indices[i + 2];
                    if (Vector3.Cross(points[b] - points[a], points[c] - points[a]).sqrMagnitude < 1e-18f)
                    {
                        excluded.Add(new NeckExcludedFace { slot = slot, triangle = i / 3, vertices = new[] { a, b, c }, center = (points[a] + points[b] + points[c]) / 3 });
                        continue;
                    }
                    triangles.AddRange(new[] { a, b, c }); triangleSlots.Add(slot); triangleIds.Add(i / 3);
                }
            }
            if (triangles.Any(i => i < 0 || i >= points.Length || normals[i].sqrMagnitude < .5f)) throw new InvalidOperationException("Invalid skin geometry");
            if (triangles.Count == 0) throw new InvalidOperationException("No usable skin triangles: " + renderer.name);
            return new NeckSurface { positions = points, normals = normals, uv = mesh.uv, triangles = triangles.ToArray(), triangleSlots = triangleSlots.ToArray(), triangleIds = triangleIds.ToArray(), excluded = excluded.ToArray() };
        }
        internal static bool TryBones(NeckTargets targets, out Transform chest, out Transform neck, out Transform head)
        {
            chest = neck = head = null;
            if (targets?.Root == null) return false;
            var root = targets.Root.transform;
            var animators = root.GetComponentsInChildren<Animator>(true).Where(a => a.avatar != null && a.avatar.isHuman && a.avatar.isValid).ToArray();
            if (animators.Length != 1) return false;
            var human = animators[0].avatar.humanDescription.human;
            var hipsNames = human.Where(b => b.humanName == "Hips").Select(b => b.boneName).ToArray();
            if (hipsNames.Length != 1) return false;
            var used = new[] { targets.Face, targets.Body }.OfType<SkinnedMeshRenderer>().SelectMany(r => r.bones).Where(b => b != null).ToArray();
            var hips = root.GetComponentsInChildren<Transform>(true).Where(t => t.name == hipsNames[0] && (used.Length == 0 || used.Any(b => b == t || b.IsChildOf(t)))).ToArray();
            if (hips.Length != 1) return false;
            var found = new List<Transform>();
            foreach (string role in new[] { "Chest", "Neck", "Head" })
            {
                var names = human.Where(b => b.humanName == role).Select(b => b.boneName).ToArray();
                if (names.Length != 1) return false;
                var matches = hips[0].GetComponentsInChildren<Transform>(true).Where(t => t.name == names[0]).ToArray();
                if (matches.Length != 1) return false;
                found.Add(matches[0]);
            }
            chest = found[0]; neck = found[1]; head = found[2]; return true;
        }
        internal static string Signature(NeckTargets targets)
        {
            if (targets == null || !targets.Valid(out _)) return "invalid";
            using (var memory = new System.IO.MemoryStream())
            using (var writer = new System.IO.BinaryWriter(memory))
            {
                writer.Write("current-neck-v5"); writer.Write(targets.Root.GetInstanceID()); writer.Write(targets.DefinitionId ?? "");
                writer.Write((int)targets.Binding); writer.Write(targets.Confirmed);
                writer.Write((int)QualitySettings.skinWeights);
                bool bonesFound = TryBones(targets, out var chest, out var neck, out var head); writer.Write(bonesFound);
                if (bonesFound) { Append(writer, chest.localToWorldMatrix); Append(writer, neck.localToWorldMatrix); Append(writer, head.localToWorldMatrix); }
                var catalog = UnityEditor.AssetDatabase.LoadAssetAtPath<TextAsset>(AvatarDefinitions.CatalogPath);
                writer.Write(catalog != null ? Hash128.Compute(catalog.text).ToString() : "missing-catalog");
                foreach (var renderer in new[] { targets.Face, targets.Body }.Distinct())
                {
                    var mesh = NeckTargets.MeshOf(renderer); writer.Write(renderer.GetInstanceID()); writer.Write(mesh.GetInstanceID());
                    Append(writer, renderer.localToWorldMatrix);
                    var asset = AssetDatabase.GetAssetPath(mesh);
                    writer.Write(!string.IsNullOrEmpty(asset) ? AssetDatabase.GetAssetDependencyHash(asset).ToString() : "transient");
                    foreach (var v in mesh.vertices) Append(writer, v);
                    foreach (var n in mesh.normals) Append(writer, n);
                    foreach (var uv in mesh.uv) { writer.Write(uv.x); writer.Write(uv.y); }
                    foreach (var b in mesh.bindposes) Append(writer, b);
                    AppendBoneWeights(writer, mesh);
                    writer.Write(EditorUtility.GetDirtyCount(mesh)); writer.Write(mesh.blendShapeCount);
                    if (string.IsNullOrEmpty(asset) && mesh.blendShapeCount > 0)
                    {
                        var v = new Vector3[mesh.vertexCount]; var n = new Vector3[v.Length]; var t = new Vector3[v.Length];
                        for (int shape = 0; shape < mesh.blendShapeCount; shape++)
                        {
                            writer.Write(mesh.GetBlendShapeName(shape)); writer.Write(mesh.GetBlendShapeFrameCount(shape));
                            for (int frame = 0; frame < mesh.GetBlendShapeFrameCount(shape); frame++)
                            {
                                writer.Write(mesh.GetBlendShapeFrameWeight(shape, frame)); mesh.GetBlendShapeFrameVertices(shape, frame, v, n, t);
                                for (int i = 0; i < v.Length; i++) { Append(writer, v[i]); Append(writer, n[i]); Append(writer, t[i]); }
                            }
                        }
                    }
                    if (renderer is SkinnedMeshRenderer skin)
                    {
                        writer.Write((int)skin.quality); writer.Write(skin.rootBone != null ? skin.rootBone.GetInstanceID() : 0);
                        if (skin.rootBone != null) Append(writer, skin.rootBone.localToWorldMatrix);
                        foreach (var bone in skin.bones) { writer.Write(bone != null ? bone.GetInstanceID() : 0); if (bone != null) Append(writer, bone.localToWorldMatrix); }
                        for (int i = 0; i < mesh.blendShapeCount; i++) writer.Write(skin.GetBlendShapeWeight(i));
                    }
                    foreach (var m in renderer.sharedMaterials) writer.Write(m != null ? m.GetInstanceID() : 0);
                }
                foreach (bool face in new[] { true, false })
                {
                    var mesh = NeckTargets.MeshOf(face ? targets.Face : targets.Body);
                    var slots = face ? targets.FaceSlots : targets.BodySlots; writer.Write(slots.Length);
                    foreach (int slot in slots) { writer.Write(slot); var indices = mesh.GetIndices(slot); writer.Write(indices.Length); foreach (int i in indices) writer.Write(i); }
                }
                writer.Flush();
                using (var hash = System.Security.Cryptography.SHA256.Create()) return Convert.ToBase64String(hash.ComputeHash(memory.GetBuffer(), 0, (int)memory.Length));
            }
        }
        internal static void AppendBoneWeights(System.IO.BinaryWriter writer, Mesh mesh)
        {
            var counts = mesh.GetBonesPerVertex(); var weights = mesh.GetAllBoneWeights();
            writer.Write(counts.Length); foreach (var count in counts) writer.Write(count);
            writer.Write(weights.Length); foreach (var weight in weights) { writer.Write(weight.boneIndex); writer.Write(weight.weight); }
        }
        private static void Append(System.IO.BinaryWriter writer, Vector3 p) { writer.Write(p.x); writer.Write(p.y); writer.Write(p.z); }
        private static void Append(System.IO.BinaryWriter writer, Matrix4x4 m) { for (int i = 0; i < 16; i++) writer.Write(m[i]); }
    }
}
