using System;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace HoriCraft.Tsugimeless.Editor
{
    // Offline verification only. This assembly contains no signing key or fallback token.
    internal static class TsugimelessLicenseCodec
    {
        internal const string Prefix = "TSG1", Product = "com.horicraft.tsugimeless";
        internal enum Result { Valid, NotConfigured, Invalid, Expired }
        internal static Result Verify(string token, string modulus, string exponent, DateTime today)
        {
            if (string.IsNullOrEmpty(modulus) || string.IsNullOrEmpty(exponent)) return Result.NotConfigured;
            if (string.IsNullOrWhiteSpace(token) || token.Length > 8192) return Result.Invalid;
            try
            {
                var parts = token.Trim().Split('.');
                if (parts.Length != 3 || parts[0] != Prefix) return Result.Invalid;
                byte[] payload = Convert.FromBase64String(parts[1]), signature = Convert.FromBase64String(parts[2]);
                byte[] n = Convert.FromBase64String(modulus), e = Convert.FromBase64String(exponent);
                if (n.Length < 256 || n.Length > 512 || signature.Length != n.Length || e.Length == 0 || e.Length > 8) return Result.Invalid;
                using (var rsa = RSA.Create())
                {
                    rsa.ImportParameters(new RSAParameters { Modulus = n, Exponent = e });
                    if (!rsa.VerifyData(payload, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1)) return Result.Invalid;
                }
                var fields = new UTF8Encoding(false, true).GetString(payload).Split('\n');
                if (fields.Length != 5 || fields[0] != Prefix || fields[1] != Product || fields[2] != "full"
                    || !Guid.TryParseExact(fields[3], "N", out _)) return Result.Invalid;
                if (fields[4].Length == 0) return Result.Valid;
                if (!DateTime.TryParseExact(fields[4], "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var until)) return Result.Invalid;
                return today.Date <= until.Date ? Result.Valid : Result.Expired;
            }
            catch (Exception e) when (e is FormatException || e is ArgumentException || e is CryptographicException)
            { return Result.Invalid; }
        }
    }
}
