using System.Collections.Generic;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    /// <summary>2 点で決まる 1 本の線（統合版の GradientParams を、首に要る分だけに削ったもの）。</summary>
    internal struct GradientLine
    {
        /// <summary>0% の端。</summary>
        internal Vector3 start;

        /// <summary>100% の端。</summary>
        internal Vector3 end;

        /// <summary>裏返す（start が 100%、end が 0%）。</summary>
        internal bool reverse;

        /// <summary>両端の丸め（0〜1）。</summary>
        internal float softness;

        /// <summary>始めと終わりが同じ場所＝向きが決まらない。</summary>
        internal bool IsDegenerate => (end - start).sqrMagnitude <= 1e-12f;
    }

    /// <summary>
    /// グラデーションの領域を作る。統合版 MaterialPon（feature/seam-v1 Editor/Recolor/GradientMaskBuilder.cs）からの移植で、
    /// UI を持たないのでテストから直接呼べる。
    ///
    /// 考え方は 1 行で言える。<b>頂点が「始めから終わりのどのあたりか」を 3D で測り、
    /// その値を三角形ごとに UV 空間へ写す。</b>
    ///
    /// 3D で測るので、<b>UV が別の島に分かれていても継ぎ目でつながる</b>。
    /// UV 空間で線を引くやり方だと、UV 上で離れている前後の島の境目で色が急に変わる。
    ///
    /// 統合版との違い: 端から先の扱いは「端で止める」だけ（くり返し・往復は首では使わない）。
    /// 対象を集める CollectSubsets は統合版の部位管理に依存するので持ち込んでいない。
    /// </summary>
    internal static class GradientMaskBuilder
    {
        /// <summary>測る相手ひとつ（形・その形を測る空間へ移す行列・いくつ目のまとまりか）。</summary>
        internal readonly struct MeshSubset
        {
            public readonly Mesh mesh;

            /// <summary>この形の座標を、線と同じ空間へ移す行列。</summary>
            public readonly Matrix4x4 toLocal;

            /// <summary>いくつ目のまとまりか。負なら全部。</summary>
            public readonly int subMesh;

            public MeshSubset(Mesh mesh, Matrix4x4 toLocal, int subMesh)
            {
                this.mesh = mesh;
                this.toLocal = toLocal;
                this.subMesh = subMesh;
            }
        }

        // ── 1 点ぶんの計算（ここだけで向きが決まる） ──────────────────

        /// <summary>
        /// この場所が「始めから終わりのどのあたりか」を 0〜1 で返す。
        ///
        /// 手順は 3 つ。
        ///  1. 始め→終わりの線へ落とした位置を出す（線の長さで割るので 0〜1 になる）
        ///  2. 端から先は端で止める
        ///  3. 「反転」なら裏返す／「両端の丸め」の分だけ、まっすぐな変化をなだらかな変化へ寄せる
        ///
        /// 始めと終わりが同じ場所のときは、どちらへ向かうか決められないので 0 を返す
        /// （＝何も起きない）。0 で割って NaN を撒くより、静かに何もしない方がよい。
        /// </summary>
        public static float ProjectT(Vector3 point, Vector3 start, Vector3 end, GradientLine gradient)
        {
            var axis = end - start;
            float lengthSq = axis.sqrMagnitude;
            if (lengthSq <= 1e-12f) return 0f;   // 始めと終わりが同じ場所

            float t = Vector3.Dot(point - start, axis) / lengthSq;
            t = Continue(t);
            if (gradient.reverse) t = 1f - t;
            return Soften(t, gradient.softness);
        }

        /// <summary>端から先の扱い（首では「端で止める」だけ）。</summary>
        private static float Continue(float t) => Mathf.Clamp01(t);

        /// <summary>
        /// 両端の丸め。まっすぐな変化と、両端がなだらかな変化を混ぜる。
        /// どちらも増える一方なので、混ぜても順番は入れ替わらない（＝縞にならない）。
        /// </summary>
        private static float Soften(float t, float softness)
        {
            float amount = Mathf.Clamp01(softness);
            if (amount <= 0f) return t;

            float smooth = t * t * (3f - 2f * t);
            return Mathf.Lerp(t, smooth, amount);
        }

        // ── 領域の画像 ────────────────────────────────────────────────

        /// <summary>
        /// グラデーションの領域を作る。作れなければ null。
        /// 返る画像は呼び出し側が使い終わったら DestroyImmediate すること。
        /// </summary>
        public static Texture2D Create(IReadOnlyList<MeshSubset> subsets, GradientLine gradient,
                                       int width, int height, bool showProgress = false)
        {
            if (subsets == null || subsets.Count == 0) return null;

            // 向きが決まっていないときは、全体が 0（＝何も起きない）の画像を作っても
            // 意味がないので、作らずに返す。呼び出し側は補正を飛ばす
            if (gradient.IsDegenerate) return null;

            var weighted = new List<UvMaskRasterizer.WeightedSubset>();

            // 同じ形は 1 回だけ測る
            var valueCache = new Dictionary<Mesh, float[]>();

            foreach (var subset in subsets)
            {
                if (subset.mesh == null) continue;

                if (!valueCache.TryGetValue(subset.mesh, out var values))
                {
                    values = BuildVertexValues(subset.mesh, subset.toLocal, gradient);
                    valueCache[subset.mesh] = values;
                }
                if (values == null) continue;

                weighted.Add(new UvMaskRasterizer.WeightedSubset(
                    subset.mesh, subset.subMesh, values));
            }

            return UvMaskRasterizer.CreateWeighted(weighted, width, height, showProgress);
        }

        /// <summary>頂点ごとの「どのあたりか」を出す。頂点が無ければ null。</summary>
        public static float[] BuildVertexValues(Mesh mesh, Matrix4x4 toLocal, GradientLine gradient)
        {
            if (mesh == null) return null;

            var vertices = mesh.vertices;
            if (vertices == null || vertices.Length == 0) return null;

            var values = new float[vertices.Length];
            for (int i = 0; i < vertices.Length; i++)
            {
                values[i] = ProjectT(toLocal.MultiplyPoint3x4(vertices[i]),
                                     gradient.start, gradient.end, gradient);
            }
            return values;
        }
    }
}
