using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    /// <summary>
    /// 「どこを、どれくらい補正するか」の画像を、<b>頂点ごとの値</b>から作る。
    /// 統合版 MaterialPon（feature/seam-v1 Editor/Recolor/UvMaskRasterizer.Weighted.cs）からの移植。
    /// 塗りつぶし（UvMaskRasterizer.cs）との違いは 1 つだけで、
    /// 画素に入るのが 0 か 1 かではなく、三角形の 3 頂点の値を混ぜた濃さになる。
    ///
    /// 首の帯はこれを使う。頂点の値は「その頂点が下の線から上の線のどのあたりか」
    /// （0〜1）で、それを三角形ごとに UV 空間へ写す。値は 3D の位置から決めているので、
    /// <b>UV が別の島に分かれていても、隣り合う場所どうしの濃さがつながる</b>。
    ///
    /// 気をつけていること:
    ///  - 「塗った／塗っていない」を濃さとは別に持つ。濃さだけで見分けると、
    ///    値が 0 の場所（＝下の端）が「塗っていない」と同じ扱いになり、
    ///    仕上げの広げで内側から食われる
    ///  - 外へ広げるときは<b>値を作らない</b>。いちばん近い画素の値をそのまま写す。
    ///    延長すると端の外側だけ 1 を超えたり負になったりして、境目に線が出る
    ///  - 倍率（RGB 版）は 0〜1 に収まらないので <paramref name="scale"/> で割ってから 8bit へ入れる。
    ///    読む側（NeckGoal のシェーダー）が同じ値で戻す
    /// </summary>
    internal static partial class UvMaskRasterizer
    {
        /// <summary>塗る相手ひとつ（頂点ごとの濃さつき）。</summary>
        internal readonly struct WeightedSubset
        {
            public readonly Mesh mesh;

            /// <summary>いくつ目のまとまりか。負なら全部。</summary>
            public readonly int subMesh;

            /// <summary>頂点ごとの濃さ（0〜1）。mesh の頂点数と同じ長さ。</summary>
            public readonly float[] values;

            public WeightedSubset(Mesh mesh, int subMesh, float[] values)
            {
                this.mesh = mesh;
                this.subMesh = subMesh;
                this.values = values;
            }
        }

        /// <summary>塗る相手ひとつ（頂点ごとの RGB 値つき）。</summary>
        internal readonly struct WeightedRgbSubset
        {
            public readonly Mesh mesh;
            public readonly int subMesh;

            /// <summary>頂点ごとの RGB 値。mesh の頂点数と同じ長さ。</summary>
            public readonly Vector3[] values;

            public WeightedRgbSubset(Mesh mesh, int subMesh, Vector3[] values)
            {
                this.mesh = mesh;
                this.subMesh = subMesh;
                this.values = values;
            }
        }

        // 塗る単位（Mesh を持たない呼び出しのために、UV・三角形・頂点値だけで表す）。
        private readonly struct Part<T>
        {
            internal readonly Vector2[] uv;
            internal readonly int[] triangles;
            internal readonly T[] values;
            internal Part(Vector2[] uv, int[] triangles, T[] values) { this.uv = uv; this.triangles = triangles; this.values = values; }
        }

        // ── 濃さ（R8） ────────────────────────────────────────────────

        /// <summary>
        /// 濃さの画像を作る。作れなければ null。
        /// 返る画像は R8（1 画素 1 バイト）で、使い終わったら呼び出し側が DestroyImmediate すること。
        /// </summary>
        public static Texture2D CreateWeighted(IReadOnlyList<WeightedSubset> subsets,
                                               int width, int height, bool showProgress = false)
        {
            if (subsets == null || subsets.Count == 0) return null;
            var parts = new List<Part<float>>();
            var uvCache = new Dictionary<Mesh, Vector2[]>();
            var done = new HashSet<long>();
            for (int i = 0; i < subsets.Count; i++)
            {
                var subset = subsets[i];
                Collect(subset.mesh, subset.subMesh, subset.values, uvCache, done, parts);
            }
            return CreateWeighted(parts, width, height, showProgress);
        }

        /// <summary>Mesh を持たない呼び出し（NeckSurface など）のための入口。</summary>
        public static Texture2D CreateWeighted(Vector2[] uv, int[] triangles, float[] values,
                                               int width, int height, bool showProgress = false)
        {
            if (uv == null || triangles == null || values == null) return null;
            return CreateWeighted(new List<Part<float>> { new Part<float>(uv, triangles, values) }, width, height, showProgress);
        }

        private static Texture2D CreateWeighted(List<Part<float>> parts, int width, int height, bool showProgress)
        {
            if (parts.Count == 0) return null;
            if (width <= 0 || height <= 0) return null;
            if (width > MaxSize || height > MaxSize) return null;

            var values = new byte[width * height];
            var covered = new byte[width * height];
            bool painted = false;

            try
            {
                for (int i = 0; i < parts.Count; i++)
                {
                    if (showProgress) Progress(i, parts.Count);
                    var part = parts[i];
                    for (int t = 0; t + 2 < part.triangles.Length; t += 3)
                    {
                        int i0 = part.triangles[t], i1 = part.triangles[t + 1], i2 = part.triangles[t + 2];
                        if (i0 >= part.uv.Length || i1 >= part.uv.Length || i2 >= part.uv.Length) continue;
                        if (i0 >= part.values.Length || i1 >= part.values.Length || i2 >= part.values.Length) continue;
                        if (RasterizeWeightedTriangle(
                                ToPixel(part.uv[i0], width, height),
                                ToPixel(part.uv[i1], width, height),
                                ToPixel(part.uv[i2], width, height),
                                part.values[i0], part.values[i1], part.values[i2],
                                values, covered, width, height))
                        {
                            painted = true;
                        }
                    }
                }
            }
            finally
            {
                if (showProgress) EditorUtility.ClearProgressBar();
            }

            if (!painted) return null;

            DilateWeighted(values, covered, width, height, DilatePixels, 1);
            return BuildTexture(values, width, height);
        }

        // ── 倍率（RGB24） ─────────────────────────────────────────────

        /// <summary>
        /// 頂点ごとの RGB 値から、線形の RGB24（使えなければ RGBA32）画像を作る。作れなければ null。
        /// <paramref name="scale"/> は 8bit へ入れる前に割る値（倍率は 1 を超えるため）。
        /// </summary>
        public static Texture2D CreateWeightedRgb(IReadOnlyList<WeightedRgbSubset> subsets,
                                                  int width, int height, float scale = 1f, bool showProgress = false)
        {
            if (subsets == null || subsets.Count == 0) return null;
            var parts = new List<Part<Vector3>>();
            var uvCache = new Dictionary<Mesh, Vector2[]>();
            var done = new HashSet<long>();
            for (int i = 0; i < subsets.Count; i++)
            {
                var subset = subsets[i];
                Collect(subset.mesh, subset.subMesh, subset.values, uvCache, done, parts);
            }
            return CreateWeightedRgb(parts, width, height, scale, showProgress);
        }

        /// <summary>Mesh を持たない呼び出し（NeckSurface など）のための入口。</summary>
        public static Texture2D CreateWeightedRgb(Vector2[] uv, int[] triangles, Vector3[] values,
                                                  int width, int height, float scale = 1f, bool showProgress = false)
        {
            if (uv == null || triangles == null || values == null) return null;
            return CreateWeightedRgb(new List<Part<Vector3>> { new Part<Vector3>(uv, triangles, values) }, width, height, scale, showProgress);
        }

        private static Texture2D CreateWeightedRgb(List<Part<Vector3>> parts, int width, int height, float scale, bool showProgress)
        {
            if (parts.Count == 0) return null;
            if (width <= 0 || height <= 0) return null;
            if (width > MaxSize || height > MaxSize) return null;
            if (!(scale > 0f) || float.IsInfinity(scale)) return null;

            // 画素ごとに配列を持たず、チャンネルごとに 1 本ずつ持つ（4K で 1600 万画素になるため）
            var red = new byte[width * height];
            var green = new byte[width * height];
            var blue = new byte[width * height];
            var covered = new byte[width * height];
            bool painted = false;

            try
            {
                for (int i = 0; i < parts.Count; i++)
                {
                    if (showProgress) Progress(i, parts.Count);
                    var part = parts[i];
                    for (int t = 0; t + 2 < part.triangles.Length; t += 3)
                    {
                        int i0 = part.triangles[t], i1 = part.triangles[t + 1], i2 = part.triangles[t + 2];
                        if (i0 >= part.uv.Length || i1 >= part.uv.Length || i2 >= part.uv.Length) continue;
                        if (i0 >= part.values.Length || i1 >= part.values.Length || i2 >= part.values.Length) continue;
                        if (RasterizeWeightedRgbTriangle(
                                ToPixel(part.uv[i0], width, height),
                                ToPixel(part.uv[i1], width, height),
                                ToPixel(part.uv[i2], width, height),
                                part.values[i0] / scale, part.values[i1] / scale, part.values[i2] / scale,
                                red, green, blue, covered, width, height))
                        {
                            painted = true;
                        }
                    }
                }
            }
            finally
            {
                if (showProgress) EditorUtility.ClearProgressBar();
            }

            if (!painted) return null;

            DilateWeighted(red, covered, width, height, DilatePixels, 3, green, blue);
            return BuildRgbTexture(red, green, blue, width, height);
        }

        // ── 塗る相手を集める ──────────────────────────────────────────

        private static void Collect<T>(Mesh mesh, int subMesh, T[] values,
                                       Dictionary<Mesh, Vector2[]> uvCache, HashSet<long> done, List<Part<T>> parts)
        {
            if (mesh == null || values == null) return;
            if (!uvCache.TryGetValue(mesh, out var uv))
            {
                uv = mesh.uv;
                uvCache[mesh] = uv;
            }
            if (uv == null || uv.Length == 0) return;   // UV が無いメッシュは塗れない

            int from = subMesh < 0 ? 0 : subMesh;
            int to = subMesh < 0 ? mesh.subMeshCount - 1 : subMesh;
            if (from < 0 || to >= mesh.subMeshCount) return;

            for (int sub = from; sub <= to; sub++)
            {
                if (mesh.GetTopology(sub) != MeshTopology.Triangles) continue;

                // 同じメッシュの同じまとまりを二度塗らない
                long id = ((long)mesh.GetInstanceID() << 16) ^ (uint)sub;
                if (!done.Add(id)) continue;

                parts.Add(new Part<T>(uv, mesh.GetTriangles(sub), values));
            }
        }

        // ── 三角形を塗る ──────────────────────────────────────────────

        /// <summary>
        /// 三角形 1 枚を、3 頂点の濃さを混ぜながら塗る。塗った画素があれば true。
        /// 混ぜ方は面積の比（重心座標）。塗りつぶしの側で内側かどうかを判定するのに
        /// 使っている 3 つの係数が、そのまま 3 頂点の重みになる。
        /// </summary>
        private static bool RasterizeWeightedTriangle(Vector2 a, Vector2 b, Vector2 c,
                                                      float va, float vb, float vc,
                                                      byte[] values, byte[] covered,
                                                      int width, int height)
        {
            bool painted = false;

            // 頂点の画素は無条件に塗る（細長い三角形が抜けないように）
            painted |= PlotWeighted(a, va, values, covered, width, height);
            painted |= PlotWeighted(b, vb, values, covered, width, height);
            painted |= PlotWeighted(c, vc, values, covered, width, height);

            float area = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
            if (Mathf.Abs(area) < 1e-9f) return painted;   // つぶれた三角形

            int minX = Mathf.FloorToInt(Mathf.Min(a.x, Mathf.Min(b.x, c.x)) - 0.5f);
            int maxX = Mathf.CeilToInt(Mathf.Max(a.x, Mathf.Max(b.x, c.x)) + 0.5f);
            int minY = Mathf.FloorToInt(Mathf.Min(a.y, Mathf.Min(b.y, c.y)) - 0.5f);
            int maxY = Mathf.CeilToInt(Mathf.Max(a.y, Mathf.Max(b.y, c.y)) + 0.5f);

            long cells = (long)(maxX - minX + 1) * (maxY - minY + 1);
            if (cells > (long)width * height * 4L) return painted;

            float inv = 1f / area;
            for (int y = minY; y <= maxY; y++)
            {
                float py = y + 0.5f;
                for (int x = minX; x <= maxX; x++)
                {
                    float px = x + 0.5f;

                    // w0 は頂点 c の、w1 は a の、w2 は b の重み（3 つ足すと 1）
                    float w0 = ((b.x - a.x) * (py - a.y) - (b.y - a.y) * (px - a.x)) * inv;
                    float w1 = ((c.x - b.x) * (py - b.y) - (c.y - b.y) * (px - b.x)) * inv;
                    float w2 = ((a.x - c.x) * (py - c.y) - (a.y - c.y) * (px - c.x)) * inv;
                    if (w0 < 0f || w1 < 0f || w2 < 0f) continue;

                    SetWeighted(values, covered, width, height, x, y, w1 * va + w2 * vb + w0 * vc);
                    painted = true;
                }
            }
            return painted;
        }

        private static bool RasterizeWeightedRgbTriangle(Vector2 a, Vector2 b, Vector2 c,
                                                         Vector3 va, Vector3 vb, Vector3 vc,
                                                         byte[] red, byte[] green, byte[] blue, byte[] covered,
                                                         int width, int height)
        {
            bool painted = false;

            painted |= PlotWeightedRgb(a, va, red, green, blue, covered, width, height);
            painted |= PlotWeightedRgb(b, vb, red, green, blue, covered, width, height);
            painted |= PlotWeightedRgb(c, vc, red, green, blue, covered, width, height);

            float area = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
            if (Mathf.Abs(area) < 1e-9f) return painted;

            int minX = Mathf.FloorToInt(Mathf.Min(a.x, Mathf.Min(b.x, c.x)) - 0.5f);
            int maxX = Mathf.CeilToInt(Mathf.Max(a.x, Mathf.Max(b.x, c.x)) + 0.5f);
            int minY = Mathf.FloorToInt(Mathf.Min(a.y, Mathf.Min(b.y, c.y)) - 0.5f);
            int maxY = Mathf.CeilToInt(Mathf.Max(a.y, Mathf.Max(b.y, c.y)) + 0.5f);

            long cells = (long)(maxX - minX + 1) * (maxY - minY + 1);
            if (cells > (long)width * height * 4L) return painted;

            float inv = 1f / area;
            for (int y = minY; y <= maxY; y++)
            {
                float py = y + 0.5f;
                for (int x = minX; x <= maxX; x++)
                {
                    float px = x + 0.5f;

                    float w0 = ((b.x - a.x) * (py - a.y) - (b.y - a.y) * (px - a.x)) * inv;
                    float w1 = ((c.x - b.x) * (py - b.y) - (c.y - b.y) * (px - b.x)) * inv;
                    float w2 = ((a.x - c.x) * (py - c.y) - (a.y - c.y) * (px - c.x)) * inv;
                    if (w0 < 0f || w1 < 0f || w2 < 0f) continue;

                    SetWeightedRgb(red, green, blue, covered, width, height, x, y, va * w1 + vb * w2 + vc * w0);
                    painted = true;
                }
            }
            return painted;
        }

        private static bool PlotWeighted(Vector2 point, float value, byte[] values, byte[] covered,
                                         int width, int height)
        {
            if (float.IsNaN(point.x) || float.IsNaN(point.y)) return false;
            SetWeighted(values, covered, width, height,
                        Mathf.FloorToInt(point.x), Mathf.FloorToInt(point.y), value);
            return true;
        }

        private static bool PlotWeightedRgb(Vector2 point, Vector3 value, byte[] red, byte[] green, byte[] blue,
                                            byte[] covered, int width, int height)
        {
            if (float.IsNaN(point.x) || float.IsNaN(point.y)) return false;
            SetWeightedRgb(red, green, blue, covered, width, height,
                           Mathf.FloorToInt(point.x), Mathf.FloorToInt(point.y), value);
            return true;
        }

        /// <summary>
        /// 画素に濃さを置く。0〜1 の外へ出た UV は折り返す（塗りつぶしと同じ）。
        /// すでに塗ってある画素には<b>濃い方を残す</b>。同じ画素へ表と裏の両方が来たときに、
        /// 描く順で結果が変わらないようにするため。
        /// </summary>
        private static void SetWeighted(byte[] values, byte[] covered, int width, int height,
                                        int x, int y, float value)
        {
            x = Wrap(x, width);
            y = Wrap(y, height);
            int index = y * width + x;

            byte level = Level(value);
            if (covered[index] == 0 || level > values[index]) values[index] = level;
            covered[index] = 255;
        }

        // RGB もチャンネルごとに濃い方を残す（R8 版と同じ規則）。
        private static void SetWeightedRgb(byte[] red, byte[] green, byte[] blue, byte[] covered,
                                           int width, int height, int x, int y, Vector3 value)
        {
            x = Wrap(x, width);
            y = Wrap(y, height);
            int index = y * width + x;

            byte r = Level(value.x), g = Level(value.y), b = Level(value.z);
            bool fresh = covered[index] == 0;
            if (fresh || r > red[index]) red[index] = r;
            if (fresh || g > green[index]) green[index] = g;
            if (fresh || b > blue[index]) blue[index] = b;
            covered[index] = 255;
        }

        private static byte Level(float value)
            => (byte)Mathf.Clamp(Mathf.RoundToInt(Mathf.Clamp01(value) * 255f), 0, 255);

        // ── 外へ広げる ────────────────────────────────────────────────

        /// <summary>
        /// 塗った場所を外へ n 画素ぶん広げる。
        /// 広げた先へ入れるのは<b>いちばん近い画素の値そのまま</b>で、
        /// 傾きを延長したりはしない。端では折り返さない（塗っていない反対側に色が付く）。
        /// </summary>
        internal static void DilateWeighted(byte[] values, byte[] covered,
                                            int width, int height, int pixels)
            => DilateWeighted(values, covered, width, height, pixels, 1);

        private static void DilateWeighted(byte[] values, byte[] covered, int width, int height, int pixels,
                                           int channels, byte[] second = null, byte[] third = null)
        {
            if (pixels <= 0) return;

            // 横 → 縦の 2 回に分けて広げる（4K では画素が 1600 万を超えるので、
            // 読む回数がそのまま待ち時間になる）
            var work = new byte[values.Length];
            var workSecond = channels > 1 ? new byte[values.Length] : null;
            var workThird = channels > 2 ? new byte[values.Length] : null;
            var workCovered = new byte[covered.Length];

            for (int step = 0; step < pixels; step++)
            {
                for (int y = 0; y < height; y++)
                {
                    int row = y * width;
                    for (int x = 0; x < width; x++)
                    {
                        int i = row + x;
                        int source = i;
                        byte mark = covered[i];
                        if (mark == 0 && x > 0 && covered[i - 1] != 0) { source = i - 1; mark = 255; }
                        if (mark == 0 && x < width - 1 && covered[i + 1] != 0) { source = i + 1; mark = 255; }
                        work[i] = values[source];
                        if (workSecond != null) workSecond[i] = second[source];
                        if (workThird != null) workThird[i] = third[source];
                        workCovered[i] = mark;
                    }
                }

                for (int y = 0; y < height; y++)
                {
                    int row = y * width;
                    for (int x = 0; x < width; x++)
                    {
                        int i = row + x;
                        int source = i;
                        byte mark = workCovered[i];
                        if (mark == 0 && y > 0 && workCovered[i - width] != 0) { source = i - width; mark = 255; }
                        if (mark == 0 && y < height - 1 && workCovered[i + width] != 0) { source = i + width; mark = 255; }
                        values[i] = work[source];
                        if (workSecond != null) second[i] = workSecond[source];
                        if (workThird != null) third[i] = workThird[source];
                        covered[i] = mark;
                    }
                }
            }
        }

        // ── 画像にする ────────────────────────────────────────────────

        private static Texture2D BuildRgbTexture(byte[] red, byte[] green, byte[] blue, int width, int height)
        {
            var format = SystemInfo.SupportsTextureFormat(TextureFormat.RGB24)
                ? TextureFormat.RGB24
                : TextureFormat.RGBA32;
            int stride = format == TextureFormat.RGB24 ? 3 : 4;

            var texture = new Texture2D(width, height, format, mipChain: false, linear: true)
            {
                name = "Tsugimeless Neck Gain",
                hideFlags = HideFlags.HideAndDontSave,
                wrapMode = TextureWrapMode.Clamp,
                filterMode = FilterMode.Bilinear,
            };

            var data = new byte[red.Length * stride];
            for (int i = 0; i < red.Length; i++)
            {
                int o = i * stride;
                data[o] = red[i];
                data[o + 1] = green[i];
                data[o + 2] = blue[i];
                if (stride == 4) data[o + 3] = 255;
            }
            texture.SetPixelData(data, 0);
            texture.Apply(updateMipmaps: false, makeNoLongerReadable: false);
            return texture;
        }
    }
}
