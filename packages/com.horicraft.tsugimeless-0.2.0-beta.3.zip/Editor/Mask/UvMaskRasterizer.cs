using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace HoriCraft.Tsugimeless.Editor
{
    /// <summary>
    /// 「どこを補正するか」の 1 チャンネル画像を、メッシュの三角形から作る。
    /// 統合版 MaterialPon（feature/seam-v1 Editor/Recolor/UvMaskRasterizer.cs）からの移植で、挙動は変えていない。
    ///
    /// やっていることは 1 つだけ。指定されたサブメッシュの三角形を、その UV0 が指す
    /// 画像の位置へ塗る。塗り終わったら 2px ぶん外へ広げる。
    /// 広げるのは、三角形の境目が画素の中心を外れて筋のように抜けるのを防ぐため。
    ///
    /// 気をつけていること:
    ///  - UV が 0〜1 の外にあるとき（タイリング）は、はみ出した先を折り返して塗る。
    ///    折り返すのは<b>画素を書くとき</b>で、頂点ごとに折り返すと 0〜1 をまたぐ三角形が裏返る
    ///  - 広げるときは折り返さない。左端の広がりが右端に回り込むと、
    ///    塗っていない側に色が付く
    /// </summary>
    internal static partial class UvMaskRasterizer
    {
        /// <summary>仕上げに外へ広げる幅（画素）。</summary>
        public const int DilatePixels = 2;

        /// <summary>作れる画像の大きさの上限（4K の 2 倍まで見ておく）。</summary>
        public const int MaxSize = 8192;

        // 「頂点ごとの値を持ち込んで塗る」入口は UvMaskRasterizer.Weighted.cs（partial）にある。

        /// <summary>塗る相手ひとつ（メッシュと、その中のいくつ目のまとまりか）。</summary>
        internal readonly struct Subset
        {
            public readonly Mesh mesh;
            public readonly int subMesh;

            public Subset(Mesh mesh, int subMesh)
            {
                this.mesh = mesh;
                this.subMesh = subMesh;
            }
        }

        /// <summary>
        /// 領域の画像を作る。作れなければ null。
        ///
        /// 返る画像は R8（1 画素 1 バイト）で、画面にもアセットにも残さない印を付けてある。
        /// 使い終わったら呼び出し側が DestroyImmediate すること。
        /// </summary>
        public static Texture2D Create(IReadOnlyList<Subset> subsets, int width, int height,
                                       bool showProgress = false)
        {
            if (subsets == null || subsets.Count == 0) return null;
            if (width <= 0 || height <= 0) return null;
            if (width > MaxSize || height > MaxSize) return null;

            var coverage = new byte[width * height];
            bool painted = false;

            try
            {
                var uvCache = new Dictionary<Mesh, Vector2[]>();
                var done = new HashSet<long>();

                for (int i = 0; i < subsets.Count; i++)
                {
                    var subset = subsets[i];
                    if (subset.mesh == null) continue;
                    if (subset.subMesh < 0 || subset.subMesh >= subset.mesh.subMeshCount) continue;
                    if (subset.mesh.GetTopology(subset.subMesh) != MeshTopology.Triangles) continue;

                    // 同じメッシュの同じまとまりを二度塗らない（複数の場所が同じ形を指すことがある）
                    long id = ((long)subset.mesh.GetInstanceID() << 16) ^ (uint)subset.subMesh;
                    if (!done.Add(id)) continue;

                    if (!uvCache.TryGetValue(subset.mesh, out var uv))
                    {
                        uv = subset.mesh.uv;
                        uvCache[subset.mesh] = uv;
                    }
                    if (uv == null || uv.Length == 0) continue;   // UV が無いメッシュは塗れない

                    if (showProgress) Progress(i, subsets.Count);

                    if (RasterizeTriangles(subset.mesh.GetTriangles(subset.subMesh), uv, coverage, width, height))
                    {
                        painted = true;
                    }
                }
            }
            finally
            {
                if (showProgress) EditorUtility.ClearProgressBar();
            }

            if (!painted) return null;

            Dilate(coverage, width, height, DilatePixels);
            return BuildTexture(coverage, width, height);
        }

        internal static void Progress(int index, int count)
        {
            EditorUtility.DisplayProgressBar(
                L.T("色を作る", "Making a color"),
                L.T("補正する場所を調べています…", "Working out the area to adjust…"),
                count <= 1 ? 0.5f : (float)index / count);
        }

        // ── 三角形を塗る ──────────────────────────────────────────────

        private static bool RasterizeTriangles(int[] triangles, Vector2[] uv,
                                               byte[] coverage, int width, int height)
        {
            if (triangles == null || triangles.Length < 3) return false;

            bool painted = false;
            for (int t = 0; t + 2 < triangles.Length; t += 3)
            {
                int i0 = triangles[t];
                int i1 = triangles[t + 1];
                int i2 = triangles[t + 2];
                if (i0 >= uv.Length || i1 >= uv.Length || i2 >= uv.Length) continue;

                if (RasterizeTriangle(
                        ToPixel(uv[i0], width, height),
                        ToPixel(uv[i1], width, height),
                        ToPixel(uv[i2], width, height),
                        coverage, width, height))
                {
                    painted = true;
                }
            }
            return painted;
        }

        private static Vector2 ToPixel(Vector2 uv, int width, int height)
            => new Vector2(uv.x * width, uv.y * height);

        /// <summary>
        /// 三角形 1 枚を塗る。塗った画素があれば true。
        ///
        /// 判定は画素の中心（x+0.5, y+0.5）が三角形の内側かどうか。
        /// これだけだと細長い三角形が丸ごと抜けるので、3 つの頂点が乗る画素は必ず塗る。
        /// </summary>
        private static bool RasterizeTriangle(Vector2 a, Vector2 b, Vector2 c,
                                              byte[] coverage, int width, int height)
        {
            bool painted = false;

            // 頂点の画素は無条件に塗る（細長い三角形が抜けないように）
            painted |= Plot(a, coverage, width, height);
            painted |= Plot(b, coverage, width, height);
            painted |= Plot(c, coverage, width, height);

            float area = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
            if (Mathf.Abs(area) < 1e-9f) return painted;   // つぶれた三角形

            int minX = Mathf.FloorToInt(Mathf.Min(a.x, Mathf.Min(b.x, c.x)) - 0.5f);
            int maxX = Mathf.CeilToInt(Mathf.Max(a.x, Mathf.Max(b.x, c.x)) + 0.5f);
            int minY = Mathf.FloorToInt(Mathf.Min(a.y, Mathf.Min(b.y, c.y)) - 0.5f);
            int maxY = Mathf.CeilToInt(Mathf.Max(a.y, Mathf.Max(b.y, c.y)) + 0.5f);

            // UV が壊れている（極端に外れている）三角形で固まらないための保険
            long cells = (long)(maxX - minX + 1) * (maxY - minY + 1);
            if (cells > (long)width * height * 4L) return painted;

            float inv = 1f / area;
            for (int y = minY; y <= maxY; y++)
            {
                float py = y + 0.5f;
                for (int x = minX; x <= maxX; x++)
                {
                    float px = x + 0.5f;

                    float w0 = ((b.x - a.x) * (py - a.y) - (b.y - a.y) * (px - a.x)) * inv;
                    float w1 = ((c.x - b.x) * (py - b.y) - (c.y - b.y) * (px - b.x)) * inv;
                    float w2 = ((a.x - c.x) * (py - c.y) - (a.y - c.y) * (px - c.x)) * inv;
                    if (w0 < 0f || w1 < 0f || w2 < 0f) continue;

                    Set(coverage, width, height, x, y);
                    painted = true;
                }
            }
            return painted;
        }

        private static bool Plot(Vector2 point, byte[] coverage, int width, int height)
        {
            if (float.IsNaN(point.x) || float.IsNaN(point.y)) return false;
            Set(coverage, width, height, Mathf.FloorToInt(point.x), Mathf.FloorToInt(point.y));
            return true;
        }

        /// <summary>画素を塗る。0〜1 の外へ出た UV は折り返す（タイリング）。</summary>
        private static void Set(byte[] coverage, int width, int height, int x, int y)
        {
            x = Wrap(x, width);
            y = Wrap(y, height);
            coverage[y * width + x] = 255;
        }

        private static int Wrap(int value, int size)
        {
            value %= size;
            return value < 0 ? value + size : value;
        }

        // ── 外へ広げる ────────────────────────────────────────────────

        /// <summary>
        /// 塗った場所を外へ n 画素ぶん広げる。
        /// 端では折り返さない。折り返すと、塗っていない反対側に色が付く。
        /// </summary>
        internal static void Dilate(byte[] coverage, int width, int height, int pixels)
        {
            if (pixels <= 0) return;

            // 横 → 縦の 2 回に分けて広げる。1 画素あたり 3 か所しか読まないので、
            // 8 方向をまとめて見るより速い（結果は 8 方向へ広げたのと同じ）。
            var work = new byte[coverage.Length];

            for (int step = 0; step < pixels; step++)
            {
                for (int y = 0; y < height; y++)
                {
                    int row = y * width;
                    for (int x = 0; x < width; x++)
                    {
                        byte value = coverage[row + x];
                        if (value == 0 && x > 0) value = coverage[row + x - 1];
                        if (value == 0 && x < width - 1) value = coverage[row + x + 1];
                        work[row + x] = value;
                    }
                }

                for (int y = 0; y < height; y++)
                {
                    int row = y * width;
                    for (int x = 0; x < width; x++)
                    {
                        byte value = work[row + x];
                        if (value == 0 && y > 0) value = work[row - width + x];
                        if (value == 0 && y < height - 1) value = work[row + width + x];
                        coverage[row + x] = value;
                    }
                }
            }
        }

        // ── 画像にする ────────────────────────────────────────────────

        private static Texture2D BuildTexture(byte[] coverage, int width, int height)
        {
            var format = SystemInfo.SupportsTextureFormat(TextureFormat.R8)
                ? TextureFormat.R8
                : TextureFormat.RGBA32;

            var texture = new Texture2D(width, height, format, mipChain: false, linear: true)
            {
                name = "Tsugimeless Neck Area",
                hideFlags = HideFlags.HideAndDontSave,
                wrapMode = TextureWrapMode.Clamp,
                filterMode = FilterMode.Bilinear,
            };

            if (format == TextureFormat.R8)
            {
                texture.SetPixelData(coverage, 0);
            }
            else
            {
                var rgba = new byte[coverage.Length * 4];
                for (int i = 0; i < coverage.Length; i++)
                {
                    byte v = coverage[i];
                    int o = i * 4;
                    rgba[o] = v;
                    rgba[o + 1] = v;
                    rgba[o + 2] = v;
                    rgba[o + 3] = v;
                }
                texture.SetPixelData(rgba, 0);
            }

            texture.Apply(updateMipmaps: false, makeNoLongerReadable: false);
            return texture;
        }
    }
}
