using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    public sealed partial class TsugimelessWindow
    {
        private readonly NeckDiagnosisSession diagnosis = new NeckDiagnosisSession();
        private readonly NeckMeasurementOverlay measurement = new NeckMeasurementOverlay();
        private bool diagnosisAfterNeck, faceReference = true, diagnosisDetailsOpen;
        private ProgressBar diagnosisProgress;
        internal NeckDiagnosis Diagnosis => diagnosis.Result;
        internal bool DiagnosisRunning => diagnosisAfterNeck || diagnosis.Running;
        internal bool FaceReference => faceReference;
        private void InitializeDiagnosis()
        {
            EditorApplication.update -= TickDiagnosis; EditorApplication.update += TickDiagnosis;
            EditorApplication.projectChanged -= DiagnosisAssetsChanged; EditorApplication.projectChanged += DiagnosisAssetsChanged;
        }
        private void DisposeDiagnosis()
        { EditorApplication.update -= TickDiagnosis; EditorApplication.projectChanged -= DiagnosisAssetsChanged; CancelDiagnosis(NeckDiagnosisState.Idle); }
        private void DiagnosisAssetsChanged() => diagnosis.InvalidateCheck();
        internal void CancelDiagnosis(NeckDiagnosisState state = NeckDiagnosisState.Cancelled)
        { diagnosisAfterNeck = false; diagnosis.Cancel(state); measurement.Hide(); diagnosisProgress = null; }
        internal void BeginDiagnosis()
        {
            CancelDiagnosis(NeckDiagnosisState.Idle); EnsureNeckTargets();
            if (neckTargets == null || !neckTargets.Confirmed || !neckTargets.Valid(out _) || playBlocked || AnimationMode.InAnimationMode()) { RenderBody(); return; }
            if (neckResult != null && neckResult.Candidate && neckResult.stamp == NeckSnapshot.Signature(neckTargets)) StartColorDiagnosis();
            else
            {
                BeginNeck();
                if (NeckRunning) diagnosisAfterNeck = true; else StartColorDiagnosis();
            }
            RenderBody();
        }
        private void StartColorDiagnosis()
        {
            diagnosisAfterNeck = false;
            diagnosis.Begin(neckTargets, neckResult, neckResult != null && !neckResult.Candidate ? NeckAnalysis.Reason(neckResult.issue) : NeckAnalysis.Reason(neckIssue));
        }
        internal void TickDiagnosis()
        {
            if (diagnosisAfterNeck && !NeckRunning) { StartColorDiagnosis(); if (page == WorkflowPage.Neck) RenderBody(); }
            if (diagnosis.Tick()) { measurement.Hide(); if (page == WorkflowPage.Neck) RenderBody(); }
            if (diagnosisProgress != null) diagnosisProgress.value = diagnosis.Progress;
        }
        internal void SetDiagnosisDirection(bool face) { faceReference = face; RenderBody(); }
        private VisualElement BuildDiagnosisRun()
        {
            var panel = new VisualElement();
            var run = TsugimelessStyles.ColoredButton(L.T("首の違いを調べる", "Examine neck differences"), BeginDiagnosis, "neck-diagnose", true);
            run.SetEnabled(neckTargets != null && neckTargets.Confirmed && neckTargets.Valid(out _) && !NeckRunning && !DiagnosisRunning && !playBlocked && !AnimationMode.InAnimationMode()); panel.Add(run);
            panel.Add(TsugimelessStyles.Note(L.T("首の場所と、色・設定・面の向きを読み取ります。アバターは変更しません。", "Reads the neck location, color, settings and surface orientation. The avatar stays unchanged.")));
            return panel;
        }
        private static void DiagnosisLine(VisualElement parent, string value) => parent.Add(TsugimelessStyles.Note(value));
        private static VisualElement DiagnosisCard(string title, string name)
        { var card = TsugimelessStyles.Card(); card.name = name; card.Add(TsugimelessStyles.Heading(title)); return card; }
        internal static VisualElement BuildDiagnosisSummary(NeckDiagnosis report)
        {
            var summary = new VisualElement { name = "diagnosis-summary" };
            var color = DiagnosisCard(L.T("肌色", "Skin color"), "diagnosis-color");
            DiagnosisLine(color, report.compared == 0
                ? L.T("肌色を比べられませんでした。", "Skin colors could not be compared.")
                : report.max.maxColorComponent > 1e-4f
                    ? L.T("調べた首の位置では、顔と体の肌色に差がありました。", "Face and body skin colors differed at the neck positions checked.")
                    : L.T("調べた首の位置では、顔と体の肌色に差は見つかりませんでした。", "No skin-color difference was found at the neck positions checked."));
            if (report.state == NeckDiagnosisState.Measured)
                DiagnosisLine(color, L.F("首の境目の{0}か所で、顔側と体側を比べました。", "Compared the face and body sides at {0} positions along the neck boundary.", report.compared));
            else if (report.compared > 0)
                DiagnosisLine(color, L.F("{0}か所のうち、比べられたのは{1}か所です。首全体を確認できた結果ではありません。", "Compared {1} of {0} positions. This does not confirm the whole neck.", report.points.Count, report.compared));
            if (report.state != NeckDiagnosisState.Measured)
                DiagnosisLine(color, !report.normalsMeasured
                    ? (!string.IsNullOrEmpty(report.geometryReason) ? report.geometryReason : L.T("首の場所を調べきれていません。顔・体の指定を確認して、もう一度調べてください。", "The neck location has not been fully examined. Check the face/body selection and try again."))
                    : L.T("色を読み取れない場所や、同じ場所に複数の色がある部分があります。理由は「詳しい測定結果」で確認できます。", "Some positions could not be read or had multiple colors. See Detailed measurements for the reasons."));
            if (report.ReferenceVersion)
                DiagnosisLine(color, L.T("このlilToonの版では、色の計算をまだ確認できていません。結果は参考として見てください。", "Color calculations have not been verified with this lilToon version. Treat these results as a reference."));
            DiagnosisLine(color, L.T("ここで比べるのは基本の肌色です。影・ツヤ・発光・透け方を含む、実際の見た目は別に確認が必要です。", "This compares base skin color. The actual appearance, including shadows, gloss, emission and transparency, still needs checking."));
            summary.Add(color);
            var settings = DiagnosisCard(L.T("影やツヤの設定", "Shadow and gloss settings"), "diagnosis-settings");
            DiagnosisLine(settings, report.ActiveDifferences > 0
                ? L.F("顔と体で、影やツヤなどの設定が{0}項目違います。", "Face and body differ in {0} settings such as shadows and gloss.", report.ActiveDifferences)
                : report.materials.Any(p => p.properties.Any(v => v.reason == null && !v.inactive))
                    ? L.T("比べられた設定では、顔と体に差はありませんでした。", "No differences were found in the settings that could be compared.")
                    : L.T("影やツヤの設定を比べられませんでした。", "Shadow and gloss settings could not be compared."));
            if (report.UnknownSettings > 0)
                DiagnosisLine(settings, L.F("比較できなかった設定も{0}項目あります。理由は「詳しい測定結果」で確認できます。", "Another {0} settings could not be compared. See Detailed measurements for the reasons.", report.UnknownSettings));
            if (report.materials.Any(p => p.Shared))
                DiagnosisLine(settings, L.T("顔と体の一部は、同じ材質を使っています。その部分の設定は共通です。", "Some face and body parts use the same material, so those settings are shared."));
            summary.Add(settings);
            var normals = DiagnosisCard(L.T("面の向き", "Surface orientation"), "diagnosis-normals");
            DiagnosisLine(normals, !report.normalsMeasured
                ? L.T("首の場所が確定していないため、面の向きを比べられませんでした。", "Surface orientations could not be compared because the neck location is not confirmed.")
                : report.normalMax == 0
                    ? L.T("調べた位置では、面の向きに差はありませんでした。", "Surface orientations did not differ at the positions checked.")
                    : L.T("調べた位置では、面の向きに数値上の差がありました。見た目への影響の大きさは、まだ分かりません。", "Surface orientations differed numerically at the positions checked. The effect on appearance is not yet known."));
            DiagnosisLine(normals, L.T("面の向きは、光の当たり方に関わります。凹凸を表す画像の影響は、まだ調べていません。", "Surface orientation affects how light falls on the skin. The effect of images that add surface detail has not been checked."));
            summary.Add(normals);
            return summary;
        }
        private void BuildDiagnosisPanel()
        {
            var report = diagnosis.Result;
            if (DiagnosisRunning)
            {
                diagnosisProgress = new ProgressBar { title = L.T("首の違いを読み取っています…", "Reading neck differences…"), lowValue = 0, highValue = 1, value = diagnosis.Progress };
                body.Add(diagnosisProgress);
                body.Add(TsugimelessStyles.ColoredButton(L.T("診断を中断する", "Cancel diagnosis"), () => { if (NeckRunning) CancelNeck(NeckIssue.Cancelled); CancelDiagnosis(); RenderBody(); }, "diagnosis-cancel"));
            }
            else if (report == null)
            {
                string text = diagnosis.State == NeckDiagnosisState.Stale ? L.T("入力が変わったため、結果を取り下げました。もう一度調べてください。", "The input changed, so the result was withdrawn. Run the diagnosis again.")
                    : diagnosis.State == NeckDiagnosisState.Cancelled ? L.T("診断を中断しました。途中の結果は使いません。", "Diagnosis cancelled. Partial results are not used.")
                    : L.T("まだ診断していません。「首の違いを調べる」から始めます。", "Not diagnosed yet. Start with Examine neck differences.");
                DiagnosisLine(body, text + (diagnosis.Error == null ? "" : "\n" + diagnosis.Error));
            }
            if (report != null && !DiagnosisRunning) body.Add(BuildDiagnosisSummary(report));
            body.Add(TsugimelessStyles.Heading(L.T("次に検討する直し方", "Ways to address the differences")));
            body.Add(new Label(L.T("どちらの肌に合わせる？", "Which skin should be the reference?")));
            var directions = new VisualElement { name = "blend-direction" }; directions.AddToClassList("tsg-tabs");
            directions.Add(TsugimelessStyles.ColoredButton(L.T("顔に体を合わせる", "Match body to face"), () => SetDiagnosisDirection(true), "direction-face", faceReference));
            directions.Add(TsugimelessStyles.ColoredButton(L.T("体に顔を合わせる", "Match face to body"), () => SetDiagnosisDirection(false), "direction-body", !faceReference)); body.Add(directions);
            var directionText = TsugimelessStyles.Note(faceReference ? L.T("顔をお手本にして、体を合わせる方向です。今は説明だけで、色や設定は変わりません。", "Use the face as the reference and adjust the body. This only changes the explanation; colors and settings stay unchanged.")
                : L.T("体をお手本にして、顔を合わせる方向です。今は説明だけで、色や設定は変わりません。", "Use the body as the reference and adjust the face. This only changes the explanation; colors and settings stay unchanged.")); directionText.name = "diagnosis-direction"; body.Add(directionText);
            if (report != null && !DiagnosisRunning)
            {
                if (report.compared > 0 && report.max.maxColorComponent > 1e-4f) DiagnosisLine(body, L.T("肌色をそろえる方法や、首の近くだけなじませる方法が候補です。", "Options include matching skin colors or blending only near the neck."));
                if (report.ActiveDifferences > 0) DiagnosisLine(body, L.T("影やツヤの設定をそろえる方法が候補です。これで境目が目立たなくなるかは、見た目を比べて確かめる必要があります。", "Matching shadow and gloss settings is an option. Compare the appearance to check whether it makes the boundary less visible."));
                if (report.state == NeckDiagnosisState.Measured && report.max.maxColorComponent <= 1e-4f && report.ActiveDifferences == 0 && report.UnknownSettings == 0 && report.materials.Count > 0)
                    DiagnosisLine(body, L.T("今回調べた範囲では、色や設定の差は見つかりませんでした。境目が見える場合は、照明や画像の細部なども調べる必要があります。", "No color or setting differences were found in the area checked. If the boundary is still visible, lighting and image details need further checking."));
                BuildDiagnosisDetails(report);
            }
            DiagnosisLine(body, L.T("今できるのは、違いを調べるところまでです。色を変えて比べる機能は準備中です。", "For now, this tool examines differences. Changing colors to compare the results is still in development."));
        }
        private static string Rgb(Color c) => $"({c.r:G6}, {c.g:G6}, {c.b:G6})";
        private void BuildDiagnosisDetails(NeckDiagnosis report)
        {
            var detail = new Foldout { text = L.T("詳しい測定結果", "Detailed measurements"), value = diagnosisDetailsOpen };
            detail.RegisterValueChangedCallback(e => { if (e.target == detail) diagnosisDetailsOpen = e.newValue; });
            DiagnosisLine(detail, L.F("対応点 {0}／両側を測定 {1}／一意に比較 {2}", "Corresponding points {0} / both sides sampled {1} / uniquely compared {2}", report.points.Count, report.sampled, report.compared));
            if (report.compared > 0) DiagnosisLine(detail, L.F("linear RGB絶対差：平均 {0}／最大 {1}", "Absolute linear RGB difference: mean {0} / maximum {1}", Rgb(report.mean), Rgb(report.max)));
            if (report.normalsMeasured) DiagnosisLine(detail, L.F("向きの差：平均 {0:G6}°／最大 {1:G6}°", "Orientation difference: mean {0:G6}° / maximum {1:G6}°", report.normalMean, report.normalMax));
            if (report.reason != null) DiagnosisLine(detail, report.reason);
            if (report.geometryReason != null) DiagnosisLine(detail, report.geometryReason);
            foreach (string reason in report.points.SelectMany(p => p.face.Concat(p.body)).Where(r => !r.measured).Select(r => r.reason).Where(r => r != null).Distinct()) DiagnosisLine(detail, reason);
            DiagnosisLine(detail, L.F("現在有効な設定差 {0}／比較できない項目 {1}", "Active setting differences {0} / unavailable properties {1}", report.ActiveDifferences, report.UnknownSettings));
            DiagnosisLine(detail, L.T("画像上の領域の重なりと、マスクへ安全に合成できるかは未検査です。", "UV-region overlap and safe composition with existing masks have not been tested."));
            DiagnosisLine(detail, NeckDiagnosis.Model + $"\n{report.elapsedMs} ms / {report.batches} batches / {report.peakBatchBytes} bytes (batch textures)");
            DiagnosisLine(detail, L.T("点の集計は面積平均や知覚色差ではありません。色見本はsRGB表示に変換し、表示範囲に収めています。数値は元のlinear値です。", "Point statistics are not area averages or perceptual differences. Swatches are converted to sRGB and clamped for display; numbers retain the linear values."));
            foreach (var material in report.reads.Values)
            {
                var images = new Foldout { text = material.source.name + " / " + material.shaderName + " / lilToon " + (material.version ?? "?") };
                foreach (var kv in material.values.Where(k => k.Value.type == UnityEngine.Rendering.ShaderPropertyType.Texture || k.Key == "_UseEmission" || k.Key == "_UseEmission2nd"))
                {
                    string toggle = NeckMaterialComparison.Toggle(kv.Key);
                    string active = toggle == null ? "" : !material.Number(toggle) ? " [" + L.T("状態不明", "State unknown") + "]" : material.N(toggle) == 0 ? " [" + L.T("現在は無効", "Currently disabled") + "]" : " [" + L.T("有効", "Enabled") + "]";
                    DiagnosisLine(images, kv.Key + " = " + kv.Value.Text + active);
                }
                detail.Add(images);
            }
            foreach (var pair in report.materials)
            {
                var values = new Foldout { text = L.F("顔[{0}] {1}／体[{2}] {3}：元値→参照値", "Face [{0}] {1} / body [{2}] {3}: target → reference", pair.faceSlot, pair.face.source.name, pair.bodySlot, pair.body.source.name) };
                foreach (var p in pair.properties)
                    DiagnosisLine(values, p.group + " / " + p.name + ": " + p.Proposal(faceReference) + (p.reason != null ? " [" + L.T("比較できません", "Cannot compare") + ": " + p.reason + "]" : p.inactive ? " [" + L.T("現在は無効", "Currently disabled") + "]" : p.different ? " [≠]" : " [=]"));
                detail.Add(values);
            }
            foreach (string shared in report.shared) DiagnosisLine(detail, shared);
            if (report.shared.Length == 0) DiagnosisLine(detail, L.T("このアバター内に他の利用先はありません。", "No other uses within this avatar."));
            foreach (var point in report.points)
            {
                string status = point.Unique ? L.T("比較できました", "Compared") : point.Complete ? L.T("この位置は参照色が複数", "Multiple reference colors at this position") : L.T("未測定の参照があります", "Some references were not measured");
                var samples = new Foldout { text = "#" + (point.index + 1) + " " + status };
                samples.Add(TsugimelessStyles.ColoredButton(L.T("この測定点を示す", "Show this measurement point"), () => measurement.Show(point.position), "diagnosis-point-" + point.index));
                foreach (bool face in new[] { true, false })
                {
                    var refs = face ? point.face : point.body;
                    if (refs.Count == 0) DiagnosisLine(samples, (face ? L.T("顔", "Face") : L.T("体", "Body")) + ": " + L.T("肌スロット内のUV参照を確認できません。", "No UV reference in the selected skin slots."));
                    foreach (var r in refs)
                    {
                        DiagnosisLine(samples, (face ? L.T("顔", "Face") : L.T("体", "Body")) + $" [{r.slot}] / triangle {r.triangle} / UV {r.uv.ToString("G6")} / {r.material.source.name}");
                        if (!r.measured) { DiagnosisLine(samples, L.T("測定できません", "Cannot measure") + ": " + r.reason); continue; }
                        SampleSwatch(samples, L.T("元の画像", "Source image"), r.raw); SampleSwatch(samples, L.T("色設定を通した値", "After color settings"), r.evaluated);
                    }
                }
                detail.Add(samples);
            }
            detail.Add(TsugimelessStyles.ColoredButton(L.T("測定点の印を隠す", "Hide measurement marks"), measurement.Hide, "diagnosis-hide-points")); body.Add(detail);
        }
        private void SampleSwatch(VisualElement parent, string label, Color color)
        {
            var row = new VisualElement(); row.style.flexDirection = FlexDirection.Row;
            var swatch = new VisualElement(); swatch.style.width = 24; swatch.style.height = 20; swatch.style.flexShrink = 0;
            var gamma = color.gamma; swatch.style.backgroundColor = new Color(Mathf.Clamp01(gamma.r), Mathf.Clamp01(gamma.g), Mathf.Clamp01(gamma.b), 1); row.Add(swatch);
            DiagnosisLine(row, label + " " + Rgb(color)); parent.Add(row);
        }
    }
}
