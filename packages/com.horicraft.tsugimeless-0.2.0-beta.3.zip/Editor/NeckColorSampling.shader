Shader "Hidden/HoriCraft/TsugimelessNeckSampling"
{
    Properties
    {
        _MainTex ("Source", 2D) = "white" {}
        // Match lilToon's gamma-authored Color properties, not Unity's [HDR] upload.
        _Color ("Multiplier", Color) = (1,1,1,1)
        _MainTexHSVG ("Tone", Vector) = (0,1,1,1)
        _MainColorAdjustMask ("Tone mask", 2D) = "white" {}
        _MainGradationTex ("Gradation", 2D) = "white" {}
        _MainGradationStrength ("Gradation strength", Float) = 0
        _Color2nd ("Layer 2 multiplier", Color) = (1,1,1,1)
        _Main2ndTex ("Layer 2", 2D) = "white" {}
        _Main2ndBlendMask ("Layer 2 mask", 2D) = "white" {}
        _Main2ndTexBlendMode ("Layer 2 blend", Float) = 0
        _Main2ndEnableLighting ("Layer 2 lighting", Float) = 1
        _UseMain2ndTex ("Use layer 2", Float) = 0
        _Color3rd ("Layer 3 multiplier", Color) = (1,1,1,1)
        _Main3rdTex ("Layer 3", 2D) = "white" {}
        _Main3rdBlendMask ("Layer 3 mask", 2D) = "white" {}
        _Main3rdTexBlendMode ("Layer 3 blend", Float) = 0
        _Main3rdEnableLighting ("Layer 3 lighting", Float) = 1
        _UseMain3rdTex ("Use layer 3", Float) = 0
        _SampleUvTex ("Sample coordinates", 2D) = "black" {}
    }
    CGINCLUDE
    #include "UnityCG.cginc"
    #include "NeckColorMath.hlsl"
    Texture2D _MainTex, _MainColorAdjustMask, _MainGradationTex;
    Texture2D _Main2ndTex, _Main2ndBlendMask, _Main3rdTex, _Main3rdBlendMask, _SampleUvTex;
    SamplerState sampler_MainTex;
    SamplerState seam_linear_clamp_sampler;
    float4 _Color, _Color2nd, _Color3rd, _MainTexHSVG, _SourceST, _Main2ndTex_ST, _Main3rdTex_ST;
    float _MainGradationStrength, _UseMain2ndTex, _UseMain3rdTex;
    float _Main2ndTexBlendMode, _Main3rdTexBlendMode, _Main2ndEnableLighting, _Main3rdEnableLighting;
    struct SeamContext { float mask; float4 layer2, layer3; };
    SeamContext Context(float2 uv)
    {
        SeamContext c;
        c.mask = _MainColorAdjustMask.SampleLevel(sampler_MainTex, uv, 0).r;
        float2 uv0 = (uv - _SourceST.zw) / _SourceST.xy;
        c.layer2 = _Color2nd * _Main2ndTex.SampleLevel(sampler_MainTex, uv0 * _Main2ndTex_ST.xy + _Main2ndTex_ST.zw, 0);
        c.layer3 = _Color3rd * _Main3rdTex.SampleLevel(sampler_MainTex, uv0 * _Main3rdTex_ST.xy + _Main3rdTex_ST.zw, 0);
        c.layer2.a *= _Main2ndBlendMask.SampleLevel(sampler_MainTex, uv, 0).r * _UseMain2ndTex;
        c.layer3.a *= _Main3rdBlendMask.SampleLevel(sampler_MainTex, uv, 0).r * _UseMain3rdTex;
        return c;
    }
    float3 Gradation(float3 color)
    {
        if (_MainGradationStrength == 0) return color;
        #ifndef UNITY_COLORSPACE_GAMMA
            color = SeamLinearToSRGB(color);
        #endif
        float3 mapped = float3(
            _MainGradationTex.SampleLevel(seam_linear_clamp_sampler, float2(color.r, .5), 0).r,
            _MainGradationTex.SampleLevel(seam_linear_clamp_sampler, float2(color.g, .5), 0).g,
            _MainGradationTex.SampleLevel(seam_linear_clamp_sampler, float2(color.b, .5), 0).b);
        #ifndef UNITY_COLORSPACE_GAMMA
            color = SeamSRGBToLinear(color);
            mapped = SeamSRGBToLinear(mapped);
        #endif
        return lerp(color, mapped, _MainGradationStrength);
    }
    float3 Evaluate(float3 input, SeamContext c)
    {
        float3 color = lerp(input, Gradation(SeamTone(input, _MainTexHSVG)), c.mask) * _Color.rgb;
        color = SeamBlend(color, c.layer2.rgb, c.layer2.a * _Main2ndEnableLighting, (int)_Main2ndTexBlendMode);
        color = SeamBlend(color, c.layer3.rgb, c.layer3.a * _Main3rdEnableLighting, (int)_Main3rdTexBlendMode);
        color = SeamBlend(color, c.layer2.rgb, c.layer2.a * (1-_Main2ndEnableLighting), (int)_Main2ndTexBlendMode);
        return SeamBlend(color, c.layer3.rgb, c.layer3.a * (1-_Main3rdEnableLighting), (int)_Main3rdTexBlendMode);
    }
    float4 Forward(v2f_img i) : SV_Target
    {
        uint pixel = (uint)i.pos.x;
        float2 uv0 = _SampleUvTex.Load(int3(pixel / 2, 0, 0)).xy;
        float2 uv = uv0 * _SourceST.xy + _SourceST.zw;
        float4 source = _MainTex.SampleLevel(sampler_MainTex, uv, 0);
        return pixel % 2 == 0 ? source : float4(Evaluate(source.rgb, Context(uv)), source.a * _Color.a);
    }
    ENDCG
    SubShader
    {
        Cull Off ZWrite Off ZTest Always
        Pass
        {
            CGPROGRAM
            #pragma target 4.5
            #pragma vertex vert_img
            #pragma fragment Forward
            ENDCG
        }
    }
    Fallback Off
}
