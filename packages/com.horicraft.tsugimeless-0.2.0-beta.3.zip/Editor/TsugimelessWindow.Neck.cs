using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    public sealed partial class TsugimelessWindow
    {
        private AvatarDefinitionFile neckCatalog;
        private NeckTargets neckTargets;
        private string neckDefinitionId = "", neckException;
        private NeckResult neckResult;
        private NeckIssue neckIssue;
        private IEnumerator<float> neckJob;
        private readonly NeckOverlay neckOverlay = new NeckOverlay();
        private readonly NeckViewController neckView = new NeckViewController();
        private float neckProgress;
        private double neckCheckAt;
        private string neckJobStamp;
        private bool neckManualOpen, neckDetailsOpen, neckUserHidden;
        private Label neckStatus;
        private HelpBox neckSourceNotice;
        private ProgressBar neckProgressBar;
        internal NeckTargets Targets => neckTargets;
        internal NeckResult Result => neckResult;
        internal bool NeckRunning => neckJob != null;

        private void InitializeNeck() { EditorApplication.update -= TickNeck; EditorApplication.update += TickNeck; }
        private void DisposeNeck() { EditorApplication.update -= TickNeck; CancelNeck(NeckIssue.None); neckView.Dispose(); }
        private void OnNeckTargetChanged()
        {
            if ((neckTargets != null && (neckTargets.Root == null || neckTargets.Root != context.Root))
                || (neckTargets == null && context.Root != null && page == WorkflowPage.Neck && body != null))
            {
                CancelNeck(NeckIssue.Stale); ResetSeam(); neckTargets = null; neckDefinitionId = "";
                if (body != null && page == WorkflowPage.Neck) RenderBody();
            }
        }
        private void EnsureNeckTargets()
        {
            var fresh = AvatarDefinitions.Load();
            bool changed = (fresh != null ? JsonUtility.ToJson(fresh) : "") != (neckCatalog != null ? JsonUtility.ToJson(neckCatalog) : "");
            neckCatalog = fresh;
            if (neckTargets != null && neckTargets.Binding == NeckBinding.Matched && string.IsNullOrEmpty(neckDefinitionId))
            {
                // Recheck the whole selection: a newly added duplicate must also invalidate
                // the automatic match. Manual choices are deliberately left alone.
                var current = new NeckTargets(context.Root, neckCatalog, "");
                if (changed || current.Binding != NeckBinding.Matched || current.DefinitionId != neckTargets.DefinitionId
                    || current.Face != neckTargets.Face || current.Body != neckTargets.Body
                    || !current.FaceSlots.SequenceEqual(neckTargets.FaceSlots) || !current.BodySlots.SequenceEqual(neckTargets.BodySlots))
                { CancelNeck(NeckIssue.Stale); ResetSeam(); neckTargets = current; }
            }
            else if (neckTargets != null && neckTargets.Binding == NeckBinding.Matched
                && (changed || !AvatarDefinitions.Matches(neckTargets.Face, neckTargets.Definition.face) || !AvatarDefinitions.Matches(neckTargets.Body, neckTargets.Definition.body)))
            {
                CancelNeck(NeckIssue.Stale); ResetSeam();
                neckTargets = new NeckTargets(context.Root, neckCatalog, neckDefinitionId);
            }
            if (neckTargets == null && context.Root != null) neckTargets = new NeckTargets(context.Root, neckCatalog, neckDefinitionId);
        }
        private VisualElement BuildNeckPanel()
        {
            EnsureNeckTargets(); var panel = new VisualElement { name = "neck-panel" };
            var names = new List<string> { L.T("一覧にない・分からない", "Not listed / unsure") };
            if (neckCatalog != null) names.AddRange(neckCatalog.avatars.Select(d => d.displayName));
            int index = neckCatalog?.avatars == null ? 0 : Array.FindIndex(neckCatalog.avatars, d => d.id == neckDefinitionId) + 1;
            var definition = new DropdownField(L.T("使用しているアバター", "Avatar definition"), names, Mathf.Max(0, index)) { name = "avatar-definition" };
            definition.SetEnabled(context.Root != null && neckCatalog != null && !NeckRunning);
            definition.RegisterValueChangedCallback(_ =>
            {
                CancelNeck(NeckIssue.None); int selected = definition.index;
                neckDefinitionId = selected > 0 ? neckCatalog.avatars[selected - 1].id : "";
                neckTargets = new NeckTargets(context.Root, neckCatalog, neckDefinitionId); RenderBody();
            });
            panel.Add(definition);
            panel.Add(TsugimelessStyles.Note(L.T("名前は用意した設定を選びます。首補正の対応済み一覧ではありません。", "Names select prepared definitions, not a list of supported seam corrections.")));
            string binding;
            switch (neckTargets?.Binding)
            {
                case NeckBinding.Matched: binding = L.T("顔・体と形の定義が一致しました。", "Face, body and geometry match the definition."); break;
                case NeckBinding.Mismatch: binding = L.T("形が定義と少し違います。顔・体と肌の欄を確認して採用できます。", "The shape differs from the definition. Review the face, body and skin slots before adopting the targets."); break;
                case NeckBinding.InvalidCatalog: binding = L.T("アバター設定を読めません。版やデータの内容を確認してください。", "Avatar definitions could not be read. Check the format version and data."); break;
                case NeckBinding.Manual: binding = L.T("今回指定した顔・体を使い、汎用検出で調べます。", "The specified face and body use generic detection for this session."); break;
                case NeckBinding.Ambiguous: binding = L.T("顔・体の候補が複数あります。手動で指定してください。", "Multiple face or body candidates remain. Specify them manually."); break;
                default: binding = L.T("骨の影響と名前からの候補です。顔・体と肌の欄を確認してください。", "Candidates use bone influence and names. Confirm face, body and skin slots."); break;
            }
            var info = new HelpBox(context.Root == null ? NoticeText(SelectionNotice.SelectAvatar) : binding, HelpBoxMessageType.Info);
            info.AddToClassList("tsg-help"); panel.Add(info);
            if (neckTargets != null)
            {
                var manual = new Foldout { text = L.T("顔・体の指定を確認する", "Review face and body targets"), value = neckManualOpen || !neckTargets.Confirmed };
                manual.RegisterValueChangedCallback(e => { if (e.target == manual) neckManualOpen = e.newValue; });
                manual.Add(BuildTargetEditor(true)); manual.Add(BuildTargetEditor(false));
                var confirm = TsugimelessStyles.ColoredButton(L.T("この顔・体を使う", "Use this face and body"), () =>
                { CancelNeck(NeckIssue.None); neckTargets.Confirm(); neckManualOpen = false; RenderBody(); }, "neck-confirm-targets");
                confirm.SetEnabled(neckTargets.Valid(out _) && !NeckRunning); manual.Add(confirm); panel.Add(manual);
            }
            panel.Add(BuildDiagnosisRun());
            var run = TsugimelessStyles.ColoredButton(L.T("首の境界を調べる", "Find the neck boundary"), BeginNeck, "neck-detect");
            run.SetEnabled(neckTargets != null && neckTargets.Confirmed && neckTargets.Valid(out _) && !NeckRunning && !playBlocked && !AnimationMode.InAnimationMode()); panel.Add(run);
            panel.Add(TsugimelessStyles.Note(L.T("現在の形を調べます。色や元のアバターは変更しません。", "Checks the current shape without changing colors or the source avatar.")));
            neckSourceNotice = new HelpBox(L.T("顔または体が非表示です。候補の線だけが見える場合があります。Unityでこのアバターを表示して、線の場所を確認してください。", "The face or body is hidden. You may see only the candidate lines. Make this avatar visible in Unity to check their location."), HelpBoxMessageType.Warning) { name = "neck-source-visibility" };
            panel.Add(neckSourceNotice); RefreshNeckSourceNotice();
            if (NeckRunning)
            {
                neckProgressBar = new ProgressBar { lowValue = 0, highValue = 1, value = neckProgress };
                panel.Add(neckProgressBar); panel.Add(TsugimelessStyles.ColoredButton(L.T("検出を中断する", "Cancel detection"), () => { CancelNeck(NeckIssue.Cancelled); RenderBody(); }, "neck-cancel"));
            }
            neckStatus = TsugimelessStyles.Note(NeckRunning ? L.T("首の境界を検出しています…", "Detecting the neck boundary…") : neckResult != null ? NeckAnalysis.Reason(neckResult.issue) : neckIssue != NeckIssue.None ? NeckAnalysis.Reason(neckIssue) : "");
            neckStatus.name = "neck-status"; panel.Add(neckStatus);
            if (neckResult != null && !NeckRunning)
            {
                panel.Add(TsugimelessStyles.Note(neckResult.Candidate
                    ? L.T("顔：水色の太線／体：黄色の破線。奥側は薄く、髪や服の上にも表示します。", "Face: thick cyan / body: dashed yellow. Far-side lines are fainter; lines also appear over hair and clothing.")
                    : neckResult.rejected.Count > 0
                        ? L.T("オレンジの点は、首の境目かもしれない場所です。まだ境目は確定していません。", "Orange points mark possible neck-boundary locations. The boundary is not confirmed yet.")
                        : L.T("首の場所を見つけられていないため、目印は表示していません。", "No marks are shown because the neck location has not been found.")));
                var focus = TsugimelessStyles.ColoredButton(L.T("首を見る", "Focus on the neck"), FocusNeck, "neck-focus", true);
                focus.SetEnabled(neckResult.Candidate || neckResult.rejected.Count > 0); panel.Add(focus);
                panel.Add(TsugimelessStyles.Note(L.T("向きと距離を自動で合わせます。別の向きも下のボタンで確認できます。", "Automatically sets the angle and distance. Use the buttons below for other views.")));
                var angles = new VisualElement(); angles.style.flexDirection = FlexDirection.Row; angles.style.flexWrap = Wrap.Wrap;
                AddNeckAngle(angles, L.T("正面", "Front"), NeckViewAngle.Front);
                AddNeckAngle(angles, L.T("左ななめ", "Front left"), NeckViewAngle.Left);
                AddNeckAngle(angles, L.T("右ななめ", "Front right"), NeckViewAngle.Right);
                AddNeckAngle(angles, L.T("後ろ", "Back"), NeckViewAngle.Back);
                angles.SetEnabled(neckResult.Candidate || neckResult.rejected.Count > 0); panel.Add(angles);
                panel.Add(TsugimelessStyles.ColoredButton(neckUserHidden ? L.T("境界を表示する", "Show boundary") : L.T("境界の表示を隠す", "Hide boundary"), () =>
                { SetNeckBoundaryVisible(neckUserHidden); }, "neck-hide"));
                if (neckResult.Candidate && !neckResult.HasUv) panel.Add(new HelpBox(L.T("線は確認できますが、画像補正に必要なUVが不足しています。", "The lines are available, but UV data required for image correction is missing."), HelpBoxMessageType.Warning));
                if (neckResult.excludedFace.Length + neckResult.excludedBody.Length > 0)
                    panel.Add(new HelpBox(L.F("計算から外した小さい面：顔 {0}／体 {1}（元メッシュは変更しません）", "Small faces excluded from calculation: face {0} / body {1} (source mesh unchanged)", neckResult.excludedFace.Length, neckResult.excludedBody.Length), HelpBoxMessageType.Warning));
            }
            if (neckView.CanRestore) panel.Add(TsugimelessStyles.ColoredButton(L.T("元の視点に戻す", "Restore previous view"), RestoreNeckView, "neck-restore-view"));
            if (neckResult != null || !string.IsNullOrEmpty(neckException))
            {
                var detail = new Foldout { text = L.T("詳細", "Details"), value = neckDetailsOpen };
                detail.RegisterValueChangedCallback(e => { if (e.target == detail) neckDetailsOpen = e.newValue; });
                if (neckResult != null && !NeckRunning)
                {
                    detail.Add(new Label(L.F("候補 {0} 点／輪 {1} 個／探索 {2:F1} mm", "Candidates: {0} / loops: {1} / search: {2:F1} mm", neckResult.initialCandidates, neckResult.loops.Count, neckResult.thresholdMm)));
                    if (neckResult.Candidate) detail.Add(new Label(L.F("法線角度：平均 {0:F1}°／最大 {1:F1}°（補正は行いません）", "Normal angle: mean {0:F1}° / max {1:F1}° (not corrected)", neckResult.meanNormalAngle, neckResult.maxNormalAngle)));
                    foreach (var trace in neckResult.traces) detail.Add(new Label(trace.ToString()));
                    if (neckResult.excludedFace.Length + neckResult.excludedBody.Length > 0)
                    {
                        var excluded = new Foldout { text = L.T("除外した面（先頭20件）", "Excluded faces (first 20)") };
                        foreach (bool face in new[] { true, false })
                            foreach (var value in (face ? neckResult.excludedFace : neckResult.excludedBody).Take(10))
                                excluded.Add(TsugimelessStyles.Note(L.F("{0}：材質欄 {1}・面 {2}・位置 {3}", "{0}: slot {1}, triangle {2}, position {3}", face ? L.T("顔", "Face") : L.T("体", "Body"), value.slot, value.triangle, value.center.ToString("F4"))));
                        detail.Add(excluded);
                    }
                    var shared = NeckAnalysis.SharedMaterials(neckTargets);
                    detail.Add(new Label(L.T("肌と同じ材質を使う場所（読み取りのみ）", "Other uses of skin materials (read only)")));
                    foreach (string use in shared) detail.Add(new Label(use));
                    if (shared.Length == 0) detail.Add(new Label(L.T("このアバター内に他の利用先はありません。", "No other uses within this avatar.")));
                }
                if (!string.IsNullOrEmpty(neckException)) detail.Add(new Label(neckException));
                panel.Add(detail);
            }
            return panel;
        }
        private void AddNeckAngle(VisualElement parent, string label, NeckViewAngle angle)
        {
            var button = TsugimelessStyles.ColoredButton(label, () => FocusNeck(angle), "neck-view-" + angle.ToString().ToLowerInvariant());
            button.style.flexGrow = 1; parent.Add(button);
        }
        internal void FocusNeck() => FocusNeck(NeckViewAngle.Oblique);
        internal void SetNeckBoundaryVisible(bool visible) { neckUserHidden = !visible; if (!visible) measurement.Hide(); UpdateNeckVisibility(); RenderBody(); }
        internal void RestoreNeckView() { neckView.Restore(); RenderBody(); }
        internal void FocusNeck(NeckViewAngle angle)
        {
            if (neckResult == null || NeckRunning) return;
            UpdateNeckVisibility(); if (neckResult == null) { RenderBody(); return; }
            neckUserHidden = false; UpdateNeckVisibility();
            if (neckView.Focus(neckResult, neckTargets, angle)) RenderBody();
        }
        private VisualElement BuildTargetEditor(bool face)
        {
            var container = new VisualElement(); var renderer = face ? neckTargets.Face : neckTargets.Body;
            var field = new ObjectField(face ? L.T("顔の描画部品", "Face renderer") : L.T("体の描画部品", "Body renderer"))
                { objectType = typeof(Renderer), allowSceneObjects = true, value = renderer };
            field.SetEnabled(!NeckRunning);
            field.RegisterValueChangedCallback(e =>
            {
                var candidate = e.newValue as Renderer;
                var slots = NeckTargets.SuggestedSlots(neckTargets.Root, candidate);
                if (!neckTargets.SetManual(face, candidate, slots)) { field.SetValueWithoutNotify(renderer); return; }
                CancelNeck(NeckIssue.None); ResetSeam(); field.schedule.Execute(RenderBody);
            });
            container.Add(field);
            if (renderer != null)
            {
                var selected = face ? neckTargets.FaceSlots : neckTargets.BodySlots;
                var mesh = NeckTargets.MeshOf(renderer);
                for (int i = 0; i < renderer.sharedMaterials.Length; i++)
                {
                    int slot = i; var mat = renderer.sharedMaterials[i];
                    var toggle = new Toggle("[" + i + "] " + (mat != null ? mat.name : "None")) { value = selected.Contains(slot) };
                    toggle.SetEnabled(!NeckRunning && mesh != null && i < mesh.subMeshCount && mat != null);
                    toggle.RegisterValueChangedCallback(e =>
                    {
                        var choices = (face ? neckTargets.FaceSlots : neckTargets.BodySlots).ToList();
                        if (e.newValue) choices.Add(slot); else choices.Remove(slot);
                        if (!neckTargets.SetManual(face, renderer, choices.Distinct().OrderBy(x => x).ToArray())) { toggle.SetValueWithoutNotify(!e.newValue); return; }
                        CancelNeck(NeckIssue.None); ResetSeam(); RenderBody();
                    });
                    container.Add(toggle);
                }
            }
            return container;
        }
        internal void BeginNeck()
        {
            CancelNeck(NeckIssue.None);
            EnsureNeckTargets();
            if (neckTargets == null || !neckTargets.Confirmed || !NeckSnapshot.TryCreate(neckTargets, out var snapshot, out neckIssue, out neckException)) { RenderBody(); return; }
            neckResult = new NeckResult { state = NeckState.Running }; neckJobStamp = snapshot.stamp; neckProgress = 0; neckUserHidden = false;
            // Old initial-pose thresholds remain historical data, not verified live-pose thresholds.
            neckJob = NeckDetection.Run(snapshot, neckResult).GetEnumerator();
            RenderBody();
        }
        internal void TickNeck()
        {
            if (page == WorkflowPage.Neck) RefreshNeckSourceNotice();
            if (neckJob == null && neckResult == null) return;
            try
            {
                if (EditorApplication.timeSinceStartup >= neckCheckAt)
                {
                    neckCheckAt = EditorApplication.timeSinceStartup + 1;
                    if (neckTargets?.Root != context.Root || playBlocked || AnimationMode.InAnimationMode()
                        || NeckSnapshot.Signature(neckTargets) != (neckJob != null ? neckJobStamp : neckResult.stamp))
                    { CancelNeck(NeckIssue.Stale); if (page == WorkflowPage.Neck) RenderBody(); return; }
                }
                if (neckJob == null) return;
                var watch = Stopwatch.StartNew();
                do
                {
                    if (!neckJob.MoveNext())
                    {
                        neckJob.Dispose(); neckJob = null;
                        if (NeckSnapshot.Signature(neckTargets) != neckJobStamp) { CancelNeck(NeckIssue.Stale); }
                        else UpdateNeckVisibility();
                        if (page == WorkflowPage.Neck) RenderBody(); return;
                    }
                    neckProgress = neckJob.Current;
                } while (watch.ElapsedMilliseconds < 12);
                if (neckProgressBar != null) neckProgressBar.value = neckProgress;
            }
            catch (Exception e)
            { CancelNeck(NeckIssue.Exception); neckException = e.Message; if (page == WorkflowPage.Neck) RenderBody(); }
        }
        private void RefreshNeckSourceNotice()
        {
            if (neckSourceNotice == null) return;
            bool Hidden(Renderer renderer) => renderer != null && (!renderer.gameObject.activeInHierarchy || !renderer.enabled
                || renderer.forceRenderingOff || UnityEditor.SceneVisibilityManager.instance.IsHidden(renderer.gameObject));
            var display = neckTargets != null && (Hidden(neckTargets.Face) || Hidden(neckTargets.Body)) ? DisplayStyle.Flex : DisplayStyle.None;
            if (neckSourceNotice.style.display.value != display) neckSourceNotice.style.display = display;
        }
        internal void CancelNeck(NeckIssue issue)
        {
            CancelDiagnosis(issue == NeckIssue.Stale ? NeckDiagnosisState.Stale : issue == NeckIssue.Cancelled ? NeckDiagnosisState.Cancelled : NeckDiagnosisState.Idle);
            neckJob?.Dispose(); neckJob = null; neckOverlay.Hide(); neckResult = null; neckIssue = issue;
            neckException = null; neckProgressBar = null;
        }
        private void UpdateNeckVisibility()
        {
            if (neckResult != null && !NeckRunning && (neckTargets?.Root != context.Root || NeckSnapshot.Signature(neckTargets) != neckResult.stamp))
            { CancelNeck(NeckIssue.Stale); return; }
            if (page == WorkflowPage.Neck && neckResult != null && !NeckRunning && !neckUserHidden) neckOverlay.Show(neckResult); else neckOverlay.Hide(); }
    }
}
