using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    /// <summary>
    /// 「ツギメを消す」ページ（D-N1）。本人が自分で消した実感を持てるよう、
    /// ①上の線 → ②下の線 → ③色の確認 → ④適用 を 1 ボタンずつ進める。全自動にしない。
    ///
    /// 守っていること:
    ///  - ④を押すまで、アバターの材質・画像・シーンを一切変更しない（③はプロパティブロックの仮表示だけ）
    ///  - 前の段が済むまで次のボタンは押せない
    ///  - 線の再計算は <see cref="NeckLinePlacer.Changed"/> の中で行わず、update で間引いて行う
    ///    （Changed の中で SetRings を呼ぶと呼び合いになるため）
    /// </summary>
    public sealed partial class TsugimelessWindow
    {
        /// <summary>線を動かしてから帯を作り直すまでの間隔（秒）。</summary>
        private const double SeamThrottle = .05;

        private readonly NeckLinePlacer placer = new NeckLinePlacer();
        private NeckSnapshot seamSnapshot;
        private NeckBandResult seamBand;
        private NeckReferenceResult seamReference;
        private NeckBakeResult seamBake;
        private NeckMeshRows seamRows;
        private Material seamComputedFrom;
        private Texture2D seamPreviewImage;
        private string seamColorStamp;
        private bool seamPreviewAfter;
        private bool seamAutoPending, seamAutoTried;
        private string seamAutoReason;
        [SerializeField] private bool seamUseRows;
        [SerializeField] private int seamUpperLine, seamLowerLine;
        [SerializeField] private string seamRowsStamp;
        private string seamSignature = "", seamBandReason, seamColorReason, seamApplyReason, seamApplyPath, seamPreviewReason;
        private bool seamApplied, seamStale, seamRecompute, seamRestoring, seamTargetsOpen;
        private double seamRecomputeAt, seamCheckAt;

        // 線はアバタールートのローカルで持つ。ドメイン再読み込みをまたいでも同じ場所を指す。
        [SerializeField] private Vector3 seamUpperLocal, seamLowerLocal;
        [SerializeField] private bool seamHasUpper, seamHasLower;

        /// <summary>MVP は体の最初の肌の材質欄だけを補正する。</summary>
        private int SeamBodySlot => neckTargets != null && neckTargets.BodySlots != null && neckTargets.BodySlots.Length > 0 ? neckTargets.BodySlots[0] : -1;
        private int SeamFaceSlot => neckTargets != null && neckTargets.FaceSlots != null && neckTargets.FaceSlots.Length > 0 ? neckTargets.FaceSlots[0] : -1;

        // ── 出入り口 ──────────────────────────────────────────────────

        private void InitializeSeam()
        {
            placer.Changed -= OnSeamLineChanged; placer.Changed += OnSeamLineChanged;
            EditorApplication.update -= TickSeam; EditorApplication.update += TickSeam;
            RestoreSeamLines();
        }

        private void DisposeSeam()
        {
            EditorApplication.update -= TickSeam;
            placer.Changed -= OnSeamLineChanged;
            placer.Dispose();
            DropSeamResults();
        }

        /// <summary>Seam ページから離れるとき。仮表示は消し、線は残す。</summary>
        private void OnSeamPageLeft()
        {
            HideSeamPreview();
            if (placer.Stage == NeckLineStage.PlacingUpper || placer.Stage == NeckLineStage.PlacingLower) placer.Cancel();
        }

        /// <summary>Play へ入るときと出るとき。線も結果も捨てる。</summary>
        private void ResetSeam()
        {
            seamStep = SeamStep.Range;
            seamFocusPending = false;
            seamRows = null; seamUseRows = false; seamAutoPending = seamAutoTried = false; seamAutoReason = null;
            seamRowsStamp = null; seamUpperLine = seamLowerLine = 0; seamAutoIssue = NeckIssue.None;
            placer.Clear();
            seamRecompute = false;
            DropSeamResults();
            seamHasUpper = seamHasLower = false; seamUpperLocal = seamLowerLocal = Vector3.zero;
            seamApplied = false; seamApplyPath = null; seamApplyReason = null; seamStale = false;
        }

        /// <summary>
        /// ドメイン再読み込みのあと、保存した 2 点を置き直す。
        /// NeckLinePlacer は点を外から入れ直す口を持たないので、当たり判定の差し替え口
        /// （<see cref="NeckLinePlacer.PickOverride"/>）にクリックを 1 回ずつ流して復元する。
        /// </summary>
        private void RestoreSeamLines()
        {
            if (!seamHasUpper || placer.HasUpper || context.Root == null || playBlocked) return;
            EnsureNeckTargets();
            if (!SeamTargetsReady()) return;
            if (seamUseRows) { AutoPlaceSeam(true); return; }
            var upper = context.Root.transform.TransformPoint(seamUpperLocal);
            var lower = context.Root.transform.TransformPoint(seamLowerLocal);
            if (!NeckSnapshot.Finite(upper) || !NeckSnapshot.Finite(lower)) return;
            seamRestoring = true;
            try
            {
                placer.Begin(context.Root, new[] { neckTargets.Face, neckTargets.Body });
                placer.PickOverride = _ => upper;
                placer.SimulateClick(new Ray(upper, Vector3.forward));
                if (seamHasLower)
                {
                    placer.PickOverride = _ => lower;
                    placer.SimulateClick(new Ray(lower, Vector3.forward));
                }
                placer.Cancel();
            }
            finally { placer.PickOverride = null; seamRestoring = false; }
            seamRecompute = true; seamRecomputeAt = EditorApplication.timeSinceStartup;
        }

        // ── 線が動いたとき ────────────────────────────────────────────

        private void OnSeamLineChanged()
        {
            if (seamRestoring) return;
            seamHasUpper = placer.HasUpper; seamHasLower = placer.HasLower;
            seamUpperLocal = placer.UpperLocal; seamLowerLocal = placer.LowerLocal;
            // ここでは印を付けるだけ。帯を作るのは update 側（呼び合いを避ける）。
            seamRecompute = true; seamRecomputeAt = EditorApplication.timeSinceStartup + SeamThrottle;
        }

        internal void TickSeam()
        {
            CheckLicenseChange();
            if (seamAutoPending && page == WorkflowPage.Seam)
            {
                seamAutoPending = false; AutoPlaceSeam(false);
                if (seamFocusPending && seamBand?.Valid == true) FocusSeam(NeckViewAngle.Front);
                seamFocusPending = false; RenderBody();
            }
            if (seamRecompute && EditorApplication.timeSinceStartup >= seamRecomputeAt)
            {
                seamRecompute = false;
                ComputeSeamBand();
                if (page == WorkflowPage.Seam) RenderBody();
            }
            // アバターが差し替わったら、前のアバターに付いていた線を持ち越さない。
            if (placer.Root != null && placer.Root != context.Root)
            {
                placer.Clear();
                seamHasUpper = seamHasLower = false; seamUpperLocal = seamLowerLocal = Vector3.zero;
                seamRecompute = false;
                DropSeamResults(); seamStale = true;
                if (page == WorkflowPage.Seam) RenderBody();
                return;
            }
            if (seamBand == null && seamBake == null) return;
            if (EditorApplication.timeSinceStartup < seamCheckAt) return;
            seamCheckAt = EditorApplication.timeSinceStartup + 1;
            if (neckTargets != null && neckTargets.Root == context.Root && !playBlocked
                && NeckSnapshot.Signature(neckTargets) == seamSignature)
            {
                if (seamBake != null && seamComputedFrom != null && ColorStamp(seamComputedFrom) != seamColorStamp)
                { DropSeamColor(); seamApplied = false; seamColorReason = L.T("材質や画像が変わりました。もう一度、色を計算してください。", "A material or image changed. Compute the colors again."); RenderBody(); }
                return;
            }
            DropSeamResults(); seamStale = true; seamApplied = false; seamApplyPath = null;
            if (page == WorkflowPage.Seam) RenderBody();
        }

        // ── 段ごとの処理 ──────────────────────────────────────────────

        private bool SeamTargetsReady()
            => !playBlocked && !EditorApplication.isPlayingOrWillChangePlaymode && context.Root != null
               && neckTargets != null && neckTargets.Root == context.Root && neckTargets.Confirmed
               && neckTargets.Valid(out _) && SeamBodySlot >= 0 && SeamFaceSlot >= 0;

        private Material SeamMaterial(bool face)
        {
            var renderer = face ? neckTargets?.Face : neckTargets?.Body;
            int slot = face ? SeamFaceSlot : SeamBodySlot;
            if (renderer == null || slot < 0) return null;
            var materials = renderer.sharedMaterials;
            return slot < materials.Length ? materials[slot] : null;
        }

        private void BeginSeamUpper()
        {
            if (!SeamTargetsReady()) return;
            seamAutoPending = false; seamAutoTried = true; seamUseRows = false; seamRows = null;
            if (placer.Root != context.Root) placer.Begin(context.Root, new[] { neckTargets.Face, neckTargets.Body });
            else placer.BeginUpper();
            RenderBody();
        }

        private void BeginSeamLower()
        {
            if (!SeamTargetsReady() || !placer.HasUpper) return;
            seamAutoPending = false; seamAutoTried = true; seamUseRows = false; seamRows = null;
            placer.BeginLower();
            RenderBody();
        }

        private void AutoPlaceSeam(bool restore)
        {
            if (!SeamTargetsReady()) return;
            int savedUpper = seamUpperLine, savedLower = seamLowerLine; string savedStamp = seamRowsStamp;
            seamAutoTried = true; seamAutoReason = null; seamAutoIssue = NeckIssue.None; seamUseRows = false; seamRows = null;
            DropSeamResults();
            if (!NeckSnapshot.TryCreate(neckTargets, out var snapshot, out var issue, out var detail))
            { seamAutoIssue = issue; seamAutoReason = NeckAnalysis.Reason(issue); return; }
            var detected = NeckDetection.Detect(snapshot);
            if (!detected.Candidate) { seamAutoIssue = detected.issue; seamAutoReason = NeckAnalysis.Reason(detected.issue); return; }
            var rows = NeckMeshRows.Build(snapshot, detected);
            if (!rows.Ready)
            {
                seamAutoReason = L.T("この形では上下の線を置けませんでした。顔・体の指定を確認してください。", "Upper and lower lines could not be placed on this shape. Check the face and body selection.") + " " + rows.Reason;
                return;
            }
            if (restore && (savedStamp != snapshot.stamp || !rows.CanUse(savedUpper, savedLower)))
            {
                seamAutoReason = L.T("形が変わりました。「上下の線を最初の位置へ戻す」で調べ直してください。", "The shape changed. Use Reset both lines to their initial positions to check again.");
                seamHasUpper = seamHasLower = false; return;
            }
            seamRows = rows; seamUseRows = true; seamRowsStamp = snapshot.stamp;
            seamUpperLine = restore ? savedUpper : rows.Upper; seamLowerLine = restore ? savedLower : rows.Lower;
            SetSeamRowPoints();
            ComputeSeamBand();
            seamRecompute = false;
        }

        private void SetSeamRowPoints()
        {
            var forward = context.Root.transform.forward;
            Vector3 Front(Vector3[] ring) => ring.OrderByDescending(p => Vector3.Dot(p, forward)).First();
            placer.SetLines(context.Root, new[] { neckTargets.Face, neckTargets.Body },
                Front(seamRows.Lines[seamUpperLine]), Front(seamRows.Lines[seamLowerLine]), false);
        }

        private void MoveSeamRow(bool upper, int direction)
        {
            if (!SeamTargetsReady() || !seamUseRows || seamRows == null) return;
            int up = seamUpperLine + (upper ? direction : 0), low = seamLowerLine + (upper ? 0 : direction);
            if (!seamRows.CanUse(up, low)) return;
            DropSeamColor(); seamApplied = false; seamApplyReason = null;
            seamUpperLine = up; seamLowerLine = low;
            SetSeamRowPoints(); ComputeSeamBand(); seamRecompute = false; RenderBody();
        }

        private void ComputeSeamBand()
        {
            DropSeamColor();
            seamBand = null; seamSnapshot = null; seamBandReason = null; seamStale = false;
            EnsureNeckTargets();
            if (!SeamTargetsReady() || !placer.HasUpper || !placer.HasLower) { placer.SetRings(null, null); return; }
            if (!NeckSnapshot.TryCreate(neckTargets, out var snapshot, out var issue, out var detail))
            {
                seamBandReason = NeckAnalysis.Reason(issue) + (string.IsNullOrEmpty(detail) ? "" : " " + detail);
                placer.SetRings(null, null); return;
            }
            seamSnapshot = snapshot; seamSignature = snapshot.stamp;
            if (seamUseRows && (seamRows == null || seamRowsStamp != snapshot.stamp || !seamRows.CanUse(seamUpperLine, seamLowerLine)))
            {
                seamBandReason = L.T("形が変わりました。「上下の線を最初の位置へ戻す」で調べ直してください。", "The shape changed. Use Reset both lines to their initial positions to check again.");
                placer.SetRings(null, null); return;
            }
            seamBand = NeckBand.Compute(snapshot, placer.UpperWorld, placer.LowerWorld, upperRing: seamUseRows ? seamRows.Lines[seamUpperLine] : null,
                lowerRing: seamUseRows ? seamRows.Lines[seamLowerLine] : null);
            placer.SetRings(seamBand.Valid ? seamBand.UpperRing : null, seamBand.Valid ? seamBand.LowerRing : null);
            if (!seamBand.Valid) seamBandReason = seamBand.Reason;
        }

        private void ComputeSeamColors()
        {
            DropSeamColor();
            if (!TsugimelessLicense.Require(out seamColorReason)) { RenderBody(); return; }
            if (seamSnapshot == null || seamBand == null || !seamBand.Valid || !SeamTargetsReady()) return;
            if (NeckSnapshot.Signature(neckTargets) != seamSignature) { DropSeamResults(); seamStale = true; RenderBody(); return; }
            var faceMaterial = SeamMaterial(true);
            if (!NeckHistoryStore.TryBaseline(context.Root, neckTargets.Body, SeamBodySlot, out var bodyMaterial, out var historyReason))
            { seamColorReason = historyReason; RenderBody(); return; }
            if (faceMaterial == null || bodyMaterial == null)
            {
                seamColorReason = L.T("顔か体の材質欄が空です。顔・体の指定を確認してください。", "The face or body material slot is empty. Check the face and body selection.");
                RenderBody(); return;
            }
            try
            {
                seamComputedFrom = bodyMaterial; seamColorStamp = ColorStamp(bodyMaterial);
                seamReference = NeckReference.Compute(seamSnapshot, seamBand,
                    LilToonMaterialRead.Capture(faceMaterial), LilToonMaterialRead.Capture(bodyMaterial));
                if (!seamReference.Valid) { seamColorReason = seamReference.Reason; RenderBody(); return; }
                seamBake = NeckLicensedActions.Bake(bodyMaterial, seamSnapshot, seamBand, seamReference);
                if (!seamBake.Valid) { seamColorReason = seamBake.Reason; RenderBody(); return; }
                ShowSeamPreview();
            }
            catch (Exception exception)
            {
                seamColorReason = L.F("色を計算できませんでした（{0}）。", "The colors could not be computed ({0}).", exception.Message);
            }
            RenderBody();
        }

        private void ShowSeamPreview()
        {
            seamPreviewReason = null;
            if (!TsugimelessLicense.Require(out seamPreviewReason)) { HideSeamPreview(); return; }
            if (seamBake == null || !seamBake.Valid || !SeamTargetsReady()) return;
            if (!ColorInputCurrent()) return;
            try
            {
                if (!seamPreviewImage) seamPreviewImage = NeckHistoryImage.Preview(seamBake.Candidate, seamComputedFrom.GetTexture(seamBake.TextureProperty) as Texture2D);
                if (!NeckPreview.ShowBaseline(neckTargets.Body, SeamBodySlot, seamComputedFrom, seamPreviewImage, out var reason, seamBake.TextureProperty)) seamPreviewReason = reason;
                else seamPreviewAfter = true;
            }
            catch (Exception e) { seamPreviewReason = NeckHistoryAssets.Reason(e); HideSeamPreview(); }
        }

        private void ToggleSeamPreview()
        {
            if (SeamPreviewShown()) HideSeamPreview(); else ShowSeamPreview();
            RenderBody();
        }

        private bool SeamPreviewShown()
            => NeckPreview.Active && neckTargets != null && NeckPreview.Target == neckTargets.Body && NeckPreview.Slot == SeamBodySlot;

        private void HideSeamPreview() { if (SeamPreviewShown()) NeckPreview.Hide(); }

        private void ApplySeam()
        {
            seamApplyReason = null;
            if (seamBake == null || !seamBake.Valid || !SeamTargetsReady() || !ColorInputCurrent()) return;
            NeckPreview.Hide();
            var result = NeckLicensedActions.Apply(context.Root, neckTargets.Body, SeamBodySlot, seamComputedFrom, seamBake,
                SeamMaterial(true), seamSignature, seamBand.UpperRing, seamBand.LowerRing);
            if (result.Ok) { seamApplied = true; seamApplyPath = result.PngPath; }
            else { seamApplied = false; seamApplyReason = result.Reason; }
            // 材質欄が変わると署名も変わる。形は変わっていないので、失効扱いにしない。
            seamSignature = NeckSnapshot.Signature(neckTargets);
            if (seamUseRows) seamRowsStamp = seamSignature;
            seamCheckAt = EditorApplication.timeSinceStartup + 1;
            RenderBody();
        }

        private void RestoreSeamMaterial()
        {
            if (neckTargets == null || SeamBodySlot < 0) return;
            RestoreHistory(null);
        }

        private void RestoreHistory(string entryId)
        {
            HideSeamPreview();
            if (NeckHistoryStore.Restore(context.Root, neckTargets.Body, SeamBodySlot, entryId, out var reason))
            { DropSeamColor(); seamApplied = false; seamApplyReason = reason; seamApplyPath = null; }
            else seamApplyReason = reason;
            seamSignature = NeckSnapshot.Signature(neckTargets);
            if (seamUseRows) seamRowsStamp = seamSignature;
            seamCheckAt = EditorApplication.timeSinceStartup + 1;
            RenderBody();
        }

        /// <summary>「もう一度」。焼き込みだけ捨てて、線と帯は残す。</summary>
        private void RetrySeamColors()
        {
            DropSeamColor();
            seamApplied = false; seamApplyPath = null; seamApplyReason = null;
            RenderBody();
        }

        /// <summary>「線を消してやり直す」。</summary>
        private void ClearSeamLines()
        {
            seamAutoPending = false; seamAutoTried = true; seamUseRows = false; seamRows = null; seamAutoReason = null; seamAutoIssue = NeckIssue.None;
            placer.Clear();
            DropSeamResults();
            seamHasUpper = seamHasLower = false; seamUpperLocal = seamLowerLocal = Vector3.zero;
            seamStale = false;
            RenderBody();
        }

        private void DropSeamResults()
        {
            DropSeamColor();
            seamBand = null; seamSnapshot = null; seamBandReason = null;
            placer.SetRings(null, null);
        }

        private void DropSeamColor()
        {
            HideSeamPreview();
            if (seamPreviewImage) DestroyImmediate(seamPreviewImage); seamPreviewImage = null;
            seamBake?.Dispose(); seamBake = null;
            seamReference = null; seamColorReason = null; seamPreviewReason = null;
            seamComputedFrom = null; seamColorStamp = null;
            seamPreviewAfter = false;
        }

        // ── 画面 ──────────────────────────────────────────────────────

        private void BuildLegacySeamPage()
        {
            EnsureNeckTargets();
            body.Add(TsugimelessStyles.Heading(L.T("ツギメを消す", "Remove the neck seam")));
            body.Add(TsugimelessStyles.Note(L.T("ボタンを上から順に押します。適用（④）まで、アバターの材質や画像は変わりません。", "Press the buttons from the top down. Nothing in the avatar's materials or images changes until step 4.")));
            bool ready = SeamTargetsReady();
            if (ready && !placer.HasUpper && !seamAutoTried) { seamAutoPending = true; seamAutoTried = true; }
            int slot = SeamBodySlot;
            if (ready && NeckApply.IsApplied(context.Root, neckTargets.Body, slot, out _)) seamApplied = true;
            if (seamStale) body.Add(new HelpBox(L.T("アバターが変わったため、②からやり直してください。", "The avatar changed. Start again from step 2."), HelpBoxMessageType.Warning));
            BuildSeamTargets(ready);
            var suggest = TsugimelessStyles.ColoredButton(L.T("線の候補を置く", "Place suggested lines"),
                () => { seamAutoPending = true; seamAutoReason = null; RenderBody(); }, "seam-suggest", !placer.HasUpper);
            suggest.SetEnabled(ready && !seamAutoPending); body.Add(suggest);
            if (seamAutoPending) body.Add(TsugimelessStyles.Note(L.T("顔との境目と、近くのメッシュの段を調べています…", "Finding the face boundary and nearby mesh rows…")));
            if (!string.IsNullOrEmpty(seamAutoReason)) body.Add(new HelpBox(seamAutoReason, HelpBoxMessageType.Warning));
            BuildSeamUpper(ready);
            BuildSeamLower(ready);
            BuildSeamColors(ready);
            BuildSeamApply(ready);
            var clear = TsugimelessStyles.ColoredButton(L.T("線を消してやり直す", "Clear the lines and start over"), ClearSeamLines, "seam-clear");
            clear.SetEnabled(placer.HasUpper || placer.HasLower);
            body.Add(clear);
        }

        private void BuildSeamTargets(bool ready)
        {
            var card = TsugimelessStyles.Card();
            card.Add(TsugimelessStyles.Heading(L.T("顔と体を決める", "Choose the face and body")));
            string status;
            if (context.Root == null) status = L.T("上の欄で、編集するアバターを選んでください。", "Select the avatar to edit in the field above.");
            else if (ready) status = "✓ " + L.F("顔 {0}／体 {1}", "Face {0} / body {1}", neckTargets.Face.name, neckTargets.Body.name);
            else status = L.T("顔と体を確かめて、「この顔・体を使う」を押してください。", "Check the face and body, then press Use this face and body.");
            card.Add(SeamStatus(status));
            if (neckTargets != null)
            {
                string binding;
                switch (neckTargets.Binding)
                {
                    case NeckBinding.Matched: binding = L.T("顔と体を自動で見つけました。次へ進めます。", "The face and body were matched automatically. You can continue."); break;
                    case NeckBinding.Manual: binding = neckTargets.Confirmed ? L.T("確認した顔と体を使います。", "Using the face and body you confirmed.") : ""; break;
                    case NeckBinding.Ambiguous: binding = L.T("候補が複数あり、自動で決められません。下の欄で顔・体と肌の材質を選んでください。", "Several candidates match. Choose the face, body and skin material slots below."); break;
                    case NeckBinding.InvalidCatalog: binding = L.T("登録設定を読めません。下の欄で顔・体と肌の材質を選べます。", "The registered definitions could not be read. You can choose the face, body and skin material slots below."); break;
                    default: binding = L.T("登録設定と一致しませんでした。下の欄で顔・体と肌の材質を確かめてください。", "No registered definition matched. Check the face, body and skin material slots below."); break;
                }
                if (!string.IsNullOrEmpty(binding)) card.Add(TsugimelessStyles.Note(binding));
                var fold = new Foldout { name = "seam-target-details", text = L.T("顔・体の指定を確認する", "Review face and body targets"), value = seamTargetsOpen || !neckTargets.Confirmed };
                fold.RegisterValueChangedCallback(e => { if (e.target == fold) seamTargetsOpen = e.newValue; });
                fold.Add(BuildTargetEditor(true)); fold.Add(BuildTargetEditor(false));
                var confirm = TsugimelessStyles.ColoredButton(L.T("この顔・体を使う", "Use this face and body"), () =>
                { neckTargets.Confirm(); seamTargetsOpen = false; DropSeamResults(); RestoreSeamLines(); seamRecompute = true; seamRecomputeAt = EditorApplication.timeSinceStartup; RenderBody(); }, "seam-confirm-targets");
                confirm.SetEnabled(neckTargets.Valid(out _) && !playBlocked);
                fold.Add(confirm); card.Add(fold);
            }
            else card.Add(new HelpBox(NoticeText(SelectionNotice.SelectAvatar), HelpBoxMessageType.Info));
            body.Add(card);
        }

        private void BuildSeamUpper(bool ready)
        {
            var card = TsugimelessStyles.Card();
            card.Add(TsugimelessStyles.Heading(seamUseRows ? L.T("① 上の線を確かめる", "1. Check the upper line") : L.T("① 上の線を置く", "1. Place the upper line")));
            card.Add(TsugimelessStyles.Note(seamUseRows
                ? L.T("水色の線が顔との境目にあるか確かめます。ここから顔の色へ合わせます。矢印で近くの段へ動かせます。", "Check that the cyan line is at the face boundary. Color matching starts here. Use the arrows to move to nearby rows.")
                : L.T("Scene Viewで、顔と体の境目（顔側）を1回クリックします。ここが100%（顔の色）になります。", "In the Scene view, click once on the face side of the boundary. That place becomes 100% (the face color).")));
            string status = placer.Stage == NeckLineStage.PlacingUpper ? placer.Hint
                : placer.HasUpper ? "✓ " + L.T("置きました", "Placed")
                : L.T("まだ置いていません。", "Not placed yet.");
            card.Add(SeamStatus(status));
            BuildSeamRowButtons(card, true, ready);
            var button = TsugimelessStyles.ColoredButton(seamUseRows ? L.T("クリックして置き直す", "Place again by clicking") : placer.HasUpper ? L.T("やり直す", "Place it again") : L.T("上の線を置く", "Place the upper line"),
                BeginSeamUpper, "seam-step1", !placer.HasUpper);
            button.SetEnabled(ready && placer.Stage != NeckLineStage.PlacingUpper);
            card.Add(button);
            body.Add(card);
        }

        private void BuildSeamLower(bool ready)
        {
            var card = TsugimelessStyles.Card();
            card.Add(TsugimelessStyles.Heading(seamUseRows ? L.T("② 下の線を確かめる", "2. Check the lower line") : L.T("② 下の線を置く", "2. Place the lower line")));
            card.Add(TsugimelessStyles.Note(seamUseRows
                ? L.T("黄色の線で元の体の色へ戻ります。下げると、なじませる範囲が広がります。", "The yellow line returns to the original body color. Moving it down widens the blend region.")
                : L.T("境目より少し下（体側）をクリックします。ここが0%（元の体の色）になります。", "Click a little below the boundary, on the body side. That place becomes 0% (the original body color).")));
            string status;
            if (placer.Stage == NeckLineStage.PlacingLower) status = placer.Hint;
            else if (!placer.HasLower) status = L.T("まだ置いていません。", "Not placed yet.");
            else if (seamBand != null && seamBand.Valid)
                status = "✓ " + (seamBand.FollowsMeshRows ? L.T("選んだ2本の線に沿って、首を一周する範囲を作りました。", "The region follows the two selected lines all the way around the neck.") : seamBand.Snapped
                    ? L.T("首の帯を作りました（全周・境目に吸着しました）", "The neck band is ready (all the way round, snapped to the boundary)")
                    : L.T("首の帯を作りました（全周・境目への吸着はありません）", "The neck band is ready (all the way round, without snapping to the boundary)"));
            else status = L.T("帯を計算しています…", "Computing the band…");
            card.Add(SeamStatus(status));
            BuildSeamRowButtons(card, false, ready);
            if (placer.HasLower && seamBandReason != null) card.Add(new HelpBox(seamBandReason, HelpBoxMessageType.Warning));
            if (!seamUseRows && seamBand != null && seamBand.Valid && !string.IsNullOrEmpty(seamBand.Summary)) card.Add(TsugimelessStyles.Note(seamBand.Summary));
            var button = TsugimelessStyles.ColoredButton(seamUseRows ? L.T("クリックして置き直す", "Place again by clicking") : placer.HasLower ? L.T("やり直す", "Place it again") : L.T("下の線を置く", "Place the lower line"),
                BeginSeamLower, "seam-step2", !placer.HasLower);
            button.SetEnabled(ready && placer.HasUpper && placer.Stage != NeckLineStage.PlacingLower);
            card.Add(button);
            body.Add(card);
        }

        private void BuildSeamRowButtons(VisualElement card, bool upper, bool ready)
        {
            if (!seamUseRows || seamRows == null) return;
            int selected = upper ? seamUpperLine : seamLowerLine;
            int meshRow = Array.IndexOf(seamRows.Rings.ToArray(), seamRows.Lines[selected]);
            card.Add(SeamStatus(meshRow < 0 ? L.T("顔との境目", "Face boundary")
                : L.F("メッシュの {0} 段目", "Mesh row {0}", meshRow + 1)));
            var row = TsugimelessStyles.EqualRow();
            foreach (int direction in new[] { -1, 1 })
            {
                var button = TsugimelessStyles.ColoredButton(direction < 0 ? L.T("↑ 一段上へ", "↑ One row up") : L.T("↓ 一段下へ", "↓ One row down"),
                    () => MoveSeamRow(upper, direction), "seam-" + (upper ? "upper" : "lower") + (direction < 0 ? "-up" : "-down"));
                button.style.flexGrow = 1; button.style.flexBasis = 0;
                button.SetEnabled(ready && seamRows.CanUse(seamUpperLine + (upper ? direction : 0), seamLowerLine + (upper ? 0 : direction)));
                row.Add(button);
            }
            card.Add(row);
        }

        private void BuildSeamColors(bool ready)
        {
            var card = TsugimelessStyles.Card();
            card.Add(TsugimelessStyles.Heading(L.T("③ 色を確かめる", "3. Check the colors")));
            card.Add(TsugimelessStyles.Note(L.T("顔と体の肌色を読み取り、体を顔へ寄せる倍率を区画ごとに決めます。", "Reads the face and body skin colors and decides, sector by sector, how far to move the body toward the face.")));
            if (neckTargets != null && (neckTargets.FaceSlots.Length > 1 || neckTargets.BodySlots.Length > 1))
                card.Add(TsugimelessStyles.Note(L.T("最初の材質欄だけを補正します。", "Only the first material slot is corrected.")));
            bool baked = seamBake != null && seamBake.Valid;
            string status = baked ? "✓ " + L.T("色を計算しました。体に仮表示しています。", "The colors are ready. They are shown on the body as a preview.")
                : seamColorReason != null ? L.T("色を計算できませんでした。", "The colors could not be computed.")
                : L.T("まだ計算していません。", "Not computed yet.");
            card.Add(SeamStatus(status));
            if (seamColorReason != null) card.Add(new HelpBox(seamColorReason, HelpBoxMessageType.Warning));
            if (seamReference != null && seamReference.Sectors != null && seamReference.Sectors.Length > 0)
            {
                card.Add(SeamSwatches(L.T("顔", "Face"), seamReference.Sectors.Select(s => s.faceAverage)));
                card.Add(SeamSwatches(L.T("体", "Body"), seamReference.Sectors.Select(s => s.bodyAverage)));
                card.Add(SeamSwatches(L.T("補正後", "Corrected"), seamReference.Sectors.Select(Corrected)));
                card.Add(TsugimelessStyles.Note(L.T("体の色を顔の色へ、区画ごとに合わせます（倍率 0.5〜2.0）", "The body color is matched to the face color sector by sector (gain 0.5 to 2.0)")));
            }
            if (seamBake != null)
            {
                if (seamBake.Valid && seamBake.TextureProperty == SeamColorEvaluator.SecondTexture)
                    card.Add(TsugimelessStyles.Note(L.T("追加の肌画像（2nd）の複製を補正します。元の画像と材質の設定は保ちます。", "A copy of the added skin image (2nd) is corrected. The original image and material settings are kept.")));
                card.Add(TsugimelessStyles.Note(L.F("帯の中 {0} 画素／到達できない画素 {1}（{2:F1}%）／最大誤差 {3:F4}", "Inside the band {0} pixels / pixels that cannot be reached {1} ({2:F1}%) / largest error {3:F4}",
                    seamBake.BandPixels, seamBake.UnreachablePixels,
                    seamBake.BandPixels > 0 ? 100f * seamBake.UnreachablePixels / seamBake.BandPixels : 0f, seamBake.MaxError)));
            }
            if (seamPreviewReason != null) card.Add(new HelpBox(seamPreviewReason, HelpBoxMessageType.Warning));
            var button = TsugimelessStyles.ColoredButton(baked ? L.T("やり直す", "Place it again") : L.T("色を計算する", "Compute the colors"),
                ComputeSeamColors, "seam-step3", !baked);
            button.SetEnabled(ready && seamBand != null && seamBand.Valid);
            card.Add(button);
            if (baked)
            {
                var toggle = TsugimelessStyles.ColoredButton(SeamPreviewShown() ? L.T("プレビューを消す", "Turn the preview off") : L.T("プレビューを見る", "Turn the preview on"),
                    ToggleSeamPreview, "seam-preview");
                card.Add(toggle);
            }
            body.Add(card);
        }

        private void BuildSeamApply(bool ready)
        {
            var card = TsugimelessStyles.Card();
            card.Add(TsugimelessStyles.Heading(L.T("④ グラデーションを作る", "4. Create the gradient")));
            card.Add(TsugimelessStyles.Note(L.T("体の画像を1枚作り、その画像を使う材質へ差し替えます。元の材質と画像は読むだけです。", "One new body image is written, and the slot is switched to a material that uses it. The original material and image are only read.")));
            bool baked = seamBake != null && seamBake.Valid;
            string status = seamApplied
                ? "✓ " + (string.IsNullOrEmpty(seamApplyPath)
                    ? L.T("適用しました。", "Applied.")
                    : L.F("適用しました。保存先: {0}", "Applied. Saved to {0}", seamApplyPath))
                : baked ? L.T("押すと、首のグラデーションを適用します。", "Press to apply the neck gradient.")
                : L.T("③まで済ませてください。", "Finish step 3 first.");
            card.Add(SeamStatus(status));
            if (seamApplied) card.Add(TsugimelessStyles.Note(L.T("シーンの保存（Ctrl+S）は自分で行ってください。", "Save the scene yourself with Ctrl+S.")));
            if (seamApplyReason != null) card.Add(new HelpBox(seamApplyReason, HelpBoxMessageType.Warning));
            var button = TsugimelessStyles.ColoredButton(L.T("グラデーションを作る", "Create the gradient"), ApplySeam, "seam-step4", true);
            button.SetEnabled(ready && baked && !seamApplied);
            card.Add(button);
            if (seamApplied)
            {
                card.Add(TsugimelessStyles.ColoredButton(L.T("元へ戻す", "Put the original back"), RestoreSeamMaterial, "seam-restore"));
                card.Add(TsugimelessStyles.ColoredButton(L.T("もう一度", "Once more"), RetrySeamColors, "seam-again"));
            }
            body.Add(card);
        }

        private static Label SeamStatus(string text)
        {
            var label = TsugimelessStyles.Note(text);
            label.style.marginBottom = 4;
            return label;
        }

        /// <summary>顔へ寄せたあとの体の色（linear）。表示だけに使う。</summary>
        private static Color Corrected(NeckSector sector)
            => new Color(sector.bodyAverage.r * sector.smoothedGain.x, sector.bodyAverage.g * sector.smoothedGain.y, sector.bodyAverage.b * sector.smoothedGain.z, 1);

        private static VisualElement SeamSwatches(string label, System.Collections.Generic.IEnumerable<Color> colors)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row; row.style.alignItems = Align.Center; row.style.flexWrap = Wrap.Wrap;
            var name = new Label(label); name.style.width = 56; name.style.flexShrink = 0; row.Add(name);
            foreach (var color in colors)
            {
                var swatch = new VisualElement();
                swatch.style.width = 18; swatch.style.height = 18; swatch.style.marginRight = 2; swatch.style.marginTop = 1; swatch.style.marginBottom = 1;
                swatch.style.flexShrink = 0;
                var gamma = color.gamma;
                swatch.style.backgroundColor = new Color(Mathf.Clamp01(gamma.r), Mathf.Clamp01(gamma.g), Mathf.Clamp01(gamma.b), 1);
                row.Add(swatch);
            }
            return row;
        }
    }
}
