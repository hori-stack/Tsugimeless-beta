using System;
using UnityEditor;

namespace HoriCraft.Tsugimeless.Editor
{
    internal static partial class TsugimelessLicense
    {
        private const string Preference = "HoriCraft.Tsugimeless.ProductLicense.v1";
        static partial void GetPublicKey(ref string modulus, ref string exponent);
        private static string checkedToken, checkedModulus, checkedExponent;
        private static DateTime checkedDay;
        private static TsugimelessLicenseCodec.Result result;
        internal static bool Active => Status == TsugimelessLicenseCodec.Result.Valid;
        internal static bool Registered => EditorPrefs.HasKey(Preference);
        internal static TsugimelessLicenseCodec.Result Status
        {
            get
            {
                string token = EditorPrefs.GetString(Preference, ""), n = null, e = null; GetPublicKey(ref n, ref e);
                if (token != checkedToken || n != checkedModulus || e != checkedExponent || checkedDay != DateTime.Today)
                {
                    checkedToken = token; checkedModulus = n; checkedExponent = e; checkedDay = DateTime.Today;
                    result = TsugimelessLicenseCodec.Verify(token, n, e, checkedDay);
                }
                return result;
            }
        }
        internal static TsugimelessLicenseCodec.Result Activate(string token)
        {
            string n = null, e = null; GetPublicKey(ref n, ref e);
            var status = TsugimelessLicenseCodec.Verify(token, n, e, DateTime.Today);
            if (status == TsugimelessLicenseCodec.Result.Valid) { EditorPrefs.SetString(Preference, token.Trim()); checkedToken = null; }
            return status; // A failed input never replaces the saved key. Never log the token.
        }
        internal static void Remove() { EditorPrefs.DeleteKey(Preference); checkedToken = null; }
        internal static bool Require(out string reason)
        { reason = Active ? null : Message(Status); return reason == null; }
        internal static string Message(TsugimelessLicenseCodec.Result status)
        {
            switch (status)
            {
                case TsugimelessLicenseCodec.Result.Valid: return L.T("解除キーを登録しました。", "The unlock key is registered.");
                case TsugimelessLicenseCodec.Result.NotConfigured: return L.T("この確認用パッケージは、解除キーの設定前です。アバター選択と線の調整を試せます。", "This verification package has no activation configuration yet. Avatar selection and line adjustment are available.");
                case TsugimelessLicenseCodec.Result.Expired: return L.T("解除キーの期限が過ぎています。色の計算と適用には、有効なキーが必要です。", "The unlock key has expired. A valid key is needed to compute and apply colors.");
                default: return L.T("解除キーを確認できません。ツギメレス用のキーを確認してください。", "The unlock key could not be verified. Check that it is a Tsugimeless key.");
            }
        }
    }
}
