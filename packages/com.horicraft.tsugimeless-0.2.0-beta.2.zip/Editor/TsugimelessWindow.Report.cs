using System;
using System.Globalization;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace HoriCraft.Tsugimeless.Editor
{
    public sealed partial class TsugimelessWindow
    {
        private NeckIssue seamAutoIssue;
        [Serializable] internal sealed class TesterReport
        {
            public int formatVersion = 1;
            public string capturedUtc, toolVersion, unityVersion, platform, graphicsApi, colorSpace, licenseState;
            public bool avatarSelected, sceneSaved, sceneHasPendingChanges, faceSelected, bodySelected, targetConfirmed;
            public string binding, step, detection, colorResult;
            public int faceSlot, bodySlot, availableLines, upperLine, lowerLine, bandPixels, unreachablePixels;
            public bool rangeReady, bandReady, calculationStale, applied, linePlacementStopped, colorStopped, previewStopped, applyStopped;
            public string maxError, meanError;
        }

        internal string BuildTesterReport()
        {
            // Deliberately enumerate safe scalar fields. Do not serialize Context, materials,
            // exceptions, hierarchy names, paths, mesh/UV data or the license token.
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssetPath("Packages/com.horicraft.tsugimeless/package.json");
            string Number(float? value) => value.HasValue && SeamColorEvaluator.Finite(value.Value)
                ? value.Value.ToString("G7", CultureInfo.InvariantCulture) : "unavailable";
            var report = new TesterReport
            {
                capturedUtc = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture),
                toolVersion = package?.version ?? "unknown", unityVersion = Application.unityVersion,
                platform = Application.platform.ToString(), graphicsApi = SystemInfo.graphicsDeviceType.ToString(),
                colorSpace = QualitySettings.activeColorSpace.ToString(), licenseState = TsugimelessLicense.Status.ToString(),
                avatarSelected = context.Root, sceneSaved = context.Root && !string.IsNullOrEmpty(context.Root.scene.path),
                sceneHasPendingChanges = context.Root && context.Root.scene.isDirty,
                faceSelected = neckTargets?.Face, bodySelected = neckTargets?.Body,
                targetConfirmed = neckTargets?.Confirmed == true, binding = neckTargets?.Binding.ToString() ?? "NoTarget",
                step = seamStep.ToString(), detection = seamAutoIssue.ToString(),
                faceSlot = SeamFaceSlot + 1, bodySlot = SeamBodySlot + 1,
                availableLines = seamRows?.Lines?.Length ?? 0,
                rangeReady = seamUseRows && seamRows?.Ready == true,
                upperLine = seamUseRows ? seamUpperLine + 1 : 0, lowerLine = seamUseRows ? seamLowerLine + 1 : 0,
                bandReady = seamBand?.Valid == true, calculationStale = seamStale,
                linePlacementStopped = !string.IsNullOrEmpty(seamAutoReason), colorStopped = !string.IsNullOrEmpty(seamColorReason),
                previewStopped = !string.IsNullOrEmpty(seamPreviewReason), applyStopped = !string.IsNullOrEmpty(seamApplyReason) && !seamApplied,
                colorResult = seamStale ? "Stale" : !string.IsNullOrEmpty(seamColorReason) ? "Stopped" : seamBake == null ? "NotCalculated" : seamBake.Valid ? "Ready" : "Stopped",
                bandPixels = seamBake?.BandPixels ?? 0, unreachablePixels = seamBake?.UnreachablePixels ?? 0,
                maxError = Number(seamBake?.MaxError), meanError = Number(seamBake?.MeanError), applied = seamApplied
            };
            return JsonUtility.ToJson(report, true);
        }

        private void BuildTesterReportCard()
        {
            var foldout = new Foldout { name = "tester-report", text = L.T("テスト結果を伝える", "Share a test result"), value = false };
            foldout.Add(TsugimelessStyles.Note(L.T("バージョンと処理の状態をまとめます。キー・アバター名・PC名・保存先は含みません。自動送信はしません。",
                "Collect versions and processing status. Keys, avatar names, PC names and file paths are excluded. Nothing is sent automatically.")));
            var content = new TextField { name = "tester-report-content", multiline = true, isReadOnly = true };
            content.style.display = DisplayStyle.None; content.style.height = 180;
            var notice = TsugimelessStyles.Note(""); notice.name = "tester-report-notice";
            var copy = TsugimelessStyles.ColoredButton(L.T("この内容をコピーする", "Copy this information"), () =>
            {
                try { EditorGUIUtility.systemCopyBuffer = content.value; notice.text = L.T("コピーしました。依頼者への返信に貼り付けてください。", "Copied. Paste it into your reply to the tester coordinator."); }
                catch { notice.text = L.T("コピーできませんでした。表示内容を選択してコピーしてください。", "Copy failed. Select the displayed text and copy it manually."); }
            }, "tester-report-copy");
            copy.SetEnabled(false);
            foldout.Add(TsugimelessStyles.ColoredButton(L.T("検証情報を表示する", "Show test information"), () =>
            {
                content.SetValueWithoutNotify(BuildTesterReport()); content.style.display = DisplayStyle.Flex; copy.SetEnabled(true);
                notice.text = L.T("表示した時点の情報です。内容を確認してからコピーしてください。", "This captures the current state. Review it before copying.");
            }, "tester-report-show"));
            foldout.Add(content); foldout.Add(copy); foldout.Add(notice); body.Add(foldout);
        }
    }
}
